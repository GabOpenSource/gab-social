Contributing
============

Thank you for considering contributing to Gab Social

You can contribute in the following ways:

- Finding and reporting bugs
- Translating the Gab Social interface into various languages
- Contributing code to Gab Social by fixing bugs or implementing features
- Improving the documentation

