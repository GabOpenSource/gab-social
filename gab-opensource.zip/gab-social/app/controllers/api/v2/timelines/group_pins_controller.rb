# frozen_string_literal: true

class Api::V2::Timelines::GroupPinsController < Api::BaseController
  before_action :set_group
  before_action :set_statuses

  def show
    if current_user
      render json: @statuses,
           serializer: REST::StatusTimelineSerializer,
           relationships: StatusRelationshipsPresenter.new(@statuses, current_user&.account_id, group_id: @group.id),
           data: StatusDataPresenter.new(@statuses)
    else
      render json: @statuses, 
        serializer: REST::StatusTimelineSerializer,
        data: StatusDataPresenter.new(@statuses)
    end
    filtered_statuses = @statuses.select { |s| s.attrs['was_pro'] == true }
    if !filtered_statuses.empty?
      StathouseStatWorker.perform_async('status', filtered_statuses.map(&:id).map(&:to_s), 'view', current_account ? current_account.id : nil)
    end
  end

  private

  def set_group
    @group = Group.find_by!(id: params[:id], is_archived: false)
  end

  def set_statuses
    @statuses = cached_group_statuses
  end

  def cached_group_statuses
    cache_collection group_statuses, Status
  end

  def group_statuses
    statuses = []
    @group.pinned_statuses.each do |s|
      statuses << s
    end
    statuses
  end

end
