import {
  Map as ImmutableMap,
  List as ImmutableList,
} from 'immutable'
import debounce from 'lodash/debounce'
import api, { getLinks } from '../api'
import { me, createdAt } from '../initial_state'
import { importFetchedAccounts, importFetchedStatuses } from './importer'
import { fetchRelationships } from './accounts'
import { updateStatusStats } from './statuses'
import { timelinePins, timelineStatusDelete } from '../store/timelines'
import { appendIsBlockingGroupId, removeIsBlockingGroupId } from '../utils/local_storage_blocks_mutes'
import {
  ACCEPTED_GROUP_TABS,
  GROUP_LIST_SORTING_TYPE_ALPHABETICAL,
  GROUP_LIST_SORTING_TYPE_MOST_POPULAR,
  TOAST_TYPE_ERROR,
} from '../constants'
import { showToast } from './toasts'

export const GROUP_FETCH_REQUEST = 'GROUP_FETCH_REQUEST'
export const GROUP_FETCH_SUCCESS = 'GROUP_FETCH_SUCCESS'
export const GROUP_FETCH_FAIL    = 'GROUP_FETCH_FAIL'

export const GROUP_RELATIONSHIPS_FETCH_REQUEST = 'GROUP_RELATIONSHIPS_FETCH_REQUEST'
export const GROUP_RELATIONSHIPS_FETCH_SUCCESS = 'GROUP_RELATIONSHIPS_FETCH_SUCCESS'
export const GROUP_RELATIONSHIPS_FETCH_FAIL    = 'GROUP_RELATIONSHIPS_FETCH_FAIL'

export const GROUPS_FETCH_REQUEST = 'GROUPS_FETCH_REQUEST'
export const GROUPS_FETCH_SUCCESS = 'GROUPS_FETCH_SUCCESS'
export const GROUPS_FETCH_FAIL    = 'GROUPS_FETCH_FAIL'

export const GROUP_JOIN_REQUEST = 'GROUP_JOIN_REQUEST'
export const GROUP_JOIN_SUCCESS = 'GROUP_JOIN_SUCCESS'
export const GROUP_JOIN_FAIL    = 'GROUP_JOIN_FAIL'

export const GROUP_LEAVE_REQUEST = 'GROUP_LEAVE_REQUEST'
export const GROUP_LEAVE_SUCCESS = 'GROUP_LEAVE_SUCCESS'
export const GROUP_LEAVE_FAIL    = 'GROUP_LEAVE_FAIL'

export const GROUP_MUTE_REQUEST = 'GROUP_MUTE_REQUEST'
export const GROUP_MUTE_SUCCESS = 'GROUP_MUTE_SUCCESS'
export const GROUP_MUTE_FAIL = 'GROUP_MUTE_FAIL'

export const GROUP_UNMUTE_REQUEST = 'GROUP_UNMUTE_REQUEST'
export const GROUP_UNMUTE_SUCCESS = 'GROUP_UNMUTE_SUCCESS'
export const GROUP_UNMUTE_FAIL = 'GROUP_UNMUTE_FAIL'

//

export const GROUP_ADMINS_FETCH_REQUEST = 'GROUP_ADMINS_FETCH_REQUEST'
export const GROUP_ADMINS_FETCH_SUCCESS = 'GROUP_ADMINS_FETCH_SUCCESS'
export const GROUP_ADMINS_FETCH_FAIL    = 'GROUP_ADMINS_FETCH_FAIL'

export const GROUP_MEMBERS_FETCH_REQUEST = 'GROUP_MEMBERS_FETCH_REQUEST'
export const GROUP_MEMBERS_FETCH_SUCCESS = 'GROUP_MEMBERS_FETCH_SUCCESS'
export const GROUP_MEMBERS_FETCH_FAIL    = 'GROUP_MEMBERS_FETCH_FAIL'

export const GROUP_MEMBERS_EXPAND_REQUEST = 'GROUP_MEMBERS_EXPAND_REQUEST'
export const GROUP_MEMBERS_EXPAND_SUCCESS = 'GROUP_MEMBERS_EXPAND_SUCCESS'
export const GROUP_MEMBERS_EXPAND_FAIL    = 'GROUP_MEMBERS_EXPAND_FAIL'

export const GROUP_MEMBERS_SEARCH_SUCCESS = 'GROUP_MEMBERS_SEARCH_SUCCESS'
export const CLEAR_GROUP_MEMBERS_SEARCH = 'CLEAR_GROUP_MEMBERS_SEARCH'

//

export const GROUP_REMOVED_ACCOUNTS_FETCH_REQUEST = 'GROUP_REMOVED_ACCOUNTS_FETCH_REQUEST'
export const GROUP_REMOVED_ACCOUNTS_FETCH_SUCCESS = 'GROUP_REMOVED_ACCOUNTS_FETCH_SUCCESS'
export const GROUP_REMOVED_ACCOUNTS_FETCH_FAIL    = 'GROUP_REMOVED_ACCOUNTS_FETCH_FAIL'

export const GROUP_REMOVED_ACCOUNTS_EXPAND_REQUEST = 'GROUP_REMOVED_ACCOUNTS_EXPAND_REQUEST'
export const GROUP_REMOVED_ACCOUNTS_EXPAND_SUCCESS = 'GROUP_REMOVED_ACCOUNTS_EXPAND_SUCCESS'
export const GROUP_REMOVED_ACCOUNTS_EXPAND_FAIL    = 'GROUP_REMOVED_ACCOUNTS_EXPAND_FAIL'

export const GROUP_REMOVED_ACCOUNTS_SEARCH_SUCCESS = 'GROUP_REMOVED_ACCOUNTS_SEARCH_SUCCESS'
export const CLEAR_GROUP_REMOVED_ACCOUNTS_SEARCH = 'CLEAR_GROUP_REMOVED_ACCOUNTS_SEARCH'

//

export const GROUP_REMOVED_ACCOUNTS_REMOVE_REQUEST = 'GROUP_REMOVED_ACCOUNTS_REMOVE_REQUEST'
export const GROUP_REMOVED_ACCOUNTS_REMOVE_SUCCESS = 'GROUP_REMOVED_ACCOUNTS_REMOVE_SUCCESS'
export const GROUP_REMOVED_ACCOUNTS_REMOVE_FAIL    = 'GROUP_REMOVED_ACCOUNTS_REMOVE_FAIL'

export const GROUP_REMOVED_ACCOUNTS_CREATE_REQUEST = 'GROUP_REMOVED_ACCOUNTS_CREATE_REQUEST'
export const GROUP_REMOVED_ACCOUNTS_CREATE_SUCCESS = 'GROUP_REMOVED_ACCOUNTS_CREATE_SUCCESS'
export const GROUP_REMOVED_ACCOUNTS_CREATE_FAIL    = 'GROUP_REMOVED_ACCOUNTS_CREATE_FAIL'

//

export const GROUP_JOIN_REQUESTS_FETCH_REQUEST = 'GROUP_JOIN_REQUESTS_FETCH_REQUEST'
export const GROUP_JOIN_REQUESTS_FETCH_SUCCESS = 'GROUP_JOIN_REQUESTS_FETCH_SUCCESS'
export const GROUP_JOIN_REQUESTS_FETCH_FAIL = 'GROUP_JOIN_REQUESTS_FETCH_FAIL'

export const GROUP_JOIN_REQUESTS_EXPAND_REQUEST = 'GROUP_JOIN_REQUESTS_EXPAND_REQUEST'
export const GROUP_JOIN_REQUESTS_EXPAND_SUCCESS = 'GROUP_JOIN_REQUESTS_EXPAND_SUCCESS'
export const GROUP_JOIN_REQUESTS_EXPAND_FAIL = 'GROUP_JOIN_REQUESTS_EXPAND_FAIL'

export const GROUP_JOIN_REQUESTS_APPROVE_SUCCESS = 'GROUP_JOIN_REQUESTS_APPROVE_SUCCESS'
export const GROUP_JOIN_REQUESTS_APPROVE_FAIL = 'GROUP_JOIN_REQUESTS_APPROVE_FAIL'

export const GROUP_JOIN_REQUESTS_REJECT_SUCCESS = 'GROUP_JOIN_REQUESTS_REJECT_SUCCESS'
export const GROUP_JOIN_REQUESTS_REJECT_FAIL = 'GROUP_JOIN_REQUESTS_REJECT_FAIL'

//

export const GROUP_REMOVE_STATUS_REQUEST = 'GROUP_REMOVE_STATUS_REQUEST'
export const GROUP_REMOVE_STATUS_SUCCESS = 'GROUP_REMOVE_STATUS_SUCCESS'
export const GROUP_REMOVE_STATUS_FAIL    = 'GROUP_REMOVE_STATUS_FAIL'

export const GROUP_UPDATE_ROLE_REQUEST = 'GROUP_UPDATE_ROLE_REQUEST'
export const GROUP_UPDATE_ROLE_SUCCESS = 'GROUP_UPDATE_ROLE_SUCCESS'
export const GROUP_UPDATE_ROLE_FAIL    = 'GROUP_UPDATE_ROLE_FAIL'

export const GROUP_CHECK_PASSWORD_RESET = 'GROUP_CHECK_PASSWORD_RESET'
export const GROUP_CHECK_PASSWORD_REQUEST = 'GROUP_CHECK_PASSWORD_REQUEST'
export const GROUP_CHECK_PASSWORD_SUCCESS = 'GROUP_CHECK_PASSWORD_SUCCESS'
export const GROUP_CHECK_PASSWORD_FAIL = 'GROUP_CHECK_PASSWORD_FAIL'

export const GROUP_PIN_STATUS_REQUEST = 'GROUP_PIN_STATUS_REQUEST'
export const GROUP_PIN_STATUS_SUCCESS = 'GROUP_PIN_STATUS_SUCCESS'
export const GROUP_PIN_STATUS_FAIL = 'GROUP_PIN_STATUS_FAIL'

export const GROUP_UNPIN_STATUS_REQUEST = 'GROUP_UNPIN_STATUS_REQUEST'
export const GROUP_UNPIN_STATUS_SUCCESS = 'GROUP_UNPIN_STATUS_SUCCESS'
export const GROUP_UNPIN_STATUS_FAIL = 'GROUP_UNPIN_STATUS_FAIL'

export const IS_PINNED_GROUP_STATUS_REQUEST = 'IS_PINNED_GROUP_STATUS_REQUEST'
export const IS_PINNED_GROUP_STATUS_SUCCESS = 'IS_PINNED_GROUP_STATUS_SUCCESS'
export const IS_PINNED_GROUP_STATUS_FAIL = 'IS_PINNED_GROUP_STATUS_FAIL'

export const GROUPS_BY_CATEGORY_FETCH_REQUEST = 'GROUPS_BY_CATEGORY_FETCH_REQUEST'
export const GROUPS_BY_CATEGORY_FETCH_SUCCESS = 'GROUPS_BY_CATEGORY_FETCH_SUCCESS'
export const GROUPS_BY_CATEGORY_FETCH_FAIL = 'GROUPS_BY_CATEGORY_FETCH_FAIL'

export const GROUP_TIMELINE_SORT = 'GROUP_TIMELINE_SORT'
export const GROUP_TIMELINE_TOP_SORT = 'GROUP_TIMELINE_TOP_SORT'

export const GROUP_SORT = 'GROUP_SORT'
export const GROUP_MODERATION_STATS = 'GROUP_MODERATION_STATS'
export const GROUP_MODERATION_MY_STATS = 'GROUP_MODERATION_MY_STATS'

/**
 * @description Import a group into redux
 * @param {ImmutableMap} group
 */
export const importGroup = (group) => (dispatch) => {
  dispatch(fetchGroupSuccess(group))
}

export const importGroups = (groups) => (dispatch) => {
  if (!Array.isArray(groups)) return
  groups.map((group) => dispatch(fetchGroupSuccess(group)))
}

/**
 * @description Fetch a group with the given groupId
 * @param {string} groupId
 */
export const fetchGroup = (groupId) => (dispatch, getState) => {
  if (!groupId) return

  dispatch(fetchGroupRelationships([groupId]))

  // Check if exists already
  if (getState().getIn(['groups', groupId])) return

  dispatch(fetchGroupRequest(groupId))

  api(getState).get(`/api/v1/groups/${groupId}`)
    .then((response) => dispatch(fetchGroupSuccess(response.data)))
    .catch((err) => dispatch(fetchGroupFail(groupId, err)))
}

const fetchGroupRequest = (groupId) => ({
  type: GROUP_FETCH_REQUEST,
  groupId,
})

const fetchGroupSuccess = (group) => ({
  type: GROUP_FETCH_SUCCESS,
  group,
})

const fetchGroupFail = (groupId, error) => ({
  type: GROUP_FETCH_FAIL,
  showToast: true,
  groupId,
  error,
})

/**
 * @description Fetch relationships for the given groupIds and current user. For example
 *              if the current user is a member, admin, mod or not.
 * @param {Array} groupIds
 */
export const fetchGroupRelationships = (groupIds) => (dispatch, getState) => {
  if (!me || !groupIds) return

  if (typeof groupIds === 'string' || typeof groupIds === 'number') {
    groupIds = [groupIds]
  }

  // Unique
  const newGroupIds = Array.from(new Set(groupIds))

  dispatch(fetchGroupRelationshipsRequest(newGroupIds))

  api(getState).post('/api/v1/group_relationships', {
    groupIds: newGroupIds,
  }).then(({ data }) => {
    dispatch(fetchGroupRelationshipsSuccess(data))
    data.forEach(function({ id, member, admin, moderator }) {
      if (typeof id === 'string' && member && (admin || moderator)) {
        // user is a mod
        dispatch(moderationStats(id))
        dispatch(fetchJoinRequests(id))
      } else {
        // normal user
        var monthsAgo = new Date()
        monthsAgo.setMonth(monthAgo.getMonth() - 3)
        if (createdAt && createdAt > monthsAgo) {
          dispatch(moderationMyStats(id))
        }
      }
    })
  }).catch((error) => {
    dispatch(fetchGroupRelationshipsFail(error))
  })
}

const fetchGroupRelationshipsRequest = (groupIds) => ({
  type: GROUP_RELATIONSHIPS_FETCH_REQUEST,
  groupIds,
})

const fetchGroupRelationshipsSuccess = (relationships) => ({
  type: GROUP_RELATIONSHIPS_FETCH_SUCCESS,
  relationships,
})

const fetchGroupRelationshipsFail = (error) => ({
  type: GROUP_RELATIONSHIPS_FETCH_FAIL,
  error,
})

/**
 * @description Fetch all groups (limited uniquely per tab, non paginated) by tab. Import
 *              groups and fetch relationships for each if tab !== member.
 * @param {String} tab
 */
export const fetchGroupsByTab = (tab) => (dispatch, getState) => {
  if (ACCEPTED_GROUP_TABS.indexOf(tab) === -1) return
  if (!me && tab !== 'featured') return

  // Don't refetch or fetch when loading
  const isLoading = getState().getIn(['group_lists', tab, 'isLoading'])
  const isFetched = getState().getIn(['group_lists', tab, 'isFetched'])

  if (isLoading || isFetched) return

  dispatch(fetchGroupsRequest(tab))

  api(getState).get(`/api/v1/groups?tab=${tab}`)
    .then((response) => {
      dispatch(fetchGroupsSuccess(response.data, tab))
      if (tab !== 'member') {
        dispatch(fetchGroupRelationships(response.data.map(item => item.id)))
      }
    })
    .catch((err) => dispatch(fetchGroupsFail(err, tab)))
}

const fetchGroupsRequest = (tab) => ({
  type: GROUPS_FETCH_REQUEST,
  tab,
})

export const fetchGroupsSuccess = (groups, tab) => ({
  type: GROUPS_FETCH_SUCCESS,
  groups,
  tab,
})

const fetchGroupsFail = (error, tab) => ({
  type: GROUPS_FETCH_FAIL,
  showToast: true,
  error,
  tab,
})

/**
 * @description Fetch all groups (limited to 100, non paginated) by category. Import groups
 *              and fetch relationships for each.
 * @param {String} category
 */
export const fetchGroupsByCategory = (sluggedCategory) => (dispatch, getState) => {
  if (!sluggedCategory) return

  const path = ['group_lists', 'by_category', sluggedCategory]

  // Don't refetch or fetch when loading
  const isLoading = getState().getIn([...path, 'isLoading'], false)

  if (isLoading) return

  // now loading
  dispatch(fetchGroupsByCategoryRequest(sluggedCategory))

  const groupIds = getState().getIn([...path, 'groupIds'], ImmutableList())
  const page = getState().getIn([...path, 'page'], 1)
  const params = { page }
  api(getState).get(`/api/v1/groups/_/category/${sluggedCategory}`, { params })
    .then((response) => {
      const { data: groups } = response;
      dispatch(fetchGroupsByCategorySuccess({ sluggedCategory, groups, groupIds, page }))
      dispatch(fetchGroupRelationships(response.data.map(item => item.id)))
    })
    .catch((err) => dispatch(fetchGroupsByCategoryFail(err, sluggedCategory)))
}

const fetchGroupsByCategoryRequest = (sluggedCategory) => ({
  type: GROUPS_BY_CATEGORY_FETCH_REQUEST,
  sluggedCategory,
})

const fetchGroupsByCategorySuccess = ({ sluggedCategory, groupIds, groups, page }) => ({
  type: GROUPS_BY_CATEGORY_FETCH_SUCCESS,
  sluggedCategory,
  groupIds,
  groups,
  page
})

const fetchGroupsByCategoryFail = (error, sluggedCategory) => ({
  type: GROUPS_BY_CATEGORY_FETCH_FAIL,
  showToast: true,
  error,
  sluggedCategory,
})

/**
 * @description Join group with the given groupId and return group relationships
 * @param {String} groupId
 */
export const joinGroup = (groupId) => (dispatch, getState) => {
  if (!me || !groupId) return

  dispatch(joinGroupRequest(groupId))

  api(getState).post(`/api/v1/groups/${groupId}/accounts`).then((response) => {
    dispatch(joinGroupSuccess(response.data))
  }).catch((error) => {
    dispatch(joinGroupFail(groupId, error))
  })
}

const joinGroupRequest = (groupId) => ({
  type: GROUP_JOIN_REQUEST,
  groupId,
})

const joinGroupSuccess = (relationship) => ({
  type: GROUP_JOIN_SUCCESS,
  showToast: true,
  relationship
})

const joinGroupFail = (error) => ({
  type: GROUP_JOIN_FAIL,
  showToast: true,
  error,
})

/**
 * @description Leave group with the given groupId and return group relationships
 * @param {String} groupId
 */
export const leaveGroup = (groupId) => (dispatch, getState) => {
  if (!me || !groupId) return
  
  dispatch(leaveGroupRequest(groupId))

  api(getState).delete(`/api/v1/groups/${groupId}/accounts`).then((response) => {
    dispatch(leaveGroupSuccess(response.data))
  }).catch((error) => {
    dispatch(leaveGroupFail(groupId, error))
  })
}

const leaveGroupRequest = (groupId) => ({
  type: GROUP_LEAVE_REQUEST,
  groupId,
})

const leaveGroupSuccess = (relationship) => ({
  type: GROUP_LEAVE_SUCCESS,
  showToast: true,
  relationship,
})

const leaveGroupFail = (error) => ({
  type: GROUP_LEAVE_FAIL,
  showToast: true,
  error,
})

export const fetchAdmins = (groupId) => (dispatch, getState) => {
  if (!me || !groupId) return

  dispatch(fetchAdminsRequest(groupId))

  api(getState).get(`/api/v1/groups/${groupId}/admins_and_mods`).then(({ data }) => {
    const { accounts, roles } = data
    const accountIds = Array.isArray(accounts) ? accounts.map((a) => a.id) : []

    dispatch(importFetchedAccounts(accounts))
    dispatch(fetchAdminsSuccess(groupId, accountIds, roles))
    dispatch(fetchRelationships(accountIds))
  }).catch((error) => {
    dispatch(fetchAdminsFail(groupId, error))
  })
}

const fetchAdminsRequest = (groupId) => ({
  type: GROUP_ADMINS_FETCH_REQUEST,
  groupId,
})

const fetchAdminsSuccess = (groupId, accountIds, roles) => ({
  type: GROUP_ADMINS_FETCH_SUCCESS,
  groupId,
  accountIds,
  roles,
})

const fetchAdminsFail = (groupId, error) => ({
  type: GROUP_ADMINS_FETCH_FAIL,
  showToast: true,
  groupId,
  error,
})

/**
 * @description Fetch members for the given groupId and imports paginated accounts
 *              and sets in user_lists reducer.
 * @param {String} groupId
 */
export const fetchMembers = (groupId) => (dispatch, getState) => {
  if (!me || !groupId) return

  dispatch(fetchMembersRequest(groupId))

  api(getState).get(`/api/v1/groups/${groupId}/accounts`).then((response) => {
    const next = getLinks(response).refs.find(link => link.rel === 'next')

    dispatch(importFetchedAccounts(response.data))
    dispatch(fetchMembersSuccess(groupId, response.data, next ? next.uri : null))
    dispatch(fetchRelationships(response.data.map(item => item.id)))
  }).catch((error) => {
    dispatch(fetchMembersFail(groupId, error))
  })
}

const fetchMembersRequest = (groupId) => ({
  type: GROUP_MEMBERS_FETCH_REQUEST,
  groupId,
})

const fetchMembersSuccess = (groupId, accounts, next) => ({
  type: GROUP_MEMBERS_FETCH_SUCCESS,
  groupId,
  accounts,
  next,
})

const fetchMembersFail = (groupId, error) => ({
  type: GROUP_MEMBERS_FETCH_FAIL,
  showToast: true,
  groupId,
  error,
})

/**
 * @description Expand members for the given groupId and imports paginated accounts
 *              and sets in user_lists reducer.
 * @param {String} groupId
 */
export const expandMembers = (groupId) => (dispatch, getState) => {
  if (!me || !groupId) return

  const url = getState().getIn(['user_lists', 'groups', groupId, 'next'])
  const isLoading = getState().getIn(['user_lists', 'groups', groupId, 'isLoading'])

  if (url === null || isLoading) return

  dispatch(expandMembersRequest(groupId))

  api(getState).get(url).then((response) => {
    const next = getLinks(response).refs.find(link => link.rel === 'next')

    dispatch(importFetchedAccounts(response.data))
    dispatch(expandMembersSuccess(groupId, response.data, next ? next.uri : null))
    dispatch(fetchRelationships(response.data.map(item => item.id)))
  }).catch((error) => {
    dispatch(expandMembersFail(groupId, error))
  })
}

const expandMembersRequest = (groupId) => ({
  type: GROUP_MEMBERS_EXPAND_REQUEST,
  groupId,
})

const expandMembersSuccess = (groupId, accounts, next) => ({
  type: GROUP_MEMBERS_EXPAND_SUCCESS,
  groupId,
  accounts,
  next,
})

const expandMembersFail = (groupId, error) => ({
  type: GROUP_MEMBERS_EXPAND_FAIL,
  showToast: true,
  groupId,
  error,
})

/**
 * 
 */
export const fetchGroupMembersAdminSearch = (groupId, query) => (dispatch, getState) => {
  if (!groupId || !query) return
  debouncedFetchGroupMembersAdminSearch(groupId, query, dispatch, getState) 
}

export const debouncedFetchGroupMembersAdminSearch = debounce((groupId, query, dispatch, getState) => {
  if (!groupId || !query) return

  api(getState).get(`/api/v1/groups/${groupId}/member_search`, {
    params: { q: query },
  }).then((response) => {
    dispatch(importFetchedAccounts(response.data))
    dispatch(fetchGroupMembersAdminSearchSuccess(response.data))
  }).catch((error) => {
    //
  })
}, 650, { leading: true })

const fetchGroupMembersAdminSearchSuccess = (accounts) => ({
  type: GROUP_MEMBERS_SEARCH_SUCCESS,
  accounts,
})

/**
 * 
 */
export const clearGroupMembersAdminSearch = () => (dispatch) => {
  dispatch({ type: CLEAR_GROUP_MEMBERS_SEARCH })
}

/**
 * @description Fetch removed accounts for the given groupId and imports paginated
 *              accounts and sets in user_lists reducer.
 * @param {String} groupId
 */
export const fetchRemovedAccounts = (groupId) => (dispatch, getState) => {
  if (!me || !groupId) return

  dispatch(fetchRemovedAccountsRequest(groupId))

  api(getState).get(`/api/v1/groups/${groupId}/removed_accounts`).then((response) => {
    const next = getLinks(response).refs.find(link => link.rel === 'next')

    dispatch(importFetchedAccounts(response.data))
    dispatch(fetchRemovedAccountsSuccess(groupId, response.data, next ? next.uri : null))
    dispatch(fetchRelationships(response.data.map(item => item.id)))
  }).catch((error) => {
    dispatch(fetchRemovedAccountsFail(groupId, error))
  })
}

const fetchRemovedAccountsRequest = (groupId) => ({
  type: GROUP_REMOVED_ACCOUNTS_FETCH_REQUEST,
  groupId,
})

const fetchRemovedAccountsSuccess = (groupId, accounts, next) => ({
  type: GROUP_REMOVED_ACCOUNTS_FETCH_SUCCESS,
  groupId,
  accounts,
  next,
})

const fetchRemovedAccountsFail = (groupId, error) => ({
  type: GROUP_REMOVED_ACCOUNTS_FETCH_FAIL,
  showToast: true,
  groupId,
  error,
})

/**
 * @description Expand likes for the given statusId and imports paginated accounts
 *              and sets in user_lists reducer.
 * @param {String} statusId
 */
export const expandRemovedAccounts = (groupId) => (dispatch, getState) => {
  if (!me || !groupId) return

  const url = getState().getIn(['user_lists', 'group_removed_accounts', groupId, 'next'])
  const isLoading = getState().getIn(['user_lists', 'group_removed_accounts', groupId, 'isLoading'])

  if (url === null || isLoading) return

  dispatch(expandRemovedAccountsRequest(groupId))

  api(getState).get(url).then((response) => {
    const next = getLinks(response).refs.find(link => link.rel === 'next')

    dispatch(importFetchedAccounts(response.data))
    dispatch(expandRemovedAccountsSuccess(groupId, response.data, next ? next.uri : null))
    dispatch(fetchRelationships(response.data.map(item => item.id)))
  }).catch((error) => {
    dispatch(expandRemovedAccountsFail(groupId, error))
  })
}

const expandRemovedAccountsRequest = (groupId) => ({
  type: GROUP_REMOVED_ACCOUNTS_EXPAND_REQUEST,
  groupId,
})

const expandRemovedAccountsSuccess = (groupId, accounts, next) => ({
  type: GROUP_REMOVED_ACCOUNTS_EXPAND_SUCCESS,
  groupId,
  accounts,
  next,
})

const expandRemovedAccountsFail = (groupId, error) => ({
  type: GROUP_REMOVED_ACCOUNTS_EXPAND_FAIL,
  showToast: true,
  groupId,
  error,
})

/**
 * 
 */
export const fetchGroupRemovedAccountsAdminSearch = (groupId, query) => (dispatch, getState) => {
  if (!groupId || !query) return
  debouncedFetchGroupRemovedAccountsAdminSearch(groupId, query, dispatch, getState) 
}

export const debouncedFetchGroupRemovedAccountsAdminSearch = debounce((groupId, query, dispatch, getState) => {
  if (!groupId || !query) return
  
  api(getState).get(`/api/v1/groups/${groupId}/removed_accounts_search`, {
    params: { q: query },
  }).then((response) => {
    dispatch(importFetchedAccounts(response.data))
    dispatch(fetchGroupRemovedAccountsAdminSearchSuccess(response.data))
  }).catch((error) => {
    //
  })
}, 650, { leading: true })

const fetchGroupRemovedAccountsAdminSearchSuccess = (accounts) => ({
  type: GROUP_REMOVED_ACCOUNTS_SEARCH_SUCCESS,
  accounts,
})

/**
 * 
 */
export const clearGroupRemovedAccountsAdminSearch = () => (dispatch) => {
  dispatch({ type: CLEAR_GROUP_REMOVED_ACCOUNTS_SEARCH })
}

/**
 * @description Remove a "removed account" from a group with the given groupId and accountId.
 * @param {String} groupId
 * @param {String} accountId
 */
export const removeRemovedAccount = (groupId, accountId) => (dispatch, getState) => {
  if (!me || !groupId || !accountId) return

  dispatch(removeRemovedAccountRequest(groupId, accountId))

  api(getState).delete(`/api/v1/groups/${groupId}/removed_accounts?account_id=${accountId}`).then((response) => {
    dispatch(removeRemovedAccountSuccess(groupId, accountId))
  }).catch((error) => {
    dispatch(removeRemovedAccountFail(groupId, accountId, error))
  })
}

const removeRemovedAccountRequest = (groupId, accountId) => ({
  type: GROUP_REMOVED_ACCOUNTS_REMOVE_REQUEST,
  groupId,
  accountId,
})

const removeRemovedAccountSuccess = (groupId, accountId) => ({
  type: GROUP_REMOVED_ACCOUNTS_REMOVE_SUCCESS,
  showToast: true,
  groupId,
  accountId,
})

const removeRemovedAccountFail = (groupId, accountId, error) => ({
  type: GROUP_REMOVED_ACCOUNTS_REMOVE_FAIL,
  showToast: true,
  groupId,
  accountId,
  error,
})

/**
 * @description Remove an account with given accountId from group with given groupId
 * @param {String} groupId
 * @param {String} accountId
 */
export const createRemovedAccount = (groupId, accountId) => (dispatch, getState) => {
  if (!me) return

  dispatch(createRemovedAccountRequest(groupId, accountId))

  api(getState).post(`/api/v1/groups/${groupId}/removed_accounts?account_id=${accountId}`).then((response) => {
    dispatch(createRemovedAccountSuccess(groupId, accountId))
  }).catch((error) => {
    dispatch(createRemovedAccountFail(groupId, accountId, error))
  })
}

const createRemovedAccountRequest = (groupId, accountId) => ({
  type: GROUP_REMOVED_ACCOUNTS_CREATE_REQUEST,
  groupId,
  accountId,
})

const createRemovedAccountSuccess = (groupId, accountId) => ({
  type: GROUP_REMOVED_ACCOUNTS_CREATE_SUCCESS,
  showToast: true,
  groupId,
  accountId,
})

const createRemovedAccountFail = (groupId, accountId, error) => ({
  type: GROUP_REMOVED_ACCOUNTS_CREATE_FAIL,
  showToast: true,
  groupId,
  accountId,
  error,
})

/**
 * @description Remove a status from a group with given groupId and statusId. Then
 *              remove the status from the group timeline on success.
 * @param {String} groupId
 * @param {String} statusId
 */
export const groupRemoveStatus = (groupId, statusId) => (dispatch, getState) => {
  if (!me || !groupId || !statusId) return

  dispatch(groupRemoveStatusRequest(groupId, statusId))
  dispatch(timelineStatusDelete({ timelineId: `group:${groupId}`, statusId }))

  api(getState).delete(`/api/v1/groups/${groupId}/statuses/${statusId}`).then((response) => {
    dispatch(groupRemoveStatusSuccess(groupId, statusId))
  }).catch((error) => {
    dispatch(groupRemoveStatusFail(groupId, statusId, error))
  })
}

const groupRemoveStatusRequest = (groupId, statusId) => ({
  type: GROUP_REMOVE_STATUS_REQUEST,
  groupId,
  statusId,
})

const groupRemoveStatusSuccess = (groupId, statusId) => ({
  type: GROUP_REMOVE_STATUS_SUCCESS,
  showToast: true,
  groupId,
  statusId,
})

const groupRemoveStatusFail = (groupId, statusId, error) => ({
  type: GROUP_REMOVE_STATUS_FAIL,
  showToast: true,
  groupId,
  statusId,
  error,
})

/**
 * @description Update role to admin, moderator for given accountId in given groupId
 * @param {String} groupId
 * @param {String} accountId
 * @param {String} role
 */
export const updateRole = (groupId, accountId, role) => (dispatch, getState) => {
  if (!me || !groupId || !accountId) return

  dispatch(updateRoleRequest(groupId, accountId))

  api(getState).patch(`/api/v1/groups/${groupId}/accounts?account_id=${accountId}`, { role }).then((response) => {
    dispatch(updateRoleSuccess(groupId, accountId))
  }).catch((error) => {
    dispatch(showToast(TOAST_TYPE_ERROR, {type: error } ))
    dispatch(updateRoleFail(groupId, accountId, error))
  })
}

const updateRoleRequest = (groupId, accountId) => ({
  type: GROUP_UPDATE_ROLE_REQUEST,
  groupId,
  accountId,
})

const updateRoleSuccess = (groupId, accountId) => ({
  type: GROUP_UPDATE_ROLE_SUCCESS,
  showToast: true,
  groupId,
  accountId,
})

const updateRoleFail = (groupId, accountId, error) => ({
  type: GROUP_UPDATE_ROLE_FAIL,
  groupId,
  accountId,
  error,
})

/**
 * @description Reset the group password check map when group password model opens
 */
export const checkGroupPasswordReset = () => ({
  type: GROUP_CHECK_PASSWORD_RESET,
})

/**
 * 
 */
export const checkGroupPassword = (groupId, password) => (dispatch, getState) => {
  if (!me || !groupId) return

  dispatch(checkGroupPasswordRequest())

  api(getState).post(`/api/v1/groups/${groupId}/password`, { password }).then((response) => {
    dispatch(joinGroupSuccess(response.data))
    dispatch(checkGroupPasswordSuccess())
  }).catch((error) => {
    dispatch(checkGroupPasswordFail(error))
  })
}

const checkGroupPasswordRequest = () => ({
  type: GROUP_CHECK_PASSWORD_REQUEST,
})

const checkGroupPasswordSuccess = () => ({
  type: GROUP_CHECK_PASSWORD_SUCCESS,
})

export const checkGroupPasswordFail = (error) => ({
  type: GROUP_CHECK_PASSWORD_FAIL,
  error,
})

/**
 * 
 */
export const fetchJoinRequests = (groupId) => (dispatch, getState) => {
  if (!me) return

  dispatch(fetchJoinRequestsRequest(groupId))

  api(getState).get(`/api/v1/groups/${groupId}/join_requests`).then((response) => {
    const next = getLinks(response).refs.find(link => link.rel === 'next')

    dispatch(importFetchedAccounts(response.data))
    dispatch(fetchJoinRequestsSuccess(groupId, response.data, next ? next.uri : null))
    dispatch(fetchRelationships(response.data.map(item => item.id)))
  }).catch((error) => {
    dispatch(fetchJoinRequestsFail(groupId, error))
  })
}

const fetchJoinRequestsRequest = (groupId) => ({
  type: GROUP_JOIN_REQUESTS_FETCH_REQUEST,
  groupId,
})

const fetchJoinRequestsSuccess = (groupId, accounts, next) => ({
  type: GROUP_JOIN_REQUESTS_FETCH_SUCCESS,
  groupId,
  accounts,
  next,
})

const fetchJoinRequestsFail = (groupId, error) => ({
  type: GROUP_JOIN_REQUESTS_FETCH_FAIL,
  showToast: true,
  groupId,
  error,
})

/**
 * 
 */
export const expandJoinRequests = (groupId) => (dispatch, getState) => {
  if (!me) return

  const url = getState().getIn(['user_lists', 'group_join_requests', groupId, 'next'])
  const isLoading = getState().getIn(['user_lists', 'group_join_requests', groupId, 'isLoading'])

  if (url === null || isLoading) return

  dispatch(expandJoinRequestsRequest(groupId))

  api(getState).get(url).then((response) => {
    const next = getLinks(response).refs.find(link => link.rel === 'next')

    dispatch(importFetchedAccounts(response.data))
    dispatch(expandJoinRequestsSuccess(groupId, response.data, next ? next.uri : null))
    dispatch(fetchRelationships(response.data.map(item => item.id)))
  }).catch((error) => {
    dispatch(expandJoinRequestsFail(groupId, error))
  })
}

const expandJoinRequestsRequest = (groupId) => ({
  type: GROUP_JOIN_REQUESTS_EXPAND_REQUEST,
  groupId,
})

const expandJoinRequestsSuccess = (id, accounts, next) => ({
  type: GROUP_JOIN_REQUESTS_EXPAND_SUCCESS,
  groupId,
  accounts,
  next,
})

const expandJoinRequestsFail = (groupId, error) => ({
  type: GROUP_JOIN_REQUESTS_EXPAND_FAIL,
  showToast: true,
  groupId,
  error,
})

/**
 * 
 */
export const approveJoinRequest = (accountId, groupId) => (dispatch, getState) => {
  if (!me) return

  api(getState).post(`/api/v1/groups/${groupId}/join_requests/respond`, { accountId, type: 'approve' }).then((response) => {
    dispatch(approveJoinRequestSuccess(response.data.accountId, groupId))
  }).catch((error) => {
    dispatch(approveJoinRequestFail(accountId, groupId, error))
  })
}

const approveJoinRequestSuccess = (accountId, groupId) => ({
  type: GROUP_JOIN_REQUESTS_APPROVE_SUCCESS,
  showToast: true,
  accountId,
  groupId,
})

const approveJoinRequestFail = (accountId, groupId, error) => ({
  type: GROUP_JOIN_REQUESTS_APPROVE_FAIL,
  showToast: true,
  accountId,
  groupId,
  error,
})

/**
 * 
 */
export const rejectJoinRequest = (accountId, groupId) => (dispatch, getState) => {
  if (!me) return

  api(getState).post(`/api/v1/groups/${groupId}/join_requests/respond`, { accountId, type: 'reject' }).then((response) => {
    dispatch(rejectJoinRequestSuccess(response.data.accountId, groupId))
  }).catch((error) => {
    dispatch(rejectJoinRequestFail(accountId, groupId, error))
  })
}

const rejectJoinRequestSuccess = (accountId, groupId) => ({
  type: GROUP_JOIN_REQUESTS_REJECT_SUCCESS,
  showToast: true,
  accountId,
  groupId,
})

const rejectJoinRequestFail = (accountId, groupId, error) => ({
  type: GROUP_JOIN_REQUESTS_REJECT_FAIL,
  showToast: true,
  accountId,
  groupId,
  error,
})

/*
 * Moderators can trigger these actions from moderation_action_bar.js
 */
export const groupModerationRespondOptions = [
  {
    action: 'approve_post',
    icon: 'like',
    title: 'Accept',
    message: 'Confirm you want to Approve this post?'
  },
  {
    action: 'remove_post',
    icon: 'close',
    title: 'Reject',
    message: 'Confirm you want to Reject this post?'
  },
  {
    action: 'approve_user',
    icon: 'check',
    title: 'Whitelist',
    message: 'Confirm you want to Approve this Account?  They will be able to post without moderation.',
    forAccount: true,
  },
  {
    action: 'remove_user',
    icon: 'lock-filled',
    title: 'Kick',
    message: 'Confirm you want to Remove this Account from the group?',
    forAccount: true,
  },
  {
    action: 'report_user',
    icon: 'error',
    title: 'Report',
    message: 'Confirm you want to Report this Account to Gab?  They will be removed from the group.',
    forAccount: true,
  },
]

/**
 * frm contains { statusId, groupId, action } and it's sent to:
 * app/controllers/api/v1/groups/moderation_controller.rb
 */
 export const respondModerationRequest = frm => (dispatch, getState) => {
  const { groupId, statusId, action } = frm
  const pathname = `/api/v1/groups/${groupId}/moderation/${action}`
  const timelineId = `group_moderation:${groupId}`
  api(getState).post(pathname, { statusId }).then(({ data }) => {
    dispatch(timelineStatusDelete({ timelineId, statusId }))

    // is this an account action?
    const actionInfo = groupModerationRespondOptions
      .find(item => item.action === action)
    if (!actionInfo || !actionInfo.forAccount) {
      return // not an account action
    }

    const state = getState()
    const status = state.getIn(['statuses', statusId])
    if (status === undefined) {
      return // status not found
    }

    // which account is this status from?
    const accountId = ImmutableMap.isMap(status) && status.get('account')

    if (accountId === undefined) {
      return
    }

    // remove all posts from the same user from our view after account action
    const timelineItems = state.getIn(['timelines', timelineId, 'items'])
    if (
      ImmutableList.isList(timelineItems) === false ||
      timelineItems.size === 0
    ) {
      return // missing timeline
    }

    const accountStatusIds = timelineItems.filter(function(item) {
      const status = state.getIn(['statuses', item])
      return ImmutableMap.isMap(status) && status.get('account') === accountId
    })

    accountStatusIds.toJS().forEach(
      id => dispatch(timelineStatusDelete({ timelineId, statusId: id }))
    )
  })
  .catch(err => console.error("error moderating", frm, err))
  .finally(() => dispatch(moderationStats(groupId)))
}

export const moderationStats = groupId => (dispatch, getState) =>
  api(getState).get(`/api/v1/groups/${groupId}/moderation/stats`)
    .then(({ data: stats }) => dispatch({
      type: GROUP_MODERATION_STATS,
      groupId,
      stats,
    }))
    .catch(err => console.error("group moderation stats error", err))

export const moderationMyStats = groupId => (dispatch, getState) =>
  api(getState).get(`/api/v1/groups/${groupId}/moderation/my_stats`)
    .then(({ data: stats }) => dispatch({
      type: GROUP_MODERATION_MY_STATS,
      groupId,
      stats,
    }))
    .catch(err => console.error("group moderation my stats error", err))

/**
 * 
 */
export const pinGroupStatus = (groupId, statusId) => (dispatch, getState) => {
  if (!me || !groupId || !statusId) return

  dispatch(pinGroupStatusRequest(groupId))

  api(getState).post(`/api/v1/groups/${groupId}/pin`, { statusId }).then((response) => {
    dispatch(updateStatusStats(response.data))
    dispatch(pinGroupStatusSuccess(groupId, statusId))
    dispatch(timelinePins(`group:${groupId}`, [statusId]))
  }).catch((error) => {
    dispatch(pinGroupStatusFail(groupId, statusId, error))
  })
}

const pinGroupStatusRequest = (groupId) => ({
  type: GROUP_PIN_STATUS_REQUEST,
  groupId,
})

const pinGroupStatusSuccess = (groupId, statusId) => ({
  type: GROUP_PIN_STATUS_SUCCESS,
  showToast: true,
  groupId,
  statusId,
})

const pinGroupStatusFail = (groupId, statusId, error) => ({
  type: GROUP_PIN_STATUS_FAIL,
  showToast: true,
  groupId,
  statusId,
  error,
})

/**
 * 
 */
export const unpinGroupStatus = (groupId, statusId) =>(dispatch, getState) => {
  if (!me || !groupId || !statusId) return

  dispatch(unpinGroupStatusRequest(groupId, statusId))
  dispatch(timelineStatusDelete({ timelineId: `group:${groupId}`, statusId, onlyPins: true }))

  api(getState).post(`/api/v1/groups/${groupId}/unpin`, { statusId }).then((response) => {
    dispatch(updateStatusStats(response.data))
    dispatch(unpinGroupStatusSuccess(groupId, statusId))
  }).catch((error) => {
    dispatch(unpinGroupStatusFail(groupId, statusId, error))
  })
}

const unpinGroupStatusRequest = (groupId, statusId) => ({
  type: GROUP_UNPIN_STATUS_REQUEST,
  groupId,
  statusId,
})

const unpinGroupStatusSuccess = (groupId, statusId) => ({
  type: GROUP_UNPIN_STATUS_SUCCESS,
  showToast: true,
  groupId,
  statusId,
})

const unpinGroupStatusFail = (groupId, statusId, error) => ({
  type: GROUP_UNPIN_STATUS_FAIL,
  showToast: true,
  groupId,
  statusId,
  error,
})


/**
 * 
 */
export const isPinnedGroupStatus = (groupId, statusId) => (dispatch, getState) => {
  if (!me || !groupId || !statusId) return

  dispatch(isPinnedGroupStatusRequest(groupId, statusId))

  api(getState).get(`/api/v1/groups/${groupId}/pin?statusId=${statusId}`).then((response) => {
    dispatch(updateStatusStats(response.data))
  }).catch((error) => {
    dispatch(isPinnedGroupStatusFail(groupId, statusId, error))
  })
}

const isPinnedGroupStatusRequest = (groupId, statusId) => ({
  type: IS_PINNED_GROUP_STATUS_REQUEST,
  groupId,
  statusId,
})

const isPinnedGroupStatusSuccess = (groupId, statusId) => ({
  type: IS_PINNED_GROUP_STATUS_SUCCESS,
  groupId,
  statusId,
})

const isPinnedGroupStatusFail = (groupId, statusId, error) => ({
  type: IS_PINNED_GROUP_STATUS_FAIL,
  groupId,
  statusId,
  error,
})

/**
 * 
 */
export const sortGroups = (tab, sortType) => (dispatch, getState) => {
  const groupIdsByTab = getState().getIn(['group_lists', tab, 'items'], ImmutableList()).toJS()
  const allGroups = getState().get('groups', ImmutableMap()).toJS()

  let groupsByTab = []
  
  for (const key in allGroups) {
    const block = allGroups[key]
    if (groupIdsByTab.indexOf(block.id > -1)) {
      groupsByTab.push(block)
    }
  }

  if (sortType === GROUP_LIST_SORTING_TYPE_ALPHABETICAL) {
    groupsByTab.sort((a, b) => a.title.localeCompare(b.title))
  } else if (sortType === GROUP_LIST_SORTING_TYPE_MOST_POPULAR) {
    groupsByTab.sort((a, b) => (a.member_count < b.member_count) ? 1 : -1)
  }

  const sortedGroupsIdsByTab = groupsByTab.map((group) => group.id)

  dispatch(groupsSort(tab, sortedGroupsIdsByTab))
}

export const groupsSort = (tab, groupIds) =>({
  type: GROUP_SORT,
  tab,
  groupIds,
})

export const setGroupTimelineSort = (sortValue) => (dispatch) => {
  dispatch({
    type: GROUP_TIMELINE_SORT,
    sortValue,
  })
}

export const setGroupTimelineTopSort = (sortValue) => (dispatch) => {
  dispatch({
    type: GROUP_TIMELINE_TOP_SORT,
    sortValue,
  })
}

/* Block Group functionality */
export const blockGroup = (groupId) => (dispatch, getState) => {
  if (!me || !groupId) return

  dispatch(blockGroupRequest(groupId))

  api(getState).post(`/api/v1/groups/${groupId}/block`).then((response) => {
    dispatch(blockGroupSuccess(groupId))
    appendIsBlockingGroupId(groupId)
  }).catch((error) => {
    dispatch(blockGroupFail(groupId, error))
  })
}

export const unblockGroup = (groupId) => (dispatch, getState) => {
  if (!me || !groupId) return

  dispatch(unblockGroupRequest(groupId))

  api(getState).post(`/api/v1/groups/${groupId}/unblock`).then((response) => {
    dispatch(unblockGroupSuccess(groupId))
    removeIsBlockingGroupId(groupId)
  }).catch((error) => {
    dispatch(unblockGroupFail(groupId, error))
  })
}

const blockGroupRequest = (groupId) => ({
  type: GROUP_MUTE_REQUEST,
  groupId,
})

const blockGroupSuccess = (groupId) => ({
  type: GROUP_MUTE_SUCCESS,
  showToast: true,
  groupId,
})

const blockGroupFail = (groupId, error) => ({
  type: GROUP_MUTE_FAIL,
  showToast: true,
  groupId,
  error,
})

const unblockGroupRequest = (groupId) => ({
  type: GROUP_UNMUTE_REQUEST,
  groupId,
})

const unblockGroupSuccess = (groupId) => ({
  type: GROUP_UNMUTE_SUCCESS,
  showToast: true,
  groupId,
})

const unblockGroupFail = (groupId, error) => ({
  type: GROUP_UNMUTE_FAIL,
  showToast: true,
  groupId,
  error,
})
