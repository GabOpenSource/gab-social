import { me } from '../initial_state'
import api from '../api'

export const SHORTCUTS_FETCH_REQUEST = 'SHORTCUTS_FETCH_REQUEST'
export const SHORTCUTS_FETCH_SUCCESS = 'SHORTCUTS_FETCH_SUCCESS'
export const SHORTCUTS_FETCH_FAIL    = 'SHORTCUTS_FETCH_FAIL'

export const SHORTCUTS_ADD_REQUEST = 'SHORTCUTS_ADD_REQUEST'
export const SHORTCUTS_ADD_SUCCESS = 'SHORTCUTS_ADD_SUCCESS'
export const SHORTCUTS_ADD_FAIL    = 'SHORTCUTS_ADD_FAIL'

export const SHORTCUTS_REMOVE_REQUEST = 'SHORTCUTS_REMOVE_REQUEST'
export const SHORTCUTS_REMOVE_SUCCESS = 'SHORTCUTS_REMOVE_SUCCESS'
export const SHORTCUTS_REMOVE_FAIL    = 'SHORTCUTS_REMOVE_FAIL'

export const SHORTCUTS_CLEAR_COUNT_REQUEST = 'SHORTCUTS_CLEAR_COUNT_REQUEST'
export const SHORTCUTS_CLEAR_COUNT_SUCCESS = 'SHORTCUTS_CLEAR_COUNT_SUCCESS'
export const SHORTCUTS_CLEAR_COUNT_FAIL    = 'SHORTCUTS_CLEAR_COUNT_FAIL'

export const SHORTCUTS_SET_ORDER_REQUEST = 'SHORTCUTS_SET_ORDER_REQUEST'
export const SHORTCUTS_SET_ORDER_SUCCESS = 'SHORTCUTS_SET_ORDER_SUCCESS'
export const SHORTCUTS_SET_ORDER_FAIL    = 'SHORTCUTS_SET_ORDER_FAIL'

/**
 * 
 */
export const fetchShortcuts = () => (dispatch, getState) => {
  if (!me) return
  
  const isFetched = getState().getIn(['shortcuts', 'isFetched'], false)
  if (isFetched) return

  const CACHE_KEY = `gabsocial_shortcuts_cache_${me}`
  const CACHE_EXPIRY = 1000 * 60 * 5 // 5 minutes

  // Try to get cached shortcuts
  try {
    const cached = localStorage.getItem(CACHE_KEY)
    if (cached) {
      const { data, timestamp } = JSON.parse(cached)
      
      // Use cache if not expired
      if (Date.now() - timestamp <= CACHE_EXPIRY) {
        dispatch(fetchShortcutsSuccess(data))
        return
      }
      localStorage.removeItem(CACHE_KEY)
    }
  } catch (e) {
    console.warn('Error reading shortcuts cache:', e)
  }

  dispatch(fetchShortcutsRequest())

  api(getState).get('/api/v1/shortcuts').then(response => {
    // Cache the new data
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify({
        data: response.data,
        timestamp: Date.now()
      }))
    } catch (e) {
      console.warn('Error writing to shortcuts cache:', e)
    }
    
    dispatch(fetchShortcutsSuccess(response.data))
  }).catch(error => dispatch(fetchShortcutsFail(error)))
}

const fetchShortcutsRequest = () => ({
  type: SHORTCUTS_FETCH_REQUEST,
})

const fetchShortcutsSuccess = (shortcuts) => ({
  type: SHORTCUTS_FETCH_SUCCESS,
  shortcuts,
})

const fetchShortcutsFail = (error) => ({
  type: SHORTCUTS_FETCH_FAIL,
  error,
})

/**
 * 
 */
export const addShortcut = (shortcutType, shortcutId) => (dispatch, getState) => {
  if (!me) return

  dispatch(addShortcutsRequest())

  api(getState).post('/api/v1/shortcuts', {
    shortcut_type: shortcutType,
    shortcut_id: shortcutId,
  }).then(response => {
    dispatch(addShortcutsSuccess(response.data))
  }).catch(error => dispatch(addShortcutsFail(error)))
}

const addShortcutsRequest = () => ({
  type: SHORTCUTS_ADD_REQUEST,
})

const addShortcutsSuccess = (shortcut) => ({
  type: SHORTCUTS_ADD_SUCCESS,
  showToast: true,
  shortcut,
})

const addShortcutsFail = (error) => ({
  type: SHORTCUTS_ADD_FAIL,
  showToast: true,
  error,
})

/**
 * 
 */
export const removeShortcut = (shortcutObjectId, shortcutType, shortcutId) => (dispatch, getState) => {
  if (!me) return
  
  let id
  if (shortcutObjectId) {
    id = shortcutObjectId
  } else if (shortcutType && shortcutId) {
    const shortcuts = getState().getIn(['shortcuts', 'items'])
    const shortcut = shortcuts.find((s) => {
      return s.get('shortcut_id') == shortcutId && s.get('shortcut_type') === shortcutType
    })
    if (!!shortcut) {
      id = shortcut.get('id')
    }
  }

  if (!id) return

  dispatch(removeShortcutsRequest())

  api(getState).delete(`/api/v1/shortcuts/${id}`).then(response => {
    dispatch(removeShortcutsSuccess(response.data.id))
  }).catch(error => dispatch(removeShortcutsFail(error)))
}

const removeShortcutsRequest = () => ({
  type: SHORTCUTS_REMOVE_REQUEST,
})

const removeShortcutsSuccess = (shortcutId) => ({
  type: SHORTCUTS_REMOVE_SUCCESS,
  showToast: true,
  shortcutId,
})

const removeShortcutsFail = (error) => ({
  type: SHORTCUTS_REMOVE_FAIL,
  showToast: true,
  error,
})

/**
 * 
 */
export const setShortcutsOrder = (shortcuts) => (dispatch, getState) => {
  if (!me || !shortcuts) return

  const orderedShortcuts = shortcuts.toJS().map((s, i) => ({
    id: s.id,
    order: i,
  }))

  dispatch(setShortcutsOrderRequest(shortcuts))

  api(getState).post(`/api/v1/shortcuts/reorder`, { shortcuts: orderedShortcuts }).then(() => {
    dispatch(setShortcutsOrderSuccess())
  }).catch(() => dispatch(setShortcutsOrderFail()))
}

const setShortcutsOrderRequest = (shortcuts) => ({
  type: SHORTCUTS_SET_ORDER_REQUEST,
  shortcuts,
})

const setShortcutsOrderSuccess = () => ({
  type: SHORTCUTS_SET_ORDER_SUCCESS,
})

const setShortcutsOrderFail = () => ({
  type: SHORTCUTS_SET_ORDER_FAIL,
})

/**
 * 
 */
 export const clearShortcutCount = (shortcutObjectId) => (dispatch, getState) => {
  if (!me || !shortcutObjectId) return

  dispatch(clearShortcutCountRequest(shortcutObjectId))

  api(getState).post(`/api/v1/shortcuts/${shortcutObjectId}/clear_count`).then(() => {
    dispatch(clearShortcutCountSuccess())
  }).catch(() => dispatch(clearShortcutCountFail()))
}

const clearShortcutCountRequest = (shortcutId) => ({
  type: SHORTCUTS_CLEAR_COUNT_REQUEST,
  shortcutId,
})

const clearShortcutCountSuccess = () => ({
  type: SHORTCUTS_CLEAR_COUNT_SUCCESS,
})

const clearShortcutCountFail = () => ({
  type: SHORTCUTS_CLEAR_COUNT_FAIL,
})

// 
export const clearShortcutCountByTimelineId = (timelineId) => (dispatch, getState) => {
  if (!me || !timelineId) return

  // destructure
  const splits = timelineId.toLowerCase().split(':')
  if (!Array.isArray(splits) || splits.length !== 2) return
  
  let entityType = splits[0]
  const entityId = splits[1]

  // name correction
  if (entityType === 'hashtag') entityType = 'tag'

  const shortcuts = getState().getIn(['shortcuts', 'items'])
  const foundShortcut = shortcuts.find((s) => {
    return `${s.get('shortcut_id')}`.toLowerCase() == entityId && s.get('shortcut_type').toLowerCase() === entityType
  })

  // clear if found and has unread_count
  if (foundShortcut && foundShortcut.get('unread_count') > 0) {
    dispatch(clearShortcutCount(foundShortcut.get('id')))
  } 
}