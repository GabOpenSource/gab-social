import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { makeGetAccount } from '../../selectors'
import { blockAccount } from '../../actions/accounts'
import ConfirmationModal from './confirmation_modal'

class BlockAccountModal extends React.PureComponent {

  handleClick = () => {
    this.props.onConfirm(this.props.account)
  }

  render() {
    const { account, onClose } = this.props

    const name = !!account ? account.get('acct') : ''
    const title = `Block ${name}`
    const message = `Are you sure you want to block ${name}?`

    return (
      <ConfirmationModal
        title={title}
        message={message}
        confirm='Block'
        onConfirm={this.handleClick}
        onClose={onClose}
      />
    )
  }

}

const mapStateToProps = (state, { accountId }) => ({
  account: makeGetAccount()(state, accountId),
})

const mapDispatchToProps = (dispatch) => ({
  onConfirm(account) {
    dispatch(blockAccount(account.get('id')))
  },
})

BlockAccountModal.propTypes = {
  account: PropTypes.object.isRequired,
  onConfirm: PropTypes.func.isRequired,
  onClose: PropTypes.func.isRequired,
}

export default connect(mapStateToProps, mapDispatchToProps)(BlockAccountModal)