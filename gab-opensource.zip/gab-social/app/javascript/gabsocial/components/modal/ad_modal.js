import React from 'react'
import PropTypes from 'prop-types'
import ModalLayout from './modal_layout'
import { GAB_AD_PLACEMENTS } from '../../constants'
import { isPro, me } from '../../initial_state'
import { GabAdStatus } from '../../features/ui/util/async_components'
import WrappedBundle from '../../features/ui/util/wrapped_bundle'
import { isMobile, getWindowDimension } from '../../utils/is_mobile'

class AdModal extends React.PureComponent {
  
  render() {
    const { onClose } = this.props
    const { width } = getWindowDimension()
    const is_mobile = isMobile(width)
    if (isPro) return <div />;

    const title = (
      <span className={[_s.d, _s.flexRow, _s.jcCenter, _s.aiCenter].join(' ')}>
        <span className={[_s.d, _s.mr2].join(' ')}>
          Sponsored
        </span>
      </span>
    )

    return (
      <ModalLayout
        noPadding
        title={title}
        width={is_mobile ? 500 : 420}
        onClose={onClose}
      >
        <WrappedBundle
            key={`gab-ad-status-modal`}
            component={GabAdStatus}
            componentParams={{
            pageKey: 'interstitial',
            position: 1,
            adModalClose: onClose,
            }}
        />
      </ModalLayout>
    )
  }

}

AdModal.propTypes = {
  onClose: PropTypes.func.isRequired,
}

export default AdModal
