import React from 'react'
import PropTypes from 'prop-types'
import ConfirmationModal from './confirmation_modal'

class BundleErrorModal extends React.PureComponent {

  handleRetry = () => {
    this.props.onRetry()
  }

  render () {
    const { onClose  } = this.props

    return (
      <ConfirmationModal
        title='Error'
        message='Something went wrong while loading this component.'
        confirm='Try again'
        onConfirm={this.handleRetry}
        onClose={onClose}
      />
    )
  }

}

BundleErrorModal.propTypes = {
  onClose: PropTypes.func.isRequired,
}

export default BundleErrorModal