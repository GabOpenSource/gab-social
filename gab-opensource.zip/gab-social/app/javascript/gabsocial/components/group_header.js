import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import ImmutablePropTypes from 'react-immutable-proptypes'
import ImmutablePureComponent from 'react-immutable-pure-component'
import Sticky from 'react-stickynode'
import { openPopover } from '../actions/popover'
import { showToast } from '../actions/toasts'
import {
  addShortcut,
  removeShortcut,
} from '../actions/shortcuts'
import {
  PLACEHOLDER_MISSING_HEADER_SRC,
  BREAKPOINT_EXTRA_SMALL,
  TOAST_TYPE_SUCCESS,
} from '../constants'
import { me } from '../initial_state'
import Responsive from '../features/ui/util/responsive_component'
import GroupActionButton from './group_action_button'
import Button from './button'
import Image from './image'
import Icon from './icon'
import TabBar from './tab_bar'
import Pills from './pills'
import Text from './text'
import Badge from './badge'

class GroupHeader extends ImmutablePureComponent {

  state = {
    stickied: false,
  }

  onStickyStateChange = (status) => {
    if (status.status === Sticky.STATUS_FIXED) {
      this.setState({ stickied: true })
    } else {
      this.setState({ stickied: false })
    }
  }

  handleOnOpenGroupOptions = () => {
    const { relationships } = this.props
    const isAdmin = !!relationships ? relationships.get('admin') : false
    const isModerator = !!relationships ? relationships.get('moderator') : false
    const isMember = !!relationships ? relationships.get('member') || isAdmin || isModerator : false
    this.props.onOpenGroupOptions(this.infoBtn, this.props.group, {
      isAdmin,
      isModerator,
      isMember,
    })
  }

  handleToggleShortcut = () => {
    const { group, isShortcut } = this.props
    const groupId = !!group ? group.get('id') : null
    
    if (!groupId) return

    if (isShortcut) {
      this.props.onRemoveShortcut(groupId)
    } else {
      this.props.onAddShortcut(groupId)
    }
  }

  handleCopySlug = () => {
    const { group } = this.props
    const url = !!group ? !!group.get('slug') ? `https://gab.com/g/${group.get('slug')}` : undefined : undefined
    if (!url) return
    
    const textarea = document.createElement('textarea')

    textarea.textContent = url
    textarea.style.position = 'fixed'

    document.body.appendChild(textarea)

    try {
      textarea.select()
      document.execCommand('copy')
    } catch (e) {
      //
    }

    document.body.removeChild(textarea)
    this.props.onShowCopyToast()
  }
 
  setInfoBtn = (c) => {
    this.infoBtn = c;
  }

  render() {
    const {
      children,
      group,
      isXS,
      isShortcut,
      relationships,
      moderationCount,
      requestsCount,
      isSmall,
    } = this.props
    const { stickied } = this.state

    const coverSrc = !!group ? group.get('cover_image_url') : ''
    const coverSrcMissing = coverSrc.indexOf(PLACEHOLDER_MISSING_HEADER_SRC) > -1 || !coverSrc
    const title = !!group ? group.get('title') : undefined
    const isVerified = !!group ? group.get('is_verified') : undefined
    const slug = !!group ? !!group.get('slug') ? `g/${group.get('slug')}` : undefined : undefined
    const isPrivate = !!group ? group.get('is_private') : false
    const isAdminOrMod = !!relationships ? (relationships.get('admin') || relationships.get('moderator')) : false
    const isModerated = !!group ? group.get('is_moderated') : undefined
    const isMediaEnabled = !!group ? group.get('is_media_visible') : undefined
    const isMembersVisible = !!group ? group.get('is_members_visible') : undefined
    const isAdminsVisible = !!group ? group.get('is_admins_visible') : undefined
    const isLinksEnabled = !!group ? group.get('is_links_visible') : undefined
    // const isChatEnabled = true // !!group ? group.get('is_chat_visible') : undefined

    const tabs = !group ? [] : [
      {
        to: `/groups/${group.get('id')}`,
        title: 'Timeline',
      },
    ]

    if ((isMembersVisible || isAdminsVisible) || isAdminOrMod && group) {
      tabs.push({
        to: `/groups/${group.get('id')}/members`,
        title: 'Members',
      })
    }

    if (isAdminOrMod && group && isPrivate) {
      const count = requestsCount > 9 ? '9+' : requestsCount
      const requestsTitle = requestsCount > 0 ?
        <>
          Requests
          <Badge text={count} className={isXS ? _s.ml10 : [_s.posAbs, _s.topNeg15PX, _s.rightNeg20PX].join(' ')} />
        </> :
        'Requests'
      tabs.push({
        to: `/groups/${group.get('id')}/requests`,
        title: requestsTitle,
      }) 
    }

    if (isAdminOrMod && group && isModerated) {
      const count = moderationCount > 9 ? '9+' : moderationCount
      const moderationTitle = moderationCount > 0 ?
        <>
          Moderation
          <Badge text={count} className={isXS ? _s.ml10 : [_s.posAbs, _s.topNeg15PX, _s.rightNeg20PX].join(' ')} />
        </> :
        'Moderation'
      tabs.push({
        to: `/groups/${group.get('id')}/moderation`,
        title: moderationTitle,
      }) 
    }

    if ((isXS || isSmall) && group) {
      tabs.push({
        to: `/groups/${group.get('id')}/about`,
        title: 'About',
      })
    }

    if (isMediaEnabled && group) {
      tabs.push({
        to: `/groups/${group.get('id')}/media`,
        title: 'Media',
      }) 
    }

    if (isLinksEnabled && group) {
      tabs.push({
        to: `/groups/${group.get('id')}/links`,
        title: 'Links',
      }) 
    }

    // if (isChatEnabled && group) {
    //   tabs.push({
    //     to: `/groups/${group.get('id')}/chat`,
    //     title: 'Chat',
    //   }) 
    // }

    const headerHeight = isXS ? '200px' : isSmall ? '320px' : '460px'
    let top = isSmall ? -320 : -460

    return (
      <div className={[_s.d, _s.z1, _s.w100PC, _s.mb15].join(' ')}>
        <Responsive max={BREAKPOINT_EXTRA_SMALL}>
          <div className={[_s.d, _s.boxShadowBlock, _s.bgPrimary].join(' ')}>
            <div className={[_s.d, _s.w100PC].join(' ')}>

              {
                coverSrc && !coverSrcMissing &&
                <Image cfWidthPX='992px' className={_s.h200PX} src={coverSrc} alt={title} expandOnClick />
              }

              <div className={[_s.d, _s.w100PC].join(' ')}>

                <div className={[_s.d, _s.w100PC, _s.px15, _s.mt10, _s.py10].join(' ')}>
                  {children}
                </div>

                {
                  !!me &&
                  <div className={[_s.d, _s.flexRow, _s.aiCenter, _s.mt5, _s.mb5, _s.pb15, _s.pt5, _s.h100PC, _s.borderBottom1PX, _s.borderColorSecondary, _s.px15].join(' ')}>
                    <GroupActionButton
                      group={group}
                      relationships={relationships}
                    />
                    <Button
                      radiusSmall
                      iconSize='18px'
                      color='brand'
                      backgroundColor='none'
                      className={[_s.ml10, _s.px10].join(' ')}
                      icon={isShortcut ? 'star' : 'star-outline'}
                      onClick={this.handleToggleShortcut}
                    />
                  </div>
                }

                <div className={[_s.d, _s.flexRow, _s.h100PC, _s.mt5, _s.pt10, _s.pb10, _s.mb5, _s.w100PC].join(' ')}>
                  <Pills pills={tabs} />
                </div>
              </div>
            </div>
          </div>
        </Responsive>

        { /** desktop */}
        <Responsive min={BREAKPOINT_EXTRA_SMALL}>
          <Sticky top={top} enabled onStateChange={this.onStickyStateChange}>
            <div className={[_s.d, _s.boxShadowBlock, _s.bgPrimary].join(' ')}>
              <div className={[_s.d, _s.w100PC].join(' ')}>

                {
                  coverSrc && !coverSrcMissing &&
                  <Image cfWidthPX='1440px' height={headerHeight} src={coverSrc} alt={title} expandOnClick />
                }
                
                <div className={[_s.d].join(' ')}>
                  <div className={[_s.d, _s.flexRow, _s.py10, _s.px10].join(' ')}>
                    <div className={[_s.d, _s.w100PC].join(' ')}>
                      <div className={[_s.d, _s.flexRow].join(' ')}>
                        <div className={[_s.d, _s.ml7, _s.flexNormal, _s.overflowHidden].join(' ')}>
                          <div className={[_s.d, _s.flexRow, _s.aiCenter].join(' ')}>
                            <h1 className={[_s.displayBlock, _s.font, _s.mt5, _s.mb5, _s.fw600, _s.fs24PX, _s.text, _s.cPrimary, _s.wrap].join(' ')}>
                              {title}
                            </h1>
                            {isVerified && <Icon id='verified-group' size='22px' className={_s.ml7} />}
                          </div>
                          {
                            !!slug && !stickied &&
                            <Button
                              noClasses
                              target='_blank'
                              onClick={this.handleCopySlug}
                              className={[_s.d, _s.flexRow, _s.mt5, _s.cursorPointer, _s.outlineNone, _s.bgTransparent, _s.inherit].join(' ')}
                            >
                              <Text color='secondary' size='medium' weight='medium'>
                                {slug}
                              </Text>
                            </Button>
                          }
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={[_s.d, _s.h53PX, _s.w100PC].join(' ')}>
                    <div className={[_s.d, _s.flexRow, _s.h100PC, _s.pl5, _s.pr15].join(' ')}>
                      
                      <TabBar tabs={tabs} isLarge />

                      <div className={[_s.d, _s.flexRow, _s.aiCenter, _s.h100PC, _s.mlAuto].join(' ')}>
                        {
                          !!me &&
                          <div className={[_s.d, _s.flexRow, _s.jcCenter, _s.aiCenter].join(' ')}>
                            <Button
                              radiusSmall
                              iconSize='18px'
                              color='brand'
                              backgroundColor='none'
                              className={[_s.mr10, _s.px10].join(' ')}
                              icon={isShortcut ? 'star' : 'star-outline'}
                              onClick={this.handleToggleShortcut}
                            />
                            <Button
                              radiusSmall
                              color='primary'
                              backgroundColor='tertiary'
                              className={[_s.mr10, _s.px10].join(' ')}
                              title='More options'
                              icon='ellipsis'
                              iconSize='19px'
                              onClick={this.handleOnOpenGroupOptions}
                              buttonRef={this.setInfoBtn}
                            />
                            {/* <Button
                              radiusSmall
                              color='primary'
                              backgroundColor='tertiary'
                              className={[_s.mr10, _s.px10].join(' ')}
                              icon='search'
                              onClick={this.handleOnOpenGroupOptions}
                              buttonRef={this.setInfoBtn}
                            /> */}
                          </div>
                        }  

                        <GroupActionButton
                          group={group}
                          relationships={relationships}
                        />

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Sticky>
        </Responsive>
      </div>
    )
  }

}

const mapStateToProps = (state, { group }) => {
  const groupId = group ? group.get('id') : null
  const shortcuts = state.getIn(['shortcuts', 'items'])
  const isShortcut = !!shortcuts.find((s) => {
    return s.get('shortcut_id') == groupId && s.get('shortcut_type') === 'group'
  })
  return { isShortcut }
}

const mapDispatchToProps = (dispatch) => ({

  onOpenGroupOptions(targetRef, group, options) {
    dispatch(openPopover('GROUP_OPTIONS', {
      targetRef,
      group,
      ...options,
      position: 'left',
    }))
  },
  onAddShortcut(groupId) {
    dispatch(addShortcut('group', groupId))
  },
  onRemoveShortcut(groupId) {
    dispatch(removeShortcut(null, 'group', groupId))
  },
  onShowCopyToast() {
    dispatch(showToast(TOAST_TYPE_SUCCESS, {
      type: "SUCCESSFULLY_COPIED_TO_CLIPBOARD"
    }))
  },

})

GroupHeader.propTypes = {
  group: ImmutablePropTypes.map,
  children: PropTypes.any,
  isShortcut: PropTypes.bool.isRequired,
  isXS: PropTypes.bool,
  onAddShortcut: PropTypes.func.isRequired,
  onRemoveShortcut: PropTypes.func.isRequired,
  onOpenGroupOptions: PropTypes.func.isRequired,
  relationships: ImmutablePropTypes.map,
  moderationCount: PropTypes.number,
  requestsCount: PropTypes.number,
}

export default connect(mapStateToProps, mapDispatchToProps)(GroupHeader)
