# frozen_string_literal: true
class RisingQueryBuilder < BaseService

  RISINGQUERY=<<-SQL
    WITH status_rank AS (
      SELECT 
        s.*,
        ROW_NUMBER() OVER (PARTITION BY s.account_id ORDER BY s.id DESC) as rank
      FROM statuses s
      JOIN accounts a ON s.account_id = a.id
      JOIN status_stats ss ON s.id = ss.status_id
      JOIN account_stats sa ON a.id = sa.account_id
      WHERE s.created_at > now() - interval '4 hours'
      AND s.in_reply_to_id is null
      AND s.visibility = 0
      AND ss.favourites_count > 9
      AND s.reblog_of_id is null
      AND a.suspended_at is null
      AND a.spam_flag is null
      AND sa.followers_count < 2500
      and (:max_id is null or s.id < :max_id)
      and (:min_id is null or s.id > :min_id)
      and s.group_id is null 
    )
    SELECT 
      sr.*
    FROM status_rank sr
    WHERE sr.rank = 1 
    ORDER BY sr.id DESC limit :limit
  SQL

  GROUPRISINGQUERY=<<-SQL
    WITH status_rank AS (
      SELECT 
        s.*,
        ROW_NUMBER() OVER (PARTITION BY s.account_id ORDER BY s.id DESC) as rank
      FROM statuses s
      JOIN accounts a ON s.account_id = a.id
      JOIN status_stats ss ON s.id = ss.status_id
      JOIN account_stats sa ON a.id = sa.account_id
      WHERE s.created_at > now() - interval '4 hours'
      AND s.in_reply_to_id is null
      AND s.visibility = 0
      AND ss.favourites_count > 9
      AND s.reblog_of_id is null
      AND a.suspended_at is null
      AND a.spam_flag is null
      AND sa.followers_count < 2500
      and (:max_id is null or s.id < :max_id)
      and (:min_id is null or s.id > :min_id)
      and s.group_id in (:group_ids)
    )
    SELECT 
      sr.*
    FROM status_rank sr
    WHERE sr.rank = 1 
    ORDER BY sr.id DESC limit :limit
  SQL
  

  def call(limit = 20, max_id = nil, min_id = nil, group_ids = nil)
    opts = { limit: limit, min_id: min_id, max_id: max_id, group_ids: group_ids }
    ActiveRecord::Base.connected_to(role: :reading) do
      if group_ids.nil?
        Status.find_by_sql([RISINGQUERY, opts])
      else
        Status.find_by_sql([GROUPRISINGQUERY, opts])
      end
    end
  end

end
