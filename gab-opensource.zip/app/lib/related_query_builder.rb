# frozen_string_literal: true
class RelatedQueryBuilder < BaseService

  def call(status_id, account_id=nil)
    return [] if status_id.nil?

    related_status = Status.find(status_id)
    group_id = related_status.group_id
    sanitized_text = ActiveRecord::Base.sanitize_sql_like(related_status.text)

    result = Status.popular_accounts.with_public_visibility.without_reblogs.without_replies
      .joins(:account, :status_stat, account: :account_stat)
      .where(accounts: { suspended_at: nil, spam_flag: nil })
      .where("status_stats.favourites_count > ?", 5)
      .where("account_stats.followers_count > ?", 25)
      .where("statuses.id != ?", status_id)
      .where("statuses.id > 110129264410182713")
      #.where("statuses.id > ?", GabSocial::Snowflake.id_at(1.month.ago))
      #.where("statuses.created_at > ?", "2023-03-27 12:05:29.847201")    
      
    if !account_id.nil?
      result = result.where("statuses.account_id != ?", account_id)
    end
    if !group_id.nil?
      result = result.where(group_id: group_id)
    end
  
    return result
  end

end
