class MarketplaceListingAttributes

  UNIQUE_KEYS = {
    attrs: [
      :gender,
      :age,
      :type,
      :is_handmade,
      :author,
      :isbn,
      :age_group,
      :grade_level,
      :position_title,
      :position_type,
      :pay_structure,
      :is_remote,
      :responsibilities,
      :sector,
      :bedrooms,
      :bathrooms,
      :sale_type,
      :sq_ft,
      :place_type,
      :lot_size,
      :age_range,
      :year,
      :make,
      :model,
      :mileage,
      :ext_color,
      :int_color,
      :body_style,
      :fuel_type,
      :transmission,
      :clean_title,
      :brand,
      :color
    ]
  }.freeze
  
  ATTRIBUTES = {

    apparel: [
      {
        key: 'gender',
        title: 'Gender',
        type: 'select',
        options: [
          {
            value: 'male',
            title: 'Male',
          },
          {
            value: 'female',
            title: 'Female',
          },
          {
            value: 'both',
            title: 'Both',
          }
        ]
      },
      {
        key: 'age',
        title: 'Age',
        type: 'select',
        options: [
          {
            value: 'baby',
            title: 'Baby',
          },
          {
            value: 'kid',
            title: 'Kid',
          },
          {
            value: 'adult',
            title: 'Adult',
          },
        ]
      },
    ],

    arts_crafts: [
      {
        key: 'type',
        title: 'Type',
        type: 'select',
        options: [
          {
            value: 'drawing_illustration',
            title: 'Drawing & Illustration',
          },
          {
            value: 'painting',
            title: 'Painting',
          },
          {
            value: 'sewing_textiles',
            title: 'Sewing & Textiles',
          },
          {
            value: 'beading_jewelry_making',
            title: 'Beading & Jewelry Making',
          },
          {
            value: 'scrapbooking_paper_crafts',
            title: 'Scrapbooking & Paper Crafts',
          },
          {
            value: 'knitting_crochet',
            title: 'Knitting & Crochet',
          },
          {
            value: 'pottery_ceramics',
            title: 'Pottery & Ceramics',
          },
          {
            value: 'craft_supplies',
            title: 'Craft Supplies',
          }
        ]
      },
      {
        key: 'is_handmade',
        title: 'Handmade',
        type: 'boolean',
      }
    ],

    books: [
      {
        key: 'author',
        title: 'Author',
        type: 'input'
      },
      {
        key: 'isbn',
        title: 'ISBN',
        type: 'input'
      },
      {
        key: 'age_group',
        title: 'Age Group',
        type: 'select',
        options: [
          {
            value: 'all',
            title: 'All',
          },
          {
            value: 'children',
            title: 'Children (0-12)'
          },
          {
            value: 'teen',
            title: 'Teens (13-17)'
          },
          {
            value: 'adult',
            title: 'Adults (18+)'
          }
        ]
      }
    ],

    homeschooling_materials: [
      {
        key: 'grade_level',
        title: 'Grade Level',
        type: 'multiple',
        options: [
          {
            value: 'pre-k',
            title: 'Pre-K',
          },
          {
            value: 'elementary',
            title: 'Elementary (K-5)',
          },
          {
            value: 'middle_school',
            title: 'Middle School (6-8)',
          },
          {
            value: 'high_school',
            title: 'High School (9-12)',
          }
        ]
      }
    ],

    food: [
      {
        key: 'type',
        title: 'Type',
        type: 'select',
        options: [
          {
            value: 'fresh_produce',
            title: 'Fresh Produce',
          },
          {
            value: 'packaged_goods',
            title: 'Packaged Goods',
          },
          {
            value: 'beverages',
            title: 'Beverages',
          },
          {
            value: 'dairy_eggs',
            title: 'Dairy & Eggs',
          },
          {
            value: 'meat_poultry',
            title: 'Meat & Poultry',
          },
          {
            value: 'seafood',
            title: 'Seafood',
          },
          {
            value: 'baked_goods',
            title: 'Baked Goods',
          },
          {
            value: 'specialty_foods',
            title: 'Specialty Foods',
          },
          {
            value: 'homemade_artisanal',
            title: 'Homemade/Artisanal',
          }
        ]
      },
      {
        key: 'features',
        title: 'Features',
        type: 'multiple',
        options: [
          { value: 'non_gmo', title: 'Non-GMO' },
          { value: 'gluten_free', title: 'Gluten-Free' },
          { value: 'no_preservatives', title: 'No Preservatives' },
          { value: 'organic_certified', title: 'Organic Certified' },
          { value: 'vegan', title: 'Vegan' },
          { value: 'vegetarian', title: 'Vegetarian' },
          { value: 'dairy_free', title: 'Dairy-Free' },
          { value: 'nut_free', title: 'Nut-Free' },
          { value: 'soy_free', title: 'Soy-Free' },
          { value: 'sugar_free', title: 'Sugar-Free' },
          { value: 'low_calorie', title: 'Low-Calorie' },
          { value: 'keto_friendly', title: 'Keto-Friendly' },
          { value: 'paleo_friendly', title: 'Paleo-Friendly' },
          { value: 'grass_fed', title: 'Grass-Fed' },
          { value: 'free_range_cage_free', title: 'Free-Range/Cage-Free' },
          { value: 'no_artificial_colors_flavors', title: 'No Artificial Colors/Flavors' },
          { value: 'high_in_protein', title: 'High in Protein' },
          { value: 'high_in_fiber', title: 'High in Fiber' },
          { value: 'whole_grain', title: 'Whole Grain' },
          { value: 'raw', title: 'Raw' },
          { value: 'no_added_hormones_antibiotics', title: 'No Added Hormones/Antibiotics' }
        ]
      }
    ],

    furniture: [
      {
        key: 'type',
        title: 'Type',
        type: 'select',
        options: [
          {
            value: 'sofa_chair',
            title: 'Sofa/Chair',
          },
          {
            value: 'table',
            title: 'Table',
          },
          {
            value: 'bed',
            title: 'Bed',
          },
          {
            value: 'dresser',
            title: 'Dresser',
          },
          {
            value: 'cabinet_bookshelf',
            title: 'Cabinet/Bookshelf',
          },
          {
            value: 'desk',
            title: 'Desk',
          },
          {
            value: 'wardrobe_armoire',
            title: 'Wardrobe/Armoire',
          },
          {
            value: 'outdoor_furniture',
            title: 'Outdoor Furniture',
          }
        ]
      },
      {
        key: 'material',
        title: 'Material',
        type: 'select',
        options: [
          {
            value: 'wood',
            title: 'Wood',
          },
          {
            value: 'metal',
            title: 'Metal',
          },
          {
            value: 'leather',
            title: 'Leather',
          },
          {
            value: 'glass',
            title: 'Glass',
          },
          {
            value: 'fabric',
            title: 'Fabric',
          },
          {
            value: 'plastic',
            title: 'Plastic',
          },
          {
            value: 'rattan_wicker',
            title: 'Rattan/Wicker',
          },
          {
            value: 'stone',
            title: 'Stone',
          }
        ]
      },
      {
        key: 'color',
        title: 'Color',
        type: 'color'
      }
    ],

    jobs: [
      {
        key: 'position_title',
        title: 'Position Title',
        type: 'input'
      },
      {
        key: 'position_type',
        title: 'Position Type',
        type: 'select',
        options: [
          {
            value: 'full_time',
            title: 'Full Time',
          },
          {
            value: 'part_time',
            title: 'Part Time',
          },
          {
            value: 'contractor',
            title: 'Contractor',
          },
          {
            value: 'volunteer',
            title: 'Volunteer',
          }
        ]
      },
      {
        key: 'pay_structure',
        title: 'Pay Structure',
        type: 'select',
        options: [
          {
            value: 'salary',
            title: 'Salary',
          },
          {
            value: 'hourly',
            title: 'Hourly',
          },
          {
            value: 'commission',
            title: 'Commission',
          }
        ]
      },
      {
        key: 'is_remote',
        title: 'Is Remote',
        type: 'boolean'
      },
      {
        key: 'responsibilities',
        title: 'Responsibilities',
        type: 'textarea'
      },
      {
        key: 'sector',
        title: 'Sector',
        type: 'select',
        options: [
          {
            value: 'technology',
            title: 'Technology',
          },
          {
            value: 'healthcare',
            title: 'Healthcare',
          },
          {
            value: 'construction_trades',
            title: 'Construction & Trades',
          },
          {
            value: 'business_finance',
            title: 'Business & Finance',
          },
          {
            value: 'retail_sales',
            title: 'Retail & Sales',
          },
          {
            value: 'food_beverage',
            title: 'Food & Beverage',
          },
          {
            value: 'marketing_advertising',
            title: 'Marketing & Advertising',
          },
          {
            value: 'education_training',
            title: 'Education & Training',
          },
          {
            value: 'art_entertainment',
            title: 'Art & Entertainment',
          },
          {
            value: 'transportation_logistics',
            title: 'Transportation & Logistics',
          },
          {
            value: 'agriculture_forestry',
            title: 'Agriculture & Forestry',
          },
          {
            value: 'other',
            title: 'Other',
          }
        ]
      }
    ],
    
    musical_instruments: [
      {
        key: 'type',
        title: 'Type',
        type: 'select',
        options: [
          {
            value: 'string',
            title: 'String',
          },
          {
            value: 'woodwind',
            title: 'Woodwind',
          },
          {
            value: 'brass',
            title: 'Brass',
          },
          {
            value: 'percussion',
            title: 'Percussion',
          },
          {
            value: 'keyboard',
            title: 'Keyboard',
          },
          {
            value: 'electronic',
            title: 'Electronic',
          }
        ]
      },
      {
        key: 'brand',
        title: 'Brand',
        type: 'input'
      }
    ],

    real_estate: [
      {
        key: 'bedrooms',
        title: 'Bedrooms',
        type: 'select',
        options: [
          {
            value: 'all',
            title: 'All',
          },
          {
            value: '1',
            title: '1',
          },
          {
            value: '2',
            title: '2',
          },
          {
            value: '3',
            title: '3',
          },
          {
            value: '4',
            title: '4',
          },
          {
            value: '5',
            title: '5',
          },
          {
            value: '6+',
            title: '6+',
          }
        ]
      },
      {
        key: 'bathrooms',
        title: 'Bathrooms',
        type: 'select',
        options: [
          {
            value: 'all',
            title: 'All',
          },
          {
            value: '1',
            title: '1',
          },
          {
            value: '2',
            title: '2',
          },
          {
            value: '3',
            title: '3',
          },
          {
            value: '4',
            title: '4',
          },
          {
            value: '5',
            title: '5',
          },
          {
            value: '6+',
            title: '6+',
          }
        ]
      },
      {
        key: 'sale_type',
        title: 'Sale Type',
        type: 'select',
        options: [
          {
            value: 'rent',
            title: 'Rent',
          },
          {
            value: 'sale',
            title: 'Sale',
          }
        ]
      },
      {
        key: 'sq_ft',
        title: 'Square Feet',
        type: 'number'
      },
      {
        key: 'place_type',
        title: 'Type of Place',
        type: 'select',
        options: [
          {
            value: 'home',
            title: 'Home',
          },
          {
            value: 'townhouse',
            title: 'Townhouse',
          },
          {
            value: 'apartment_condo',
            title: 'Apartment/Condo',
          },
          {
            value: 'land',
            title: 'Land',
          }
        ]
      },
      {
        key: 'lot_size',
        title: 'Lot Size',
        type: 'number'
      }
    ],

    toys_and_games: [
      {
        key: 'age_range',
        title: 'Age Range',
        type: 'select',
        options: [
          {
            value: 'birth_to_24_months',
            title: 'Birth to 24 Months',
          },
          {
            value: '2_to_4_years',
            title: '2 to 4 Years',
          },
          {
            value: '5_to_7_years',
            title: '5 to 7 Years',
          },
          {
            value: '8_to_13_years',
            title: '8 to 13 Years',
          },
          {
            value: '14_years_up',
            title: '14 Years & Up',
          },
          {
            value: 'all',
            title: 'All',
          }
        ]
      }
    ],

    vehicles: [
      {
        key: 'type',
        title: 'Type',
        type: 'select',
        options: [
          {
            value: 'car-truck',
            title: 'Car/Truck',
          },
          {
            value: 'motorcycle',
            title: 'Motorcycle',
          },
          {
            value: 'powersport',
            title: 'Powersport',
          },
          {
            value: 'rv-camper',
            title: 'RV/Camper',
          },
          {
            value: 'trailer',
            title: 'Trailer',
          },
          {
            value: 'boat',
            title: 'Boat',
          },
          {
            value: 'commercial-industrial',
            title: 'Commercial/Industrial',
          },
          {
            value: 'other',
            title: 'Other' 
          },          
        ]
      },
      {
        key: 'year',
        title: 'Year',
        type: 'year'
      },
      {
        key: 'make',
        title: 'Make',
        type: 'input'
      },
      {
        key: 'model',
        title: 'Model',
        type: 'input'
      },
      {
        key: 'mileage',
        title: 'Mileage',
        type: 'number'
      },
      {
        key: 'ext_color',
        title: 'Exterior Color',
        type: 'color'
      },
      {
        key: 'int_color',
        title: 'Interior Color',
        type: 'color'
      },
      {
        key: 'body_style',
        title: 'Body Style',
        type: 'select',
        options: [
          { value: 'coupe', title: 'Coupe' },
          { value: 'truck', title: 'Truck' },
          { value: 'sedan', title: 'Sedan' },
          { value: 'hatchback', title: 'Hatchback' },
          { value: 'suv', title: 'SUV' },
          { value: 'convertible', title: 'Convertible' },
          { value: 'wagon', title: 'Wagon' },
          { value: 'minivan', title: 'Minivan' },
          { value: 'small car', title: 'Small Car' },
          { value: 'other', title: 'Other' }
        ],
      },
      {
        key: 'fuel_type',
        title: 'Fuel Type',
        type: 'select',
        options: [
          { value: 'diesel', title: 'Diesel' },
          { value: 'electric', title: 'Electric' },
          { value: 'gasoline', title: 'Gasoline' },
          { value: 'flex', title: 'Flex' },
          { value: 'hybrid', title: 'Hybrid' },
          { value: 'petrod', title: 'Petrod' },
          { value: 'plug-in hybrid', title: 'Plug-in Hybrid' },
          { value: 'other', title: 'Other' }
        ],
      },
      {
        key: 'transmission',
        title: 'Transmission Type',
        type: 'select',
        options: [
          { value: 'manual', title: 'Manual' },
          { value: 'automatic', title: 'Automatic' }
        ],
      },
      {
        key: 'clean_title',
        title: 'Clean title',
        type: 'boolean',
        subtitle: 'This vehicle has a clean title. This vehicle has no significant damage or persistent problems.',
      },
    ],

    watches_jewelry: [
      {
        key: 'gender',
        title: 'Gender',
        type: 'select',
        options: [
          {
            value: 'male',
            title: 'Male',
          },
          {
            value: 'female',
            title: 'Female',
          },
          {
            value: 'both',
            title: 'Both',
          }
        ]
      },
      {
        key: 'brand',
        title: 'Brand',
        type: 'input'
      },
      {
        key: 'color',
        title: 'Color',
        type: 'color'
      },
    ],

  }.freeze

end