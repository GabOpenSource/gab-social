class Simplifiers::MediaAttachmentSimplifier
  # from REST::MediaAttachmentSerializer
  MAPPING = {
    id: :i,
    type: :t,
    url: :u,
    preview_url: :pu,
    source_mp4: :smp4,
    remote_url: :ru,
    meta: :m,
    account_id: :ai,
    status_url: :su,
    status_id: :si,
    marketplace_listing_id: :mli,
    file_name: :fn,
    description: :d,
    blurhash: :b,
    file_content_type: :fct,
    lowres_mp4: :lmp4,
    file_fingerprint: :ff
  }.freeze

  META_KEY_MAPPING = {
    aspect: :a,
    audio_bitrate: :ab,
    audio_channels: :ac,
    audio_encode: :ae,
    duration: :d,
    fps: :f,
    height: :h,
    length: :l,
    lowres: :lr,
    original: :o,
    playable: :p,
    size: :s,
    small: :sm,
    width: :w
  }.freeze

  INNER_META_PARENT_KEYS = [:lowres, :original, :playable, :small].freeze

  INNER_META_KEY_MAPPING = {
    width: :w,
    height: :h,
    frame_rate: :fr,
    duration: :d,
    bitrate: :b,
    size: :s,
    aspect: :a
  }.freeze

  def self.simplified_key(original_key)
    MAPPING[original_key] || original_key
  end

  def self.original_key(simplified_key)
    MAPPING.key(simplified_key) || simplified_key
  end
 
  def self.simplify_meta(meta_hash)
    return {} unless meta_hash.is_a?(Hash)

    # Define which outer keys can have inner keys
    keys_with_inner_meta = INNER_META_PARENT_KEYS.map { |k| META_KEY_MAPPING[k] }

    # Transform the main meta keys
    simplified_meta = meta_hash.transform_keys { |key| META_KEY_MAPPING[key.to_sym] || key }

    # Transform specific inner meta keys
    keys_with_inner_meta.each do |outer_key|
      if simplified_meta[outer_key].is_a?(Hash)
        simplified_meta[outer_key] = simplified_meta[outer_key].transform_keys { |k| INNER_META_KEY_MAPPING[k.to_sym] || k }
      end
    end

    simplified_meta
end
end
