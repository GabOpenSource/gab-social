class Simplifiers::StatusSimplifier
  # from REST::StatusSerializer
  MAPPING = {
    id: :i,
    created_at: :ca,
    revised_at: :ra,
    in_reply_to_id: :irti,
    in_reply_to_account_id: :irta,
    sensitive: :s,
    spoiler_text: :st,
    visibility: :v,
    language: :l,
    uri: :u,
    url: :ul,
    direct_replies_count: :drc,
    replies_count: :rc,
    reblogs_count: :rbc,
    pinnable: :p,
    pinnable_by_group: :pbg,
    favourites_count: :fc,
    quote_of_id: :qoi,
    expires_at: :ea,
    has_quote: :hq,
    bookmark_collection_id: :bci,
    quotes_count: :qc,
    reaction_id: :rid,
    reactions_counts: :rcs,
    is_reply: :ir,
    account_id: :ai,
    media_attachment_ids: :mai,
    conversation_id: :ci,
    reblog_of_id: :robi,
    group_id: :gi,
    status_context_id: :sci,
    preview_card_id: :pci,
    poll_id: :pi,
    favourited: :fvd,
    reblogged: :rbgd,
    muted: :m,
    content: :c,
    text: :t,
    markdown: :md,
    reblog: :rb,
    quote: :q,
    account: :a,
    group: :g,
    status_context: :sc,
    media_attachments: :ma,
    ordered_mentions: :om,
    mentions: :m,
    tags: :tg,
    emojis: :e,
    preview_card: :pc,
    preloadable_poll: :pp
  }.freeze

  def self.simplified_key(original_key)
    MAPPING[original_key] || original_key
  end

  def self.original_key(simplified_key)
    MAPPING.key(simplified_key) || simplified_key
  end
end