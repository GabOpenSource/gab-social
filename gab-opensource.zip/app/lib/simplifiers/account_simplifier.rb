class Simplifiers::AccountSimplifier
  # from REST::AccountSerializer
  MAPPING = {
    id: :i,
    username: :un,
    acct: :ac,
    display_name: :dn,
    locked: :l,
    created_at: :ca,
    note: :nt,
    url: :u,
    avatar: :av,
    avatar_static: :avs,
    avatar_small: :avsml,
    avatar_static_small: :avss,
    header: :h,
    header_static: :hs,
    is_spam: :is,
    followers_count: :foc,
    following_count: :fic,
    statuses_count: :sc,
    is_pro: :ip,
    is_verified: :iv,
    is_donor: :idn,
    is_investor: :ii,
    show_pro_life: :spl,
    is_parody: :ipd
  }.freeze

  def self.simplified_key(original_key)
    MAPPING[original_key] || original_key
  end

  def self.original_key(simplified_key)
    MAPPING.key(simplified_key) || simplified_key
  end
end