class Simplifiers::GroupSimplifier
  # from REST::GroupSerializer
  MAPPING = {
    id: :i,
    title: :t,
    description: :d,
    description_html: :dh,
    cover_image_url: :ciu,
    cover_image_thumbnail_url: :cit,
    cover_image_medium_url: :cim,
    is_archived: :ia,
    member_count: :mc,
    is_verified: :iv,
    is_moderated: :im,
    created_at: :ca,
    is_private: :ip,
    is_visible: :ivs,
    slug: :sl,
    url: :u,
    tags: :tg,
    group_category: :gc,
    password: :pw,
    has_password: :hp,
    is_paused: :ipd,
    theme_color: :tc,
    rules: :r,
    is_admins_visible: :iav,
    is_members_visible: :imv,
    is_media_visible: :imv,
    is_links_visible: :ilv,
    allow_quotes: :aq
  }.freeze

  def self.simplified_key(original_key)
    MAPPING[original_key] || original_key
  end

  def self.original_key(simplified_key)
    MAPPING.key(simplified_key) || simplified_key
  end
end
