# frozen_string_literal: true

class StatusDataPresenter
  attr_reader :statuses, :accounts, :groups, :current_user, :current_account,
              :stats, :media_attachments, :pending_media_attachments,
              :group_categories, :polls, :status_contexts, :account_stats,
              :preview_cards, :reactions_counts, :view_counts

  def initialize(statuses, exclude_accounts: false, exclude_groups: false)
    return if statuses.nil? || statuses.empty?
    @statuses = statuses.compact
    status_ids = @statuses.flat_map { |s| 
      items = [s.id, s.reblog_of_id, s.quote_of_id]
      items << s.reblog.quote_of_id if s.reblog&.quote_of_id
      items
    }.uniq.compact
    group_ids = Status.where(id: status_ids).pluck(:group_id).uniq.compact
    group_ids.delete(nil)

    @accounts = Account.joins(:statuses).where(statuses: { id: status_ids }).distinct.index_by(&:id) unless exclude_accounts
    @groups = {}
    @groups = Group.where(id: group_ids).index_by(&:id) unless exclude_groups or group_ids.empty?
    @current_user = current_user
    @current_account = current_user&.account
    @stats = StatusStat.where(status_id: status_ids).index_by(&:status_id)

    @media_attachments = MediaAttachment.where(status_id: status_ids).to_a
    @pending_media_attachments = PendingMediaAttachment.where(status_id: status_ids).where('media_attachment_id is null').to_a
    @polls = Poll.where(status_id: status_ids).index_by(&:status_id)

    group_categories = []
    @groups.each do |group_id, group|
      group_categories << group.group_category_id
    end
    group_categories.uniq!
    @group_categories = {}
    @group_categories = GroupCategories.where(id: group_categories).index_by(&:id) if group_categories.any?
    status_context_ids = []
    @statuses.each do |status|
      status_context_ids << status.status_context_id if !status.status_context_id.nil?
    end
    status_context_ids.uniq!
    @status_contexts = {}
    @status_contexts = StatusContext.where(id: status_context_ids).index_by(&:id) if status_context_ids.any?  

    # pluck the account ids from @accounts
    account_ids = []
    @accounts.each do |account_id, account|
      account_ids << account_id
    end
    @account_stats = AccountStat.where(account_id: account_ids).index_by(&:account_id) if account_ids.any?

    @preview_cards = PreviewCard.joins(:statuses).select('preview_cards.*, statuses.id as status_id').where(statuses: { id: status_ids }).index_by(&:status_id)

    @redis_keys = status_ids.map { |id| "reactions_counts:#{id}" }
    reacts = Rails.cache.read_multi(*@redis_keys)
    @reactions_counts = {}
    reacts.each do |key, value|
      @reactions_counts[key.gsub('reactions_counts:', '')] = value
    end

    @view_counts = {}
    ids_for_views = []
    @statuses.each do |status|
      ids_for_views << status.id if status.attrs['was_pro'] == true
      if status.reblog_of_id && status.reblog
        ids_for_views << status.reblog_of_id if status.reblog.attrs['was_pro'] == true
      end
      if status.quote_of_id && status.quote
        ids_for_views << status.quote_of_id if status.quote.attrs['was_pro'] == true
      end
    end
    if ids_for_views.any?
      analytics = StathouseRetrievalService.instance.get_multi_counts('status', ids_for_views)
      if !analytics.nil?
        analytics.each do |data|
          if @view_counts[data['event_object_id']].nil?
            @view_counts[data['event_object_id']] = [{event_action: data['event_action'], count: data['count']}]
          else
            @view_counts[data['event_object_id']] << {event_action: data['event_action'], count: data['count']}
          end
        end
      end
    end

  end

  def get_stats(status_id)
    @stats[status_id] || []
  end

end
