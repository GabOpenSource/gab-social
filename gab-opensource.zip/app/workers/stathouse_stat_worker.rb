# frozen_string_literal: true

# How to use:
# StathouseStatWorker.perform_async('marketplace_listing', listing_ids, 'view', current_account ? current_account.id : nil)

class StathouseStatWorker
  include Sidekiq::Worker

  sidekiq_options queue: 'track', retry: 0

  def perform(event_class, event_ids, event_action, event_account = nil, event_data = nil)
    if event_ids.is_a?(Array)
      StathouseTrackingService.instance.track_multi(event_class, event_ids, event_action, event_account, event_data)
    else
      StathouseTrackingService.instance.track(event_class, event_ids, event_action, event_account, event_data)
    end
  end
end