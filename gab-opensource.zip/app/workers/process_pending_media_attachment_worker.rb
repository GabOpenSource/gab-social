# frozen_string_literal: true
require 'open-uri'

class ProcessPendingMediaAttachmentWorker
  include Sidekiq::Worker
  include RoutingHelper

  sidekiq_options queue: 'media', retry: false

  def perform(pending_media_id)
    pending_media = PendingMediaAttachment.find(pending_media_id)
    return if pending_media.media_attachment_id.present?
    media_account = Account.find(pending_media.account_id)
    @media = media_account
    .media_attachments
    .create!(
        account: media_account,
        file: pending_media.file,
        description: pending_media.description,
        status_id: pending_media.status_id,
        scheduled_status_id: pending_media.scheduled_status_id,
    )
    pending_media.media_attachment_id = @media.id      
    pending_media.save!
    if !pending_media.status_id.nil? || !pending_media.scheduled_status_id.nil?
      media = MediaAttachment.find(@media.id)
      media.update!(status_id: pending_media.status_id, scheduled_status_id: pending_media.scheduled_status_id)
      Rails.cache.delete("statuses/#{pending_media.status_id}") unless pending_media.status_id.nil?
      Rails.cache.delete("statuses/#{pending_media.scheduled_status_id}") unless pending_media.scheduled_status_id.nil?
    end
  rescue ActiveRecord::RecordNotFound
    Rails.logger.error "ProcessPendingMediaAttachmentWorker: ActiveRecord::RecordNotFound: #{pending_media_id}"
    # TODO: determine failure path...
    true
  end
end
