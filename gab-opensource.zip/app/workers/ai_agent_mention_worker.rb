# frozen_string_literal: true
require "openai"

class AiAgentMentionWorker
  include Sidekiq::Worker

  sidekiq_options queue: 'pull', retry: 8

  def perform(agent_id, status_id, mentioner_account_id)
    agent = AiAgent.find(agent_id)
    agent_account = Account.find(agent.account_id)
    status = Status.find(status_id)
    mentioner_account = Account.find(mentioner_account_id)

    return true if status.account_id == agent_account.id

    # Remove mentions at the beginning of the status
    target_text = status.text.gsub(/^@(\w+)\s/, '')

    client = OpenAI::Client.new(
      access_token: "this-is-not-an-access-token",
      uri_base: agent.endpoint,
      request_timeout: 720
    )
    
    response = client.chat(
      parameters: {
        model: "Nous-Hermes-Llama2-13b",
        messages: [
          { role: "system", content: agent.system },
          { role: "user", content: target_text}
        ],
        temperature: 0.9,
      }
    )
    response = response.dig("choices", 0, "message", "content")

    PostStatusService.new.call(agent_account,
      thread: status,
      gms_skip: true,
      text: response,
      markdown: response,
      sensitive: false
    )

    if mentioner_account.is_pro? && rand(1..10) == 7
      PostStatusService.new.call(agent_account,
        quote_of_id: status.id,
        gms_skip: true,
        text: response,
        markdown: response,
        sensitive: false
      )
    end

    true
  rescue ActiveRecord::RecordNotFound, OpenSSL::SSL::SSLError, URI::InvalidURIError, GabSocial::NotPermittedError
    true
  rescue => e
    Rails.logger.error "AI Agent Mention Worker Error: #{e.message}"
    Rails.logger.error e.backtrace.join("\n")
    raise e
  end
end
