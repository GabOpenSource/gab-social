# frozen_string_literal: true

class Api::V2::Timelines::GroupController < Api::BaseController
  before_action :set_group
  before_action :set_sort_type
  before_action :set_statuses

  after_action :insert_pagination_headers, if: -> { !@statuses.empty? && is_rising? }

  def show
    if current_user
      is_admin_or_mod = @is_admin_or_mod || false
      is_member = @group_relationships ? @group_relationships.member[@group.id] == true : false
      if @group.is_private and !is_admin_or_mod and !is_member
        render json: { error: 'Not authorized' }, status: :forbidden
        return
      end
      status_relationships = nil
      if is_admin_or_mod
        status_relationships = StatusRelationshipsPresenter.new(@statuses, current_user.account_id, group_id: @group.id, include_blocking_map: true)
      else
        status_relationships = StatusRelationshipsPresenter.new(@statuses, current_user.account_id, group_id: @group.id)
      end
      
      render json: @statuses,
           serializer: REST::StatusTimelineSerializer,
           relationships: status_relationships,
           data: StatusDataPresenter.new(@statuses)
    else
      render json: @statuses, 
        serializer: REST::StatusTimelineSerializer,
        data: StatusDataPresenter.new(@statuses)
    end
    track_status_views(@statuses)
  end

  private

  def set_sort_type
    @sort_type = 'newest'
    @sort_type = 'top_today' if current_user.nil?
    @sort_type = params[:sort_by] if [
      'hot',
      'newest',
      'recent',
      'rising',
      'top_today',
      'top_weekly',
      'top_monthly',
      'top_yearly',
      'top_all_time',
    ].include? params[:sort_by]

    return @sort_type
  end

  def set_group
    @group = Group.find_by!(id: params[:id], is_archived: false)
  end

  def set_statuses
    if current_account
      @group_relationships = GroupRelationshipsPresenter.new([@group.id], current_account.id)
      @is_admin_or_mod = @group_relationships.admin[@group.id] == true || @group_relationships.moderator[@group.id] == true
    end
    @statuses = cached_group_statuses
    @statuses = @statuses.reject { |status| status.proper.nil? }
  end

  def cached_group_statuses
    ActiveRecord::Base.connected_to(role: :writing) do
      cache_collection group_statuses, Status
    end
  end

  def group_statuses
    # : todo : filter deeper by
    # params[:status_context] # aka posts with statuses.status_context_id
    # params[:badge_id] # aka group_account.badge_id
    
    page = if current_account
      params[:page]
    else
      [params[:page].to_i.abs, MIN_UNAUTHENTICATED_PAGES].min
    end

    statuses = nil

    if is_rising?
      statuses = RisingQueryBuilder.new.call(
        limit_param(DEFAULT_STATUSES_LIMIT),
        params[:max_id],
        params[:since_id],
        [@group.id]
      )
    else
      statuses = SortingQueryBuilder.new.call(@sort_type, @group, page, nil, { current_account: current_account })
    end

    if current_account
      unless @is_admin_or_mod
        statuses = FeedManager.instance.filter_from_home_batch(statuses, current_account.id)
      end
    end

    statuses
  end

  def is_rising?
    @sort_type == 'rising'
  end

  def insert_pagination_headers
    set_pagination_headers(next_path, prev_path)
  end

  def pagination_params(core_params)
    params.slice(:limit).permit(:limit).merge(core_params)
  end

  def next_path
    api_v2_timelines_group_url params[:id], pagination_params(max_id: pagination_max_id)
  end

  def prev_path
    api_v2_timelines_group_url params[:id], pagination_params(min_id: pagination_since_id)
  end

  def pagination_max_id
    @statuses.last.id
  end

  def pagination_since_id
    @statuses.first.id
  end
end
