# frozen_string_literal: true

class Api::V2::Timelines::ExploreController < Api::BaseController
  before_action :set_sort_type
  before_action :set_statuses

  def show
    if current_user
      render json: @statuses,
           serializer: REST::StatusTimelineSerializer,
           relationships: StatusRelationshipsPresenter.new(@statuses, current_user&.account_id),
           data: StatusDataPresenter.new(@statuses)
    else
      render json: @statuses, 
        serializer: REST::StatusTimelineSerializer,
        data: StatusDataPresenter.new(@statuses)
    end
    track_status_views(@statuses)
  end

  private

  def set_sort_type
    @sort_type = 'hot'
    @sort_type = params[:sort_by] if [
      'hot',
      'rising',
      'top_today',
      'top_weekly',
      'top_monthly',
      'top_yearly',
      'top_all_time',
    ].include? params[:sort_by]

    return @sort_type
  end

  def set_statuses
    @statuses = ActiveRecord::Base.connected_to(role: :writing) do
      cache_collection explore_statuses, Status
    end
    # : todo : 
    # add statuses in new table explore_page_statuses
    # with start_time
  end

  def explore_statuses
    page = if current_account
      params[:page].to_i
    else
      [params[:page].to_i.abs, MIN_UNAUTHENTICATED_PAGES].min
    end

    statuses = nil

    if @sort_type == 'rising'
      statuses = RisingQueryBuilder.new.call(
        limit_param(DEFAULT_STATUSES_LIMIT),
        params[:max_id],
        params[:since_id]
      )
    else
      statuses = SortingQueryBuilder.new.deduped_with_cache(@sort_type, nil, page, "explore", { current_account: current_account })
    end

    statuses = FeedManager.instance.filter_from_home_batch(statuses, current_account.id) if current_account

    statuses
  end
end
