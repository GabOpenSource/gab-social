# frozen_string_literal: true

class Api::V2::Statuses::ThreadController < Api::BaseController
  include Authorization

  DEFAULT_THREAD_PAGE_LIMIT = 25

  before_action -> { authorize_if_got_token! :read, :'read:statuses' }
  before_action :set_status

  def show
    all_ids = @status.thread_snapshot_ids
    sort_by = sort_by_param
    all_ids = sorted_thread_ids(all_ids, sort_by) if sort_by.present?

    page = page_params
    page_size = limit_param(DEFAULT_THREAD_PAGE_LIMIT)
    offset = (page - 1) * page_size
    page_ids = all_ids[offset, page_size]

    if page_ids.nil? || page_ids.empty?
      render json: empty_response(all_ids.size)
      return
    end

    statuses = load_page_statuses(page_ids)
    replies_map = build_replies_map(page_ids, all_ids)
    has_more = offset + page_size < all_ids.size

    render json: {
      statuses: serialized_statuses(statuses),
      replies_map: replies_map,
      total_count: all_ids.size,
      page: page,
      has_more: has_more,
    }
  end

  private

  def set_status
    @status = Status.find(params[:id])
    authorize @status, :show?
  rescue GabSocial::NotPermittedError
    raise ActiveRecord::RecordNotFound
  end

  def page_params
    [params[:page].to_i.abs, 1].max
  end

  def sort_by_param
    sort = params[:sort_by].to_s.downcase.strip
    %w[newest most-liked].include?(sort) ? sort : nil
  end

  def sorted_thread_ids(all_ids, sort_by)
    root_id = @status.id

    top_level_ids = case sort_by
    when 'newest'
      Status.where(id: all_ids, in_reply_to_id: root_id).order(id: :desc).pluck(:id)
    when 'most-liked'
      Status.where(id: all_ids, in_reply_to_id: root_id).left_outer_joins(:status_stat).order('COALESCE(status_stats.favourites_count, 0) DESC, statuses.id ASC').pluck(:id)
    else
      return all_ids
    end

    top_level_set = Set.new(top_level_ids)

    groups = {}
    current_top = nil
    all_ids.each do |id|
      if top_level_set.include?(id)
        groups[id] = [id]
        current_top = id
      elsif current_top
        groups[current_top] << id
      end
    end

    top_level_ids.flat_map { |tid| groups[tid] || [] }
  end

  def load_page_statuses(ids)
    statuses = Status.where(id: ids)
      .includes(:account, :media_attachments, :tags, :preview_cards, :poll, :revisions, :status_context, group: :group_categories)
      .to_a

    account_ids = statuses.map(&:account_id).uniq
    domains = statuses.map { |s| s.account&.domain }.compact.uniq
    relations = relations_map_for_account(current_account, account_ids, domains)

    statuses.reject! { |s| filter_status_for_thread?(s, relations) }
    statuses.sort_by! { |s| ids.index(s.id) }
    statuses
  end

  def relations_map_for_account(account, account_ids, domains)
    return {} if account.nil?

    {
      blocking: Account.blocking_map(account_ids, account.id),
      blocked_by: Account.blocked_by_map(account_ids, account.id),
      muting: Account.muting_map(account_ids, account.id),
      following: Account.following_map(account_ids, account.id),
    }
  end

  def filter_status?(status, relations)
    StatusFilter.new(status, current_account, relations).filtered?
  end

  def filter_status_for_thread?(status, relations)
    status.account_id != current_account&.id &&
      !StatusPolicy.new(current_account, status, relations).show?
  end

  def build_replies_map(page_ids, all_ids)
    root_id = @status.id.to_s
    statuses = Status.where(id: page_ids).select(:id, :in_reply_to_id)
    map = {}
    statuses.each do |s|
      next if s.in_reply_to_id.nil?
      next if s.in_reply_to_id.to_s == root_id
      map[s.id.to_s] = s.in_reply_to_id.to_s
    end
    map
  end

  def serialized_statuses(statuses)
    ActiveModelSerializers::SerializableResource.new(
      statuses,
      each_serializer: REST::StatusSerializer,
      scope: current_user,
      scope_name: :current_user,
      relationships: StatusRelationshipsPresenter.new(statuses, current_user&.account_id)
    )
  end

  def empty_response(total)
    {
      statuses: [],
      replies_map: {},
      total_count: total,
      page: page_params,
      has_more: false,
    }
  end
end
