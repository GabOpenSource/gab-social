require 'openssl'
require 'base64'

class Api::V3::SupportHookController < Api::BaseController

  def self.encode_user_token(account_id)
    payload = "#{account_id}"
    signature = OpenSSL::HMAC.hexdigest('SHA256', ENV.fetch('SUPPORT_HOOK_SECRET'), payload)
    return Base64.urlsafe_encode64("#{payload}:#{signature}", padding: false)
  end

  def lookup
    # Log and return false is captcha key is not present. This will disallow anyone from signing up
    verify_setup
    verify_user_token
    Rails.logger.info "SupportHookController: Support hook request for token: #{params[:user_token]}"
    account_id = decode_user_token(params[:user_token])
    Rails.logger.info "SupportHookController: Account ID: #{account_id}"
    begin
      account = Account.find(account_id)
      throw ActiveRecord::RecordNotFound if account.nil?
      user = User.find_by(account_id: account.id)
      throw ActiveRecord::RecordNotFound if user.nil?
      payload = {
        account_id: account.id.to_s,
        account_username: account.username,
        account_display_name: account.display_name,
        account_avatar_url: account.avatar_cdn_url,
        account_note: account.note,
        account_created_at: account.created_at,
        account_updated_at: account.updated_at,
        account_is_pro: account.is_pro?,
        account_is_verified: account.is_verified?,
        account_is_donor: account.is_donor?,
        account_is_investor: account.is_investor?,
        account_is_flagged_as_spam: account.is_flagged_as_spam?,
        account_spam_flag: account.spam_flag,
        email: user.email,
        is_admin: user.admin,
        is_moderator: user.moderator,
        is_approved: user.approved,
        is_confirmed: !user.confirmed_at.nil?,
        deliverable: user.deliverable,
        sign_in_count: user.sign_in_count,
        current_sign_in_ip: user.current_sign_in_ip.to_s,
        admin_link: "https://#{ENV.fetch('WEB_DOMAIN')}/admin/accounts/#{account.id}"
      }
      return render json: payload
    rescue ActiveRecord::RecordNotFound
      Rails.logger.error "SupportHookController: Account not found"
      return render json: { error: 'Account not found' }, status: 404
    end
  end

  private

  def verify_setup
    if ENV.fetch('SUPPORT_HOOK_SECRET', '').empty? || ENV.fetch('SUPPORT_HOOK_SECRET', '').nil?
      Rails.logger.debug "SupportHookController: SUPPORT_HOOK_SECRET is undefined"
      return render json: { error: 'Missing key for Support hook request' }, status: 401
    end
    if params[:secret] != ENV.fetch('SUPPORT_HOOK_SECRET')
      Rails.logger.debug "SupportHookController: Invalid secret"
      return render json: { error: 'Invalid secret' }, status: 401
    end
  end

  def verify_user_token
    if params[:user_token].nil? || params[:user_token].empty?
      Rails.logger.debug "SupportHookController: User token is missing"
      return render json: { error: 'User token is missing' }, status: 401
    end
  end

  def decode_user_token(user_token)
    decoded = Base64.urlsafe_decode64(user_token)
    payload, signature = decoded.split(':')
    if signature != OpenSSL::HMAC.hexdigest('SHA256', ENV.fetch('SUPPORT_HOOK_SECRET'), payload)
      Rails.logger.debug "SupportHookController: Invalid user token"
      return render json: { error: 'Invalid user token' }, status: 401
    end
    return payload
  end
end
