# frozen_string_literal: true

class Api::V1::MarketplaceListingsController < Api::BaseController
  include Authorization

  before_action :require_user!, except: [:show]
  before_action :set_marketplace_listing, except: [:create]
  before_action :ensure_ownership!, only: [:update, :destroy]

  def show
    authorize @marketplace_listing, :show?
    render json: @marketplace_listing, serializer: REST::MarketplaceListingSerializer
    StathouseStatWorker.perform_async('marketplace_listing', @marketplace_listing.id.to_s, 'view', current_account ? current_account.id : nil)
  end

  def create
    @marketplace_listing = CreateMarketplaceListingService.new.call(
      current_account,
      marketplace_listing_params
    )
    render json: @marketplace_listing, serializer: REST::MarketplaceListingSerializer
  end

  def update
    # only require review if not biz
    require_review = @marketplace_listing.business_id.nil?

    updated_marketplace_listing = CreateMarketplaceListingService.new.call(
      current_account,
      marketplace_listing_params,
      @marketplace_listing
    )

    if require_review
      MarketplaceListingStatusChangeService.new.call(
        @marketplace_listing,
        :pending_admin_review,
        nil,
        current_account
      )
    end

    render json: updated_marketplace_listing, serializer: REST::MarketplaceListingSerializer
  end

  def destroy
    authorize @marketplace_listing, :destroy?

    @marketplace_listing.destroy!

    render_empty_success
  end

  def set_status
    authorize @marketplace_listing, :update?

    MarketplaceListingStatusChangeService.new.call(
      @marketplace_listing,
      MarketplaceListing.statuses.key(params[:status].to_i),
      nil,
      current_account,
    )

    render json: @marketplace_listing, serializer: REST::MarketplaceListingSerializer
  end

  private

  def ensure_ownership!
    if @marketplace_listing.account.id == current_account.id
      true
    else
      render json: { error: 'Unauthorized' }, status: 501
    end
  end

  def set_marketplace_listing
    @marketplace_listing = MarketplaceListing.includes(:account).find(params[:id])
    # important!
    authorize @marketplace_listing, :show?
  end

  def marketplace_listing_params
    thep = params.permit(
      :title,
      :description,
      :category,
      :condition,
      :location,
      :location_object,
      :price,
      :business_id,
      :cta_title,
      :cta_link,
      media_ids: [],
      attrs: MarketplaceListingAttributes::UNIQUE_KEYS[:attrs]
    )
    thep[:condition] = thep[:condition].to_i if !thep[:condition].nil?

    if !params[:location_object].nil?
      # thep[:location_object] = JSON.parse(params[:location_object])
      thep[:location_object] = params[:location_object]
    end

    thep
  end
end
