# frozen_string_literal: true

class Api::V1::Timelines::ForYouController < Api::BaseController
  before_action :require_user!
  after_action :insert_pagination_headers, unless: -> { @statuses.empty? }

  def show
    @statuses = load_statuses
    @statuses = FeedManager.instance.filter_from_home_batch(@statuses, current_account.id) if current_account
    render json: @statuses,
           each_serializer: REST::StatusSerializer,
           relationships: StatusRelationshipsPresenter.new(@statuses, current_user&.account_id)
    track_status_views(@statuses)        
  end

  private

  def load_statuses
    the_statuses
  end

  def the_statuses
    acct = Account.find(31)

    page = params[:page].to_i
    theLimit = params[:max_id].nil? ? 20 : limit_param(DEFAULT_STATUSES_LIMIT)

    statuses = ForYouFeed.new(acct, current_account).get(
      theLimit,
      params[:max_id],
      params[:since_id],
      params[:min_id],
      'newest',
      page
    )
  
    statuses
  end

  def insert_pagination_headers
    set_pagination_headers(next_path, prev_path)
  end

  def pagination_params(core_params)
    params.slice(:local, :limit).permit(:local, :limit).merge(core_params)
  end

  def next_path
    api_v1_timelines_for_you_url pagination_params(max_id: pagination_max_id)
  end

  def prev_path
    api_v1_timelines_for_you_url pagination_params(min_id: pagination_since_id)
  end

  def pagination_max_id
    @statuses.last.id
  end

  def pagination_since_id
    @statuses.first.id
  end


end
