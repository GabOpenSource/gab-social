# frozen_string_literal: true

class Api::V1::Timelines::LinksController < Api::BaseController
  before_action :set_sort_type

  def show
    @statuses = load_link_statuses
    @statuses = FeedManager.instance.filter_from_home_batch(@statuses, current_account.id) if current_account
    render json: @statuses,
           each_serializer: REST::StatusSerializer,
           relationships: StatusRelationshipsPresenter.new(@statuses, current_user&.account_id)
    track_status_views(@statuses)        
  end

  private

  def load_link_statuses
    link_statuses
  end

  def link_statuses
    statuses = Status.popular_accounts.without_replies.joins(:preview_cards)

    # only show 1 page if no user
    page = if current_account
      params[:page].to_i
    else
      [params[:page].to_i.abs, MIN_UNAUTHENTICATED_PAGES].min
    end
  
    statuses = statuses.merge(SortingQueryBuilder.new.call(@sort_type, nil, page, 'links', { current_account: current_account }))

    statuses
  end

  def set_sort_type
    @sort_type = 'newest'
    @sort_type = params[:sort_by] if [
      'hot',
      'newest',
      'recent',
      'top_today',
      'top_weekly',
      'top_monthly',
      'top_yearly',
      'top_all_time',
      'most_votes_today',
      'most_votes_weekly',
      'most_votes_monthly',
      'most_votes_yearly',
      'most_votes_all_time',
    ].include? params[:sort_by]

    return @sort_type
  end


end
