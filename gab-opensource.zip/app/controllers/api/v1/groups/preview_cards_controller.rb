# frozen_string_literal: true

class Api::V1::Groups::PreviewCardsController < Api::BaseController
  before_action :require_user!
  before_action :set_group
  after_action :insert_pagination_headers

  def index
    @preview_cards = load_cards
    render json: @preview_cards, each_serializer: REST::PreviewCardSerializer
  end

  private

  def set_group
    @group = Group.find(params[:group_id])
    if !@group.is_links_visible
      return render json: { "error": true }, status: 422
    end
  end

  def load_cards
    # don't show anything if no user and group is private or not visible
    return [] if current_account.nil? && (@group.is_private || !@group.is_visible)
    # don't show anything if group is private and user not a member
    return [] if @group.is_private && !@group.group_accounts.where(account_id: current_account.id).exists?

    scope = PreviewCard.joins(:statuses).where(statuses: {
      group_id: @group.id,
    })

    scope = scope.paginate_by_max_id(
      limit_param(DEFAULT_PREVIEW_CARDS_LIMIT),
      params[:max_id],
      params[:since_id]
    )

    scope
  end

  def insert_pagination_headers
    set_pagination_headers(next_path, prev_path)
  end

  def next_path
    if records_continue?
      api_v1_group_preview_cards_url pagination_params(max_id: pagination_max_id)
    end
  end

  def prev_path
    unless @preview_cards.empty?
      api_v1_group_preview_cards_url pagination_params(since_id: pagination_since_id)
    end
  end

  def pagination_max_id
    @preview_cards.last.id
  end

  def pagination_since_id
    @preview_cards.first.id
  end

  def records_continue?
    @preview_cards.size == limit_param(DEFAULT_PREVIEW_CARDS_LIMIT)
  end

  def pagination_params(core_params)
    params
      .slice(:limit)
      .permit(:limit)
      .merge(core_params)
  end
end
