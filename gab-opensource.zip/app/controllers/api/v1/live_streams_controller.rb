# frozen_string_literal: true

class Api::V1::LiveStreamsController < Api::BaseController
  before_action -> { doorkeeper_authorize! :read, :'read:statuses' }, only: [:index, :show, :by_username]
  before_action -> { doorkeeper_authorize! :write, :'write:statuses' }, only: [:create, :destroy, :status, :mute_chat, :unmute_chat]
  before_action :require_user!, only: [:create, :destroy, :status, :mute_chat, :unmute_chat]
  before_action :set_live_stream, only: [:show, :destroy, :status, :mute_chat, :unmute_chat]
  before_action :ensure_host_owns_stream!, only: [:destroy, :status, :mute_chat, :unmute_chat]

  def index
    @live_streams = LiveStream.active.by_newest.includes(:account)
    render json: @live_streams, each_serializer: REST::LiveStreamSerializer
  end

  def show
    viewer_token = nil
    if current_account
      begin
        is_muted = LiveStreamMute.muted?(@live_stream.account_id, current_account.id)
        gab_token = LiveStreamTokenService.mint(current_account)
        response = jump_api_post('/api/broadcast/join', {
          streamId: @live_stream.stream_id,
          is_muted: is_muted,
        }, gab_token)
        viewer_token = response['viewerToken'] if response
      rescue => e
        Rails.logger.error "LiveStreams#show: failed to get viewer token: #{e.message}"
      end
    end

    stream_json = ActiveModelSerializers::SerializableResource.new(
      @live_stream, serializer: REST::LiveStreamSerializer
    ).as_json
    stream_json[:viewer_token] = viewer_token
    stream_json[:livekit_url] = response['serverUrl'] if response
    stream_json[:jump_url] = jump_web_url
    render json: stream_json
  end

  def create
    unless current_account.is_pro?
      return render json: { error: 'Gab PRO subscription required to go live' }, status: 403
    end

    existing = LiveStream.active.find_by(account: current_account)
    if existing
      begin
        gab_token_cleanup = LiveStreamTokenService.mint(current_account)
        jump_api_post('/api/broadcast/end', { streamId: existing.stream_id }, gab_token_cleanup)
      rescue => e
        Rails.logger.error "LiveStreams#create: failed to end previous stream #{existing.stream_id} on Jump: #{e.message}"
      end
      existing.end_stream!
      Rails.logger.info "LiveStreams#create: replaced previous stream #{existing.stream_id} for account #{current_account.id}"
    end

    title = params[:title].presence || "#{current_account.display_name}'s Live"
    source_type = permitted_source_type
    encoder_protocol = permitted_encoder_protocol(source_type)
    stream_orientation = permitted_stream_orientation(source_type)
    gab_token = LiveStreamTokenService.mint(current_account)

    response = jump_api_post('/api/broadcast/create', jump_create_payload(title, source_type, encoder_protocol), gab_token)
    unless response && response['streamId']
      Rails.logger.error "LiveStreams#create: Jump returned nil or missing streamId. JUMP_API_URL=#{jump_api_url}"
      return render json: { error: "Failed to create broadcast. Streaming server (#{jump_api_url}) may be unreachable." }, status: 502
    end

    jump_source_type = response['sourceType'].presence || source_type
    jump_protocol = response['protocol'].presence || encoder_protocol

    @live_stream = LiveStream.create!(
      account: current_account,
      stream_id: response['streamId'],
      title: title,
      status: :live,
      started_at: Time.current,
      stream_orientation: stream_orientation,
      source_type: jump_source_type,
      encoder_protocol: jump_protocol,
      ingress_id: response['ingressId'],
      ingress_url: response['ingressUrl'],
      stream_key: response['streamKey'],
    )

    NotifyLiveStreamFollowersWorker.perform_async(@live_stream.id)

    stream_json = serialize_stream(@live_stream)
    stream_json[:host_token] = response['hostToken'] if response['hostToken'].present?
    stream_json[:livekit_url] = response['serverUrl'] if response['serverUrl'].present?
    stream_json[:ingress_url] = response['ingressUrl'] if response['ingressUrl'].present?
    stream_json[:stream_key] = response['streamKey'] if response['streamKey'].present?
    stream_json[:ingress_id] = response['ingressId'] if response['ingressId'].present?
    stream_json[:source_type] = jump_source_type
    stream_json[:encoder_protocol] = jump_protocol if jump_protocol.present?
    stream_json[:jump_url] = jump_web_url
    render json: stream_json
  end

  def status
    gab_token = LiveStreamTokenService.mint(current_account)
    response = jump_api_get("/api/broadcast/#{@live_stream.stream_id}/status", gab_token)
    unless response
      return render json: { error: "Failed to fetch broadcast status from #{jump_api_url}" }, status: 502
    end

    if response['viewerCount'].present? && response['viewerCount'].to_i != @live_stream.viewer_count
      ActiveRecord::Base.connected_to(role: :writing) do
        @live_stream.update_column(:viewer_count, response['viewerCount'].to_i)
      end
    end

    render json: {
      id: @live_stream.id.to_s,
      stream_id: @live_stream.stream_id,
      source_type: @live_stream.source_type,
      encoder_protocol: @live_stream.encoder_protocol,
      ingress_url: @live_stream.ingress_url,
      stream_key: @live_stream.stream_key,
      jump_url: jump_web_url,
      broadcast_status: {
        source_type: response['sourceType'],
        encoder_protocol: response['encoderProtocol'],
        encoder_status: response['encoderStatus'],
        is_live: response['isLive'],
        viewer_count: response['viewerCount'],
        started_at: response['startedAt'],
        live_since: response['liveSince'],
        ingress_id: response['ingressId'],
        ingress_participant_identity: response['ingressParticipantIdentity'],
        primary_publisher_identity: response['primaryPublisherIdentity'],
      },
    }
  end

  def by_username
    account = Account.find_local!(params[:username])
    @live_stream = LiveStream.active.find_by(account: account)

    unless @live_stream
      return render json: { error: 'User is not currently live', username: params[:username] }, status: 404
    end

    viewer_token = nil
    response = nil
    if current_account
      begin
        is_muted = LiveStreamMute.muted?(@live_stream.account_id, current_account.id)
        gab_token = LiveStreamTokenService.mint(current_account)
        response = jump_api_post('/api/broadcast/join', {
          streamId: @live_stream.stream_id,
          is_muted: is_muted,
        }, gab_token)
        viewer_token = response['viewerToken'] if response
      rescue => e
        Rails.logger.error "LiveStreams#by_username: failed to get viewer token: #{e.message}"
      end
    end

    stream_json = ActiveModelSerializers::SerializableResource.new(
      @live_stream, serializer: REST::LiveStreamSerializer
    ).as_json
    stream_json[:viewer_token] = viewer_token
    stream_json[:livekit_url] = response['serverUrl'] if response
    stream_json[:jump_url] = jump_web_url
    render json: stream_json
  rescue ActiveRecord::RecordNotFound
    render json: { error: 'User not found' }, status: 404
  end

  def destroy
    begin
      gab_token = LiveStreamTokenService.mint(current_account)
      jump_api_post('/api/broadcast/end', { streamId: @live_stream.stream_id }, gab_token)
    rescue => e
      Rails.logger.error "LiveStreams#destroy: failed to end on Jump: #{e.message}"
    end

    @live_stream.end_stream!
    render json: @live_stream, serializer: REST::LiveStreamSerializer
  end

  def mute_chat
    target_account = Account.find_by(username: params[:username])
    unless target_account
      return render json: { error: 'User not found' }, status: 404
    end

    if target_account.id == current_account.id
      return render json: { error: 'Cannot mute yourself' }, status: 422
    end

    mute = LiveStreamMute.find_or_create_by!(
      account: current_account,
      muted_account: target_account,
    )

    jump_mute_participant(target_account.id)

    render json: { muted: true, username: target_account.username }
  rescue ActiveRecord::RecordNotUnique
    render json: { muted: true, username: target_account.username }
  rescue => e
    Rails.logger.error "LiveStreams#mute_chat: #{e.message}"
    render json: { error: 'Failed to mute user' }, status: 500
  end

  def unmute_chat
    target_account = Account.find_by(username: params[:username])
    unless target_account
      return render json: { error: 'User not found' }, status: 404
    end

    LiveStreamMute.where(
      account: current_account,
      muted_account: target_account,
    ).destroy_all

    render json: { muted: false, username: target_account.username }
  end

  private

  def set_live_stream
    @live_stream = LiveStream.find(params[:id])
  end

  def ensure_host_owns_stream!
    return if @live_stream.account_id == current_account.id

    render json: { error: 'Only the host can manage this stream' }, status: 403
  end

  def jump_api_url
    ENV.fetch('JUMP_API_URL', 'https://jump.gab.com')
  end

  def jump_web_url
    ENV.fetch('JUMP_WEB_URL', jump_api_url)
  end

  def jump_api_post(path, body, token)
    parsed_jump_request(path, Net::HTTP::Post, token) do |request|
      request['Content-Type'] = 'application/json'
      request.body = body.to_json
    end
  end

  def jump_api_get(path, token)
    parsed_jump_request(path, Net::HTTP::Get, token)
  end

  def parsed_jump_request(path, request_class, token)
    url = "#{jump_api_url}#{path}"
    Rails.logger.info "Jump API call: #{request_class.name.demodulize.upcase} #{url}"
    uri = URI.parse(url)
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = uri.scheme == 'https'
    http.open_timeout = 5
    http.read_timeout = 10

    request = request_class.new(uri.request_uri)
    request['Authorization'] = "Bearer #{token}"
    yield request if block_given?

    response = http.request(request)
    Rails.logger.info "Jump API response: #{response.code} #{response.body.truncate(500)}"
    parsed = JSON.parse(response.body)

    if response.code.to_i >= 400
      Rails.logger.error "Jump API returned #{response.code}: #{parsed}"
      return nil
    end

    parsed
  rescue => e
    Rails.logger.error "Jump API error (#{path}): #{e.class}: #{e.message}"
    Rails.logger.error "JUMP_API_URL is set to: #{jump_api_url}"
    nil
  end

  def serialize_stream(stream)
    ActiveModelSerializers::SerializableResource.new(
      stream, serializer: REST::LiveStreamSerializer
    ).as_json
  end

  def jump_create_payload(title, source_type, encoder_protocol)
    payload = {
      title: title,
      sourceType: source_type,
    }
    payload[:protocol] = encoder_protocol if encoder_protocol.present?
    payload
  end

  def permitted_source_type
    value = params[:source_type].presence
    return value if LiveStream::SOURCE_TYPES.include?(value)

    'browser_host'
  end

  def permitted_encoder_protocol(source_type)
    return nil unless source_type == 'external_encoder'

    value = params[:protocol].presence
    return value if LiveStream::ENCODER_PROTOCOLS.include?(value)

    'rtmp'
  end

  def permitted_stream_orientation(source_type = permitted_source_type)
    value = params[:stream_orientation].presence
    return value if %w(portrait landscape).include?(value)
    return 'landscape' if source_type == 'external_encoder'

    nil
  end

  def jump_mute_participant(muted_account_id)
    gab_token = LiveStreamTokenService.mint(current_account)
    jump_api_post("/api/broadcast/#{@live_stream.stream_id}/mute", {
      participantIdentity: "viewer-#{muted_account_id}",
    }, gab_token)
  rescue => e
    Rails.logger.error "LiveStreams#jump_mute_participant: failed to mute on Jump: #{e.message}"
  end
end
