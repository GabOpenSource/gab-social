# frozen_string_literal: true

class Api::V1::ReportsController < Api::BaseController
  before_action -> { doorkeeper_authorize! :write, :'write:reports' }, only: [:create]
  before_action :require_user!

  MAX_REPORTS_DAILY_LIMIT = 5

  def create
    if daily_limit_reached?(current_account) && !current_account.user&.staff?
      render json: { error: 'Daily report limit reached, suggest mute/block instead.' }, status: 429
      return
    end
    @report = ReportService.new.call(
      current_account,
      reported_account,
      status_ids: reported_status_ids,
      comment: report_params[:comment],
      forward: report_params[:forward],
      category: report_params[:category]
    )

    render json: {success: true}
  end

  private

  def daily_limit_reached?(account)
    Report.where(account: account).where('created_at > ?', 1.day.ago).count >= MAX_REPORTS_DAILY_LIMIT
  end

  def reported_status_ids
    reported_account.statuses.find(status_ids).pluck(:id)
  end

  def status_ids
    Array(report_params[:status_ids])
  end

  def reported_account
    Account.find(report_params[:account_id])
  end

  def report_params
    params.permit(:account_id, :comment, :forward, :category, status_ids: [])
  end
end
