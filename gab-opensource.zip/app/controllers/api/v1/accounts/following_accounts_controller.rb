# frozen_string_literal: true

class Api::V1::Accounts::FollowingAccountsController < Api::BaseController
  before_action -> { doorkeeper_authorize! :read, :'read:accounts' }
  before_action :set_account
  after_action :insert_pagination_headers

  def index
    @accounts = load_accounts
    render json: @accounts, each_serializer: REST::AccountSerializer
  end

  private

  def set_account
    @account = Account.find(params[:account_id])
  end

  def load_accounts
    return [] if hide_results? || current_account.nil? || @account.suspended?

    default_accounts.merge(paginated_follows).to_a
  end

  def hide_results?
    # if not my acount and not pro, dont allow
    if @account.id.to_s != current_account.id.to_s && !current_account.is_pro?
      return false
    end

    (@account.user_hides_network? && current_account.id != @account.id) || (current_account && @account.blocking?(current_account))
  end

  def default_accounts
    scope = Account.includes(:passive_relationships, :account_stat).references(:passive_relationships)
    scope = scope.where(is_verified: true) if @account.verified? && @account.id != current_account.id
    scope.where(suspended_at: nil)
      .where('COALESCE(accounts.spam_flag, 0) != 1')
      .joins(:user).where(users: { disabled: false })
  end

  def paginated_follows
    Follow.where(account: @account).paginate_by_max_id(
      limit_param(DEFAULT_ACCOUNTS_LIMIT),
      params[:max_id],
      params[:since_id]
    )
  end

  def insert_pagination_headers
    set_pagination_headers(next_path, prev_path)
  end

  def next_path
    if records_continue?
      api_v1_account_following_index_url pagination_params(max_id: pagination_max_id)
    end
  end

  def prev_path
    unless @accounts.empty?
      api_v1_account_following_index_url pagination_params(since_id: pagination_since_id)
    end
  end

  def pagination_max_id
    @accounts.last.passive_relationships.first.id
  end

  def pagination_since_id
    @accounts.first.passive_relationships.first.id
  end

  def records_continue?
    @accounts.size == limit_param(DEFAULT_ACCOUNTS_LIMIT)
  end

  def pagination_params(core_params)
    params.slice(:limit).permit(:limit).merge(core_params)
  end
end
