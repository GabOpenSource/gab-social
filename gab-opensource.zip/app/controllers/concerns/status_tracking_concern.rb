# frozen_string_literal: true

module StatusTrackingConcern
  extend ActiveSupport::Concern

  def track_status_views(statuses)
    return if statuses.nil?

    statuses = Array(statuses)
    return if statuses.empty?

    ids_to_track = []
    statuses.each do |s|
      if s.reblog_of_id && s.reblog
        ids_to_track << s.reblog_of_id.to_s if s.reblog.attrs['was_pro'] == true
      elsif s.attrs['was_pro'] == true
        ids_to_track << s.id.to_s
      end
    end

    return if ids_to_track.empty?
    StathouseStatWorker.perform_async('status', ids_to_track, 'view', current_account&.id)
  end
end
