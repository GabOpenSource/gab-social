# frozen_string_literal: true

module Admin
  class FavouritesController < BaseController
    before_action :set_account

    PER_PAGE = 40

    def index
      authorize :account, :index?
      @favourites = @account.favourites
        .includes(status: [:account, :media_attachments])
        .order(id: :desc)
        .page(params[:page]).per(PER_PAGE)
    end

    def set_account
      @account = Account.find(params[:account_id])
    end
  end
end
