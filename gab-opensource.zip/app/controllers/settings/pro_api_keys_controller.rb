# frozen_string_literal: true

class Settings::ProApiKeysController < Settings::BaseController
  layout 'admin'

  before_action :authenticate_user!
  before_action :require_pro!

  def show
  end

  def create
    current_user.generate_pro_api_key!
    @newly_generated = true
    render :show
  end

  def destroy
    current_user.revoke_pro_api_key!
    redirect_to settings_pro_api_key_path, notice: 'Your Pro API key has been revoked.'
  end

  private

  def require_pro!
    unless current_user.pro_active?
      redirect_to settings_billing_upgrade_path,
        alert: 'A GabPRO subscription is required to use the Pro API.'
    end
  end
end
