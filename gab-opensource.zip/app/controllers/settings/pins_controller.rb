# frozen_string_literal: true

class Settings::PinsController < Settings::BaseController
  layout 'admin'

  before_action :authenticate_user!
  before_action :set_account

  def index
    @profile_pins = @account.status_pins.order('status_pins.created_at DESC')
    profile_statuses = Status.unscope(:where, :order).where(id: @profile_pins.map(&:status_id)).includes(:account).index_by(&:id)

    group_accounts = GroupAccount.where(account_id: @account.id, role: [:admin, :moderator])
    @group_role_map = group_accounts.map { |ga| [ga.group_id, ga.role] }.to_h

    @managed_groups = Group.where(id: @group_role_map.keys)

    @group_pins_by_group = {}
    @group_statuses_by_id = {}
    @managed_groups.each do |group|
      pins = group.group_pinned_statuses.order('group_pinned_statuses.id DESC')
      @group_pins_by_group[group.id] = pins
      status_ids = pins.map(&:status_id)
      loaded = Status.unscope(:where, :order).where(id: status_ids).includes(:account).index_by(&:id)
      @group_statuses_by_id.merge!(loaded)
    end

    @profile_statuses_by_id = profile_statuses
  end

  def destroy
    if params[:type] == 'group'
      destroy_group_pin
    else
      destroy_profile_pin
    end
  end

  private

  def set_account
    @account = current_user.account
  end

  def destroy_profile_pin
    pin = @account.status_pins.find_by(status_id: params[:id])
    if pin
      pin.destroy!
      redirect_to settings_pins_path, notice: I18n.t('pins.removed_profile_pin')
    else
      redirect_to settings_pins_path, alert: I18n.t('pins.pin_not_found')
    end
  end

  def destroy_group_pin
    group = Group.joins(:group_accounts)
      .where(group_accounts: { account_id: @account.id, role: [:admin, :moderator] })
      .find(params[:group_id])

    pin = group.group_pinned_statuses.find_by(status_id: params[:id])
    if pin
      pin.destroy!
      redirect_to settings_pins_path, notice: I18n.t('pins.removed_group_pin')
    else
      redirect_to settings_pins_path, alert: I18n.t('pins.pin_not_found')
    end
  end
end
