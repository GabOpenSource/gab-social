# frozen_string_literal: true

class Oauth::AuthorizationsController < Doorkeeper::AuthorizationsController
  skip_before_action :authenticate_resource_owner!

  before_action :store_current_location
  before_action :authenticate_resource_owner!
  before_action :set_cache_headers

  include Localized

  private

  def store_current_location
    store_location_for(:user, request.url)
  end

  def render_success
    if skip_authorization? || (matching_token? && !truthy_param?('force_login'))
      ActiveRecord::Base.connected_to(role: :writing) do
        redirect_or_render authorize_response
      end
    elsif Doorkeeper.configuration.api_only
      render json: pre_auth
    else
      render :new
    end
  end

  def truthy_param?(key)
    ActiveModel::Type::Boolean.new.cast(params[key])
  end

  def set_cache_headers
    response.headers['Cache-Control'] = 'no-cache, no-store, max-age=0, must-revalidate'
  end
end
