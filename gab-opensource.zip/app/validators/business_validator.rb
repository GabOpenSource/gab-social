# frozen_string_literal: true

class BusinessValidator < ActiveModel::Validator
  MAX_CHARS_BUSINESS_NAME = 512
  MAX_CHARS_BUSINESS_TAGLINE = 512
  MAX_CHARS_BUSINESS_DESCRIPTION = 3072

  def validate(business)
    business.errors.add(:base, 'You must add a name.') if business.name.nil? || business.name.length === 0
    business.errors.add(:base, "Name cannot exceed #{MAX_CHARS_BUSINESS_NAME} characters.") if business.name.length > MAX_CHARS_BUSINESS_NAME
    business.errors.add(:base, 'You must add a tagline.') if business.tagline.nil? || business.tagline.length === 0
    business.errors.add(:base, "Tagline cannot exceed #{MAX_CHARS_BUSINESS_TAGLINE} characters.") if business.tagline.length > MAX_CHARS_BUSINESS_TAGLINE
    business.errors.add(:base, 'You must add a description.') if business.description.nil? || business.description.length === 0
    business.errors.add(:base, "Description cannot exceed #{MAX_CHARS_BUSINESS_DESCRIPTION}.") if business.description.length > MAX_CHARS_BUSINESS_DESCRIPTION
    
    # business.errors.add(:base, 'You must enter a website.') if business.websites.size === 0

    business.errors.add(:base, 'You must select at least 1 category.') if business.categories.size === 0
    business.errors.add(:base, 'Please select categories.') if !categories_exist?(business.categories)

    # only on create!
    return if !business.created_at.nil?

    business.errors.add(:base, "You have already created a business. You can only 1 business per account. Email support@gab.com for help.") if limit_reached?(business)
  end

  private

  def categories_exist?(category_ids)
    category_ids = category_ids.map(&:to_i)
    existing_categories_count = BusinessCategory.where(id: category_ids).count
    existing_categories_count == category_ids.length
  end

  def limit_reached?(business)
    count = 10
    Business.where(account_id: business.account_id).count >= count
  end

end
