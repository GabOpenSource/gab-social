# frozen_string_literal: true

class MarketplaceListingLimitValidator < ActiveModel::Validator
  MAX_LISTINGS = 50

  def validate(marketplaceListing)
    # only on create!
    return if !marketplaceListing.created_at.nil?
    # Unlimited if for business
    # return if !marketplaceListing.business_id&.nil?
    return if !marketplaceListing.business_id.nil?
  
    marketplaceListing.errors.add(:base, "You can create a maximum of #{MAX_LISTINGS} listings per week") if limit_reached?(marketplaceListing)
  end

  private

  def limit_reached?(marketplaceListing)
    count = MAX_LISTINGS
    MarketplaceListing.where(account: marketplaceListing.account)
      .where('created_at > ?', 7.days.ago)
      .count >= count
  end

end
