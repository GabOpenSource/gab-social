# frozen_string_literal: true

class UnfavouriteLimitValidator < ActiveModel::Validator
  HOURLY_UNLIKE_LIMIT = 20

  def validate(unfavourite)
    return if unfavourite.account.nil?
    unfavourite.errors.add(:base, 'Hourly un-like limit reached. Please slow down.') if hourly_limit_reached?(unfavourite.account)
  end

  private

  def hourly_limit_reached?(account)
    Unfavourite.where(account: account).where('created_at > ?', 1.hour.ago).count >= HOURLY_UNLIKE_LIMIT
  end
end
  
