# frozen_string_literal: true

class REST::MarketplaceListingSerializer < ActiveModel::Serializer
  attributes :id, :title, :description, :tags, :location, :created_at,
             :status_i, :status_s, :condition, :price, :is_expired, :runtime_seconds,
             :saves, :price_label, :url, :description_html, :cta, :analytics,
             :account_id, :media_attachment_ids, :attrs, :business_id, :location_object

  
  belongs_to :business, serializer: REST::BusinessSerializer, if: :business_exists?
  belongs_to :account, serializer: REST::AccountSerializer, unless: :exclude_account?
  belongs_to :marketplace_listing_category, serializer: REST::MarketplaceListingCategorySerializer
  has_many :media_attachments, serializer: REST::MediaAttachmentSerializer, unless: :exclude_media?

  def description_html
    Formatter.instance.formatGroupDescription(object.description).strip
  end

  def is_expired
    object.is_expired?
  end

  def runtime_seconds
    object.runtime_seconds
  end

  def id
    object.id.to_s
  end

  def business_id
    object.business_id&.to_s
  end

  def account_id
    if !object.business_id.nil? && !is_owner?
      return nil
    else
      object.account_id.to_s if !object.account_id.nil?
    end
  end

  def media_attachment_ids
    if !object.media_attachment_order.nil? && !object.media_attachment_order.empty?
      object.media_attachment_order
    else 
      if !object.media_attachments.nil?
        object.media_attachments.map { |m| m.id.to_s }
      end
    end
  end

  def saves
    object.marketplace_listing_saves.count
  end

  def analytics
    return nil if !is_owner?
    return nil if object.business_id.nil?
    # return [{event_action: "view", count: 22350923}] # TESTING
    return StathouseRetrievalService.instance.get_counts('marketplace_listing', object.id)
  end

  def price_label
    if object.price == 0
      return "FREE"
    else
      whole_number = (object.price % 1).zero?
      precision = whole_number ? 0 : 2
      ActionController::Base.helpers.number_to_currency(object.price, precision: precision)
    end
  end

  def url
    "https://#{ENV['LOCAL_DOMAIN']}/marketplace/item/#{object.id.to_s}"
  end

  def condition
    MarketplaceListing.conditions[object.condition]
  end

  def status_i
    MarketplaceListing.statuses[object.status]
  end

  def status_s
    object.status_s
  end

  def exclude_media?
    instance_options && instance_options[:exclude_media]
  end

  def exclude_account?
    (!object.business_id.nil? && !is_owner?) || (instance_options && instance_options[:exclude_account])
  end

  def business_exists?
    !object.business_id.nil?
  end

  def is_owner?
    return defined?(current_user) && !current_user.nil? && !current_user.account.nil? && object.account_id.to_s == current_user.account.id.to_s
  end

  def attrs
    return [] unless object.attrs && object.respond_to?(:marketplace_listing_category)

    category_attrs = MarketplaceListingAttributes::ATTRIBUTES[object.marketplace_listing_category.slug.to_sym]
        
    return [] unless category_attrs
    
    result = category_attrs.map do |attr|
      value = object.attrs[attr[:key].to_s]

      # For select fields, get the clean title matching the value
      if attr[:type] == 'select'
        option = attr[:options].find { |opt| opt[:value] == value }
        clean_value = option ? option[:title] : value
      elsif attr[:type] == 'boolean'
        clean_value = (value == true || value == "true") ? 'Yes' : 'No'
      else
        clean_value = value
      end

      {
        value: clean_value,
        title: attr[:title],
        type: attr[:type],
        key: attr[:key]
      }
    end

    result.reject { |item| item[:value].nil? || item[:value] == 'undefined' }
  end

  def current_user?
    !current_user.nil?
  end

end
