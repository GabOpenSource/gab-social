# frozen_string_literal: true

class REST::PreviewCardSerializer < ActiveModel::Serializer
  include RoutingHelper

  attributes :id, :url, :title, :description, :type,
             :provider_name, :provider_url,  :html,
             :width, :height, :image, :embed_url, :updated_at,
             :gab_content_type

  def image
    url = object.image? ? full_asset_url(object.image.url(:original)) : nil
    # url = !url.nil? ? url.sub("https://media.", "https://") : nil
    url
  end

  def gab_content_type
    return nil if object.url.nil?

    parsed_url = URI.parse(object.url)
    if ['gab.com', 'develop.gab.com', 'localhost'].include?(parsed_url.host)
      if parsed_url.path.match(/^\/groups/)
        return 1
      elsif parsed_url.path.match(/^\/feeds/)
        return 2
      elsif parsed_url.path.match(/^\/marketplace\/item/)
        return 3
      else
        return nil
      end
    else
      return nil
    end
  end
end
