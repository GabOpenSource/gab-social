# frozen_string_literal: true

class REST::StatusSerializer < ActiveModel::Serializer
  attributes :id, :created_at, :revised_at, :in_reply_to_id, :in_reply_to_account_id,
             :sensitive, :spoiler_text, :visibility, :language, :uri,
             :url, :direct_replies_count, :replies_count, :reblogs_count, :pinnable, :pinnable_by_group,
             :favourites_count, :quote_of_id, :expires_at, :has_quote, :bookmark_collection_id,
             :quotes_count, :reaction_id, :reactions_counts, :is_reply, :account_id,
             :media_attachment_ids, :conversation_id, :analytics, :reblog_of_id, :quote_of_id, :group_id,
             :status_context_id, :preview_card_id, :poll_id

  attribute :favourited, if: :current_user?
  attribute :reblogged, if: :current_user?
  attribute :muted, if: :current_user?

  attribute :content
  attribute :text, if: :owned_by_user
  attribute :markdown, if: :owned_by_user

  belongs_to :reblog, serializer: REST::StatusSerializer, unless: :exclude_reblog?
  belongs_to :quote, serializer: REST::QuotedStatusSerializer, unless: :exclude_quote?
  belongs_to :account, serializer: REST::AccountSerializer, unless: :exclude_account?
  belongs_to :group, serializer: REST::GroupSerializer, unless: :exclude_group?
  belongs_to :status_context, serializer: REST::StatusContextSerializer, unless: :exclude_status_context?

#  has_many :media_attachments, serializer: REST::MediaAttachmentSerializer, unless: :exclude_media?
#  has_many :pending_media_attachments, serializer: REST::PendingMediaAttachmentSerializer, unless: :exclude_media?
  attribute :media_attachments, unless: :exclude_media?

  has_many :ordered_mentions, key: :mentions
  has_many :tags
  has_many :emojis, serializer: REST::CustomEmojiSerializer

  has_one :preview_card, key: :card, serializer: REST::PreviewCardSerializer, unless: :exclude_preview_card?
  has_one :preloadable_poll, key: :poll, serializer: REST::PollSerializer, unless: :exclude_poll?

  def media_attachments
    pending_media_attachments = object.pending_media_attachments.where(media_attachment_id: nil)
    media_attachments = object.media_attachments
    # filter media_attachments and pending_media_attachments to de-duplicate by file_fingerprint attribute
    seen_fingerprints = []
    media_attachments = media_attachments.select { |m|
      next(true) if m.file_fingerprint.nil?
      if seen_fingerprints.include?(m.file_fingerprint)
        false
      else
        seen_fingerprints.push(m.file_fingerprint)
        true
      end
    }
    (media_attachments.map { |m| REST::MediaAttachmentSerializer.new(m) } + pending_media_attachments.map { |m| REST::PendingMediaAttachmentSerializer.new(m) }).sort_by { |m| m.id }
  end

  def id
    object.id.to_s
  end

  def account_id
    object.account_id.to_s if !object.account_id.nil?
  end

  def reblog_of_id
    object.reblog_of_id.to_s if !object.reblog_of_id.nil?
  end
  
  def quote_of_id
    object.quote_of_id.to_s if !object.quote_of_id.nil?
  end 
  
  def group_id
    object.group_id.to_s if !object.group.nil?
  end

  def status_context_id
    object.status_context_id.to_s if !object.status_context_id.nil?
  end

  def preview_card_id
    object.preview_card.id.to_s if !object.preview_card.nil?
  end
  
  def poll_id
    object.poll_id.to_s if !object.poll_id.nil?
  end

  def media_attachment_ids
    ids = []
    if !object.media_attachments.nil?
      object.media_attachments.map { |m| ids.push(m.id.to_s) }
    end
    if !object.pending_media_attachments.nil?
      object.pending_media_attachments.map { |m| ids.push(m.id.to_s) }
    end
    ids
  end

  def analytics
    return nil if !current_user?
    # Disabled following line to show PRO status view counts to all users
    # return nil if object.account_id != current_user.account_id
    return nil if !object.attrs['was_pro']
    return StathouseRetrievalService.instance.get_counts('status', object.id)
  end

  def conversation_id
    object.conversation_id.to_s if !object.conversation_id.nil?
  end

  def direct_replies_count
    object.direct_replies_count
  end

  def quotes_count
    object.quotes_count
  end

  def replies_count
    object.replies_count
  end

  def in_reply_to_id
    object.in_reply_to_id&.to_s
  end

  def in_reply_to_account_id
    object.in_reply_to_account_id&.to_s
  end

  def is_reply
    object.reply?
  end

  def quote_of_id
    object.quote_of_id&.to_s
  end

  def current_user?
    defined?(current_user) && !current_user.nil?
  end
  
  def visibility
    # This visibility is masked behind "private"
    # to avoid API changes because there are no
    # UX differences
    if object.limited_visibility?
      'private'
    else
      object.visibility
    end
  end

  def uri
    "/#{object.account.username}/posts/#{object.id}"
  end

  def content
    blocked_by_status_owner = false
    if instance_options && instance_options[:relationships]
      blocked_by_status_owner = instance_options[:relationships].blocked_by_map[object.account_id] || false
    end
    spammer = false
    if object.account && object.account.spam_flag == 1
      spammer = true
    end
    
    if blocked_by_status_owner
      # if they commented on MY status, let me see it
      if object.in_reply_to_account_id.to_s == current_user.account.id.to_s
        # continue...
      else 
        return '[HIDDEN – USER BLOCKS YOU]'
      end
    elsif spammer
      return '[HIDDEN – MARKED AS SPAM]'
    end

    if object.markdown != nil && object.markdown.length > 0
      Formatter.instance.format(object, use_markdown: true).strip
    else
      Formatter.instance.format(object).strip
    end
  end

  def rich_content
    blocked_by_status_owner = false
    if instance_options && instance_options[:relationships]
      blocked_by_status_owner = instance_options[:relationships].blocked_by_map[object.account_id] || false
    end
    spammer = false
    if object.account && object.account.spam_flag == 1
      spammer = true
    end

    if blocked_by_status_owner
      # if they commented on MY status, let me see it
      if object.in_reply_to_account_id.to_s == current_user.account.id.to_s
        # continue...
      else
        return '[HIDDEN – USER BLOCKS YOU]'
      end
    elsif spammer
      return '[HIDDEN – MARKED AS SPAM]'
    end
    
    Formatter.instance.format(object, use_markdown: true).strip
  end

  def plain_markdown
    blocked_by_status_owner = false
    if instance_options && instance_options[:relationships]
      blocked_by_status_owner = instance_options[:relationships].blocked_by_map[object.account_id] || false
    end
    spammer = false
    if object.account && object.account.spam_flag == 1
      spammer = true
    end

    if blocked_by_status_owner
      # if they commented on MY status, let me see it
      if object.in_reply_to_account_id.to_s == current_user.account.id.to_s
        # continue...
      else 
        return '[HIDDEN – USER BLOCKS YOU]'
      end
    elsif spammer
      return '[HIDDEN – MARKED AS SPAM]'
    end
    
    return object.markdown
  end

  def url
    TagManager.instance.url_for(object)
  end

  def favourited
    if instance_options && instance_options[:relationships]
      !!instance_options[:relationships].favourites_map[object.id] || false
    else
      current_user.account.favourited?(object)
    end
  end

  def muted
    if instance_options && instance_options[:relationships]
      instance_options[:relationships].mutes_map[object.conversation_id] || false
    else
      current_user.account.muting_conversation?(object.conversation)
    end
  end

  def favourites_count
    object.favourites_count
  end

  def reaction_id
    if instance_options && instance_options[:relationships]
      instance_options[:relationships].favourites_map[object.id] || nil
    else
      if current_user?
        current_user&.account&.reaction_id(object)
      else
        nil
      end
    end
  end

  def reblogged
    if instance_options && instance_options[:relationships]
      instance_options[:relationships].reblogs_map[object.id] || false
    else
      if current_user?
        current_user.account.reblogged?(object)
      else
        nil
      end
    end
  end

  def bookmarked
    return
  end

  def pinned
    return
  end

  def owned_by_user
    current_user? && current_user.account_id == object.account_id
  end

  PINNABLE_VISIBILITIES = %w(public unlisted).freeze
  def pinnable
    owned_by_user &&
      !object.reblog? &&
      PINNABLE_VISIBILITIES.include?(object.visibility)
  end

  def pinned_by_group
    return
  end

  def pinnable_by_group
    object.group_id?
  end

  def ordered_mentions
    object.active_mentions.to_a.sort_by(&:id)
  end

  def bookmark_collection_id
    instance_options[:bookmark_collection_id]
  end

  def exclude_media?
    instance_options && instance_options[:exclude_media]
  end

  def exclude_account?
    instance_options && instance_options[:exclude_account]
  end

  def exclude_reblog?
    instance_options && instance_options[:exclude_reblog]
  end

  def exclude_quote?
    instance_options && instance_options[:exclude_quote]
  end

  def exclude_group?
    instance_options && instance_options[:exclude_group]
  end

  def exclude_status_context?
    instance_options && instance_options[:exclude_status_context]
  end
  
  def exclude_preview_card?
    instance_options && instance_options[:exclude_preview_card]
  end

  def exclude_poll?
    instance_options && instance_options[:exclude_poll]
  end

  class ApplicationSerializer < ActiveModel::Serializer
    attributes :name, :website
  end

  class MentionSerializer < ActiveModel::Serializer
    attributes :id, :username, :url, :acct

    def id
      object.account_id.to_s
    end

    def username
      object.account_username
    end

    def url
      TagManager.instance.url_for(object.account)
    end

    def acct
      object.account_acct
    end
  end

  class TagSerializer < ActiveModel::Serializer
    include RoutingHelper

    attributes :name, :url

    def url
      "/tags/#{object.name}"
    end
  end
end
