# frozen_string_literal: true

class REST::BusinessAccountSerializer < ActiveModel::Serializer
  include RoutingHelper

  attributes :id, :business_id, :account_id, :title, :role,
             :visibility, :created_at

  def id
    object.id.to_s
  end

  def account_id
    object.account_id.to_s
  end

  def business_id
    object.business_id.to_s
  end

  def visibility
    object.visibility == 1 ? 'visible' : 'hidden'
  end

end
