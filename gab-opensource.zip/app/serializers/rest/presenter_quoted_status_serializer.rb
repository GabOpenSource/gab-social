# frozen_string_literal: true

class REST::PresenterQuotedStatusSerializer < ActiveModel::Serializer
  attributes :id, :created_at, :revised_at, :in_reply_to_id, :in_reply_to_account_id,
             :sensitive, :spoiler_text, :visibility, :language, :uri,
             :url, :direct_replies_count, :replies_count, :reblogs_count, :pinnable, :pinnable_by_group,
             :favourites_count, :quote_of_id, :expires_at, :has_quote, :bookmark_collection_id,
             :quotes_count, :reaction_id, :reactions_counts, :is_reply, :account_id,
             :media_attachment_ids, :conversation_id, :account, :group,
             :analytics, :reblog_of_id, :quote_of_id, :group_id,
             :status_context_id, :preview_card_id, :poll_id

  attribute :favourited, if: :current_user?
  attribute :reblogged, if: :current_user?
  attribute :muted, if: :current_user?

  attribute :content
  attribute :text, if: :owned_by_user
  attribute :markdown, if: :owned_by_user

  # belongs_to :account, serializer: REST::AccountSerializer
  # belongs_to :group, serializer: REST::GroupSerializer

#  has_many :media_attachments, serializer: REST::MediaAttachmentSerializer
  attribute :media_attachments

  has_many :ordered_mentions, key: :mentions
  has_many :tags
  has_many :emojis, serializer: REST::CustomEmojiSerializer

  has_one :preview_card, key: :card, serializer: REST::PreviewCardSerializer
  has_one :preloadable_poll, key: :poll, serializer: REST::PollSerializer

  def analytics
    return nil if !current_user?
    # Disabled following line to show PRO status view counts to all users
    # return nil if object.account_id != current_user.account_id
    return nil if !object.attrs['was_pro']
    if instance_options[:data] && instance_options[:data].view_counts
      return instance_options[:data].view_counts[object.id.to_s]
    end
    return StathouseRetrievalService.instance.get_counts('status', object.id)
  end

  def media_attachments
    ma = []
    pma = []
    seen_fingerprints = []
    if instance_options && instance_options[:data] && instance_options[:data].media_attachments
      instance_options[:data].media_attachments.each { |m|
        next unless m.status_id == object.id 
        next if seen_fingerprints.include?(m.file_fingerprint)
        if !m.file_fingerprint.nil?
          seen_fingerprints.push(m.file_fingerprint)
        end
        ma.push(m)
      }
    else
      ma = object.media_attachments.to_a
    end
    if instance_options && instance_options[:data] && instance_options[:data].pending_media_attachments
      instance_options[:data].pending_media_attachments.each { |m|
        next unless m.status_id == object.id
        next if seen_fingerprints.include?(m.file_fingerprint)
        if !m.file_fingerprint.nil?
          seen_fingerprints.push(m.file_fingerprint)
        end
        pma.push(m)
      }
    else
      pma = object.pending_media_attachments.where(media_attachment_id: nil).to_a
    end
    (ma.map { |m| 
      REST::MediaAttachmentSerializer.new(m, data: instance_options[:data]) 
    } + pma.map { |m| 
      REST::PendingMediaAttachmentSerializer.new(m, data: instance_options[:data]) 
    }).sort_by { |m| m.id }

  end

  def id
    object.id.to_s
  end

  def reblog
    return nil if exclude_reblog? || object.nil? || object.reblog.nil?
    REST::PresenterStatusSerializer.new(object.reblog, data: instance_options[:data])
  end

  def quote
    return nil if exclude_quote? || object.nil? || object.quote.nil?
    REST::PresenterQuotedStatusSerializer.new(object.quote, data: instance_options[:data])
  end
  
  def account
    return nil if exclude_account?
    REST::AccountSerializer.new(presenter_account, data: instance_options[:data])
  end

  def group
    return nil if object.group_id.nil?
    REST::GroupSerializer.new(presenter_group, data: instance_options[:data])
  end

  def direct_replies_count
    if instance_options[:data] && instance_options[:data].stats
      instance_options[:data].stats[object.id]&.direct_replies_count || 0
    else
      object.direct_replies_count
    end
  end

  def quotes_count
    if instance_options[:data] && instance_options[:data].stats
      instance_options[:data].stats[object.id]&.quotes_count || 0
    else
      object.quotes_count
    end
  end

  def replies_count
    if instance_options[:data] && instance_options[:data].stats
      instance_options[:data].stats[object.id]&.replies_count || 0
    else
      object.replies_count
    end
  end

  def reblogs_count
    if instance_options[:data] && instance_options[:data].stats
      instance_options[:data].stats[object.id]&.reblogs_count || 0
    else
      object.reblogs_count
    end
  end

  def in_reply_to_id
    object.in_reply_to_id&.to_s
  end

  def in_reply_to_account_id
    object.in_reply_to_account_id&.to_s
  end

  def is_reply
    object.reply?
  end

  def reblog_of_id
    object.reblog_of_id&.to_s
  end

  def quote_of_id
    object.quote_of_id&.to_s
  end

  def preview_card_id
    object.preview_card.id.to_s if !object.preview_card.nil?
  end

  def current_user?
    defined?(current_user) && !current_user.nil?
  end

  def visibility
    # This visibility is masked behind "private"
    # to avoid API changes because there are no
    # UX differences
    if object.limited_visibility?
      'private'
    else
      object.visibility
    end
  end

  def uri
    "/#{object.account.username}/posts/#{object.id}"
  end

  def content
    blocked_by_status_owner = false
    if instance_options && instance_options[:relationships]
      blocked_by_status_owner = instance_options[:relationships].blocked_by_map[object.account_id] || false
    end
    spammer = false
    if object.account && object.account.spam_flag == 1
      spammer = true
    end

    if blocked_by_status_owner
      '[HIDDEN – USER BLOCKS YOU]'
    elsif spammer
      '[HIDDEN – MARKED AS SPAM]'
    else
      if object.markdown != nil && object.markdown.length > 0
        Formatter.instance.format(object, use_markdown: true).strip
      else
        Formatter.instance.format(object).strip
      end
    end
  end

  def rich_content
    blocked_by_status_owner = false
    if instance_options && instance_options[:relationships]
      blocked_by_status_owner = instance_options[:relationships].blocked_by_map[object.account_id] || false
    end
    spammer = false
    if object.account && object.account.spam_flag == 1
      spammer = true
    end

    if blocked_by_status_owner
      '[HIDDEN – USER BLOCKS YOU]'
    elsif spammer
      '[HIDDEN – MARKED AS SPAM]'
    else
      Formatter.instance.format(object, use_markdown: true).strip
    end
  end

  def plain_markdown
    blocked_by_status_owner = false
    if instance_options && instance_options[:relationships]
      blocked_by_status_owner = instance_options[:relationships].blocked_by_map[object.account_id] || false
    end
    spammer = false
    if object.account && object.account.spam_flag == 1
      spammer = true
    end

    if blocked_by_status_owner
      '[HIDDEN – USER BLOCKS YOU]'
    elsif spammer
      '[HIDDEN – MARKED AS SPAM]'
    else
      object.markdown
    end
  end

  def url
    TagManager.instance.url_for(object)
  end

  def favourited
    if instance_options && instance_options[:relationships]
      !!instance_options[:relationships].favourites_map[object.id] || false
    else
      current_user.account.favourited?(object)
    end
  end

  def muted
    if instance_options && instance_options[:relationships]
      instance_options[:relationships].mutes_map[object.conversation_id] || false
    else
      current_user.account.muting_conversation?(object.conversation)
    end
  end

  def favourites_count
    object.favourites_count
  end

  def reaction_id
    if instance_options && instance_options[:relationships]
      instance_options[:relationships].favourites_map[object.id] || nil
    else
      if current_user?
        current_user&.account&.reaction_id(object)
      else
        nil
      end
    end
  end

  def reblogged
    if instance_options && instance_options[:relationships]
      instance_options[:relationships].reblogs_map[object.id] || false
    else
      if current_user?
        current_user.account.reblogged?(object)
      else
        nil
      end
    end
  end

  def bookmarked
    return
  end

  def pinned
    return
  end

  def owned_by_user
    current_user? && current_user.account_id == object.account_id
  end

  PINNABLE_VISIBILITIES = %w(public unlisted).freeze
  def pinnable
    owned_by_user &&
      !object.reblog? &&
      PINNABLE_VISIBILITIES.include?(object.visibility)
  end

  def pinned_by_group
    return
  end

  def pinnable_by_group
    object.group_id?
  end

  def ordered_mentions
    object.active_mentions.to_a.sort_by(&:id)
  end

  def bookmark_collection_id
    instance_options[:bookmark_collection_id]
  end

  def exclude_account?
    instance_options && instance_options[:exclude_account]
  end

  def exclude_reblog?
    instance_options && instance_options[:exclude_reblog]
  end

  def exclude_quote?
    instance_options && instance_options[:exclude_quote]
  end

  class ApplicationSerializer < ActiveModel::Serializer
    attributes :name, :website
  end

  class MentionSerializer < ActiveModel::Serializer
    attributes :id, :username, :url, :acct

    def id
      object.account_id.to_s
    end

    def username
      object.account_username
    end

    def url
      TagManager.instance.url_for(object.account)
    end

    def acct
      object.account_acct
    end
  end

  class TagSerializer < ActiveModel::Serializer
    include RoutingHelper

    attributes :name, :url

    def url
      "/tags/#{object.name}"
    end
  end

  private

  def presenter_account
    account = nil
    if instance_options[:data] && instance_options[:data].accounts
      account = instance_options[:data].accounts[object.account_id]
    end
    account = object.account if account.nil?
    account
  end

  def presenter_group
    group = nil
    if instance_options[:data] && instance_options[:data].groups
      group = instance_options[:data].groups[object.group_id]
    end
    group = object.group if group.nil?
    group
  end
end
