# frozen_string_literal: true

class REST::BusinessSerializer < ActiveModel::Serializer
  include RoutingHelper

  attributes :id, :name, :tagline, :description, :status, :websites, 
  :locations, :categories, :keywords, :coupons, :hours, :cta, :url,
  :logo_thumbnail_url, :promotions, :pro_tier, :pro_expires_at, :pro_tier_name,
  :cover_image_url, :phone_number, :analytics, :shortcut_count

  def id
    object.id.to_s
  end

  def websites
    object.websites.map { |website| format_website(website) }
  end

  def cta
    if !object.cta.nil? && !object.cta["link"].nil? && !object.cta["title"].nil?
      return {
        link: format_website(object.cta["link"]),
        title: object.cta["title"],
      }
    end
  end

  def shortcut_count
    return nil if !is_owner?
    return nil if object.pro_tier.nil? || object.pro_tier == 0
    # : todo :
    0
  end

  def analytics
    return nil if !is_owner?
    # return nil if object.pro_tier.nil? || object.pro_tier == 0
    # return [{event_action: "view", count: 20943}] # TESTING
    return StathouseRetrievalService.instance.get_counts('business', object.id)
  end

  def pro_tier
    !object.pro_tier.nil? ? Business.pro_tiers[object.pro_tier] : nil
  end

  def url
    "https://#{ENV['LOCAL_DOMAIN']}/business/#{object.id.to_s}"
  end

  def pro_tier_name
    p = !object.pro_tier.nil? ? Business.pro_tiers[object.pro_tier] : nil
    return 'Bronze' if p == 1
    return 'Silver' if p == 2
    return 'Gold' if p == 3
    return nil
  end

  def categories
    ActiveModel::SerializableResource.new(
      BusinessCategory.where(id: object.categories),
      each_serializer: REST::BusinessCategorySerializer
    ).as_json
  end

  def cover_url(**options)
    full_asset_url(object.cover.url, **options)
  end

  def avatar_url(**options)
    full_asset_url(object.avatar.url, **options)
  end

  def cover_image_url
    cover_url(cloudflare_options: { width: 1440, fit: 'scale-down' })
  end

  def logo_thumbnail_url
    avatar_url(cloudflare_options: { width: 320, fit: 'scale-down' })
  end

  private

  def is_owner?
    return defined?(current_user) && !current_user.nil? && !current_user.account.nil? && object.account_id.to_s == current_user.account.id.to_s
  end
  
  def format_website(website)
    # Check if the website starts with http:// or https://
    if website.present? && !website.match?(/\Ahttp(s)?:\/\//)
      "https://#{website}"
    else
      website
    end
  end

end
