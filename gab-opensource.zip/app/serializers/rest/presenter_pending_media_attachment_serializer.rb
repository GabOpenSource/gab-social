# frozen_string_literal: true

class REST::PresenterPendingMediaAttachmentSerializer < ActiveModel::Serializer
  include RoutingHelper

  attributes :id, :type, :url, :meta, :account_id, :status_url,
             :status_id, :file_name, :preview_url, :source_mp4,
             :description, :blurhash, :file_content_type, :file_fingerprint

  def id
    object.id.to_s
  end

  def file_name
    object.file_file_name.to_s
  end

  def account_id
    object.account_id.to_s if !object.account_id.nil?
  end

  def status_id
    object.status_id.to_s if !object.status_id.nil?
  end
  
  def url
    if object.type == "video"
      return nil
    end

    full_asset_url(object.file.url(:original))
  end

  def preview_url
    if object.file_file_name and object.file_file_name.start_with? "gab://media/"
      return clean_migrated_url[0]
    end

    if object.type == "video"
      full_asset_url('video-missing.png', { skip_pipeline: true })
    else
      url = full_asset_url(object.file.url(:original))
      # remove media subdomain for videos
      # random 50% chance
      #if rand(2) == 1
      #  url = url.sub("https://media.", "https://")
      #end
      url
    end
  end

  def source_mp4
    if object.type == "image" || object.type == "gifv" || object.type == "unknown"
      return nil
    else 
      url = full_asset_url(object.file.url(:original))
      #url = url.sub("https://media.", "https://")
      url
    end
  end

  def status_url
    return nil if object.status_id.nil?

    return "/#{presenter_account.username}/posts/#{object.status_id.to_s}"
  end
  
  def meta
    object.file.meta
  end

  private

  def presenter_account
    account = nil
    if instance_options[:data] && instance_options[:data].accounts
      account = instance_options[:data].accounts[object.account_id]
    end
    account = object.account if account.nil?
    account
  end

end
