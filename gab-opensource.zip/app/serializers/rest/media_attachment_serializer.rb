# frozen_string_literal: true

class REST::MediaAttachmentSerializer < ActiveModel::Serializer
  include RoutingHelper

  attributes :id, :type, :url, :preview_url, :source_mp4,
             :remote_url, :meta, :account_id, :status_url,
             :status_id, :marketplace_listing_id, :file_name,
             :description, :blurhash, :file_content_type,
             :lowres_mp4, :file_fingerprint

  def id
    object.id.to_s
  end

  def file_name
    object.file_file_name.to_s
  end

  def account_id
    object.account_id.to_s if !object.account_id.nil?
  end

  def status_id
    object.status_id.to_s if !object.status_id.nil?
  end

  def status_url
    return nil if object.status_id.nil?

    return "/#{object.account.username}/posts/#{object.status_id.to_s}"
  end
  
  def marketplace_listing_id
    object.marketplace_listing_id.to_s if !object.marketplace_listing_id.nil?
  end

  def clean_migrated_url
    object
      .file_file_name
      .sub("gab://media/", "")
      .gsub("https://gabfiles.blob.core.windows.net/", "https://gab.com/media/")
      .gsub("https://files.gab.com/file/files-gab/", "https://gab.com/media/")
      .gsub("https://f002.backblazeb2.com/file/files-gab/", "https://gab.com/media/")
      .split("|")
  end

  def url
    if object.type == "video"
      return nil
    end

    if object.file_file_name and object.file_file_name.start_with? "gab://media/"
      return clean_migrated_url[1]
    end

    full_asset_url(object.file.url(:original))
  end

  def source_mp4
    if object.type == "image" || object.type == "gifv" || object.type == "unknown"
      return nil
    else
      url = full_asset_url(object.file.url(:playable))
      # remove media subdomain for videos
      # random 50% chance
      #if rand(2) == 1
      #  url = url.sub("https://media.", "https://")
      #end
      url  
    end
  end

  def lowres_mp4
    if object.type == "image" || object.type == "gifv" || object.type == "unknown"
      return nil
    else 
      url = full_asset_url(object.file.url(:lowres))
      # remove media subdomain for videos
      # random 50% chance
      #if rand(2) == 1
      #  url = url.sub("https://media.", "https://")
      #end
      url
    end
  end

  def remote_url
    object.remote_url.presence
  end

  def preview_url
    if object.file_file_name and object.file_file_name.start_with? "gab://media/"
      return clean_migrated_url[0]
    end

    url = full_asset_url(object.file.url(:small))
    # remove media subdomain for thumbnails
    #url = url.sub("https://media.", "https://")
    url
  end

  def meta
    object.file.meta
  end

end
