# frozen_string_literal: true

class REST::PendingStatusSerializer < ActiveModel::Serializer
  attributes :id, :created_at, :params

  has_many :media_attachments, serializer: REST::MediaAttachmentSerializer
  has_many :pending_media_attachments, serializer: REST::PendingMediaAttachmentSerializer

  def id
    object.id.to_s
  end

  def params
    object.params.without(:application_id)
  end
end
