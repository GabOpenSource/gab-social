# frozen_string_literal: true

class REST::StatusTimelineSerializer < ActiveModel::Serializer

  # Define the default options
  DEFAULT_OPTIONS = {
    exclude_reblog: true,
    exclude_quote: true,
    exclude_account: true,
    exclude_group: true,
    exclude_status_context: true,
    exclude_media: true,
    exclude_preview_card: true,
    exclude_poll: true
  }.freeze

  type 'statuses'

  def initialize(object, options = {})
    super
    @statuses = object
    @all_statuses = all_statuses
    @current_user = options[:current_user]
    @current_account = @current_user&.account if @current_user
    @options = the_options
    @data = instance_options[:data]
  end

  def attributes(*args)
    {
      t: @statuses.map(&:id).map(&:to_s),
      s: simplify_keys(serialized_statuses, Simplifiers::StatusSimplifier),
      a: simplify_keys(presenter_related_accounts(Account, :account_id, REST::PresenterAccountSerializer), Simplifiers::AccountSimplifier),
      g: simplify_keys(unique_related_objects(Group, :group_id, REST::PresenterGroupSerializer), Simplifiers::GroupSimplifier),
      p: unique_related_objects(Poll, :poll_id, REST::PollSerializer),
      sc: unique_related_objects(StatusContext, :status_context_id, REST::StatusContextSerializer),
      ma: simplify_media_attachment_keys(unique_related_objects_with_medias, Simplifiers::MediaAttachmentSimplifier),
      pc: unique_related_objects_with_associations(PreviewCard, :preview_cards, REST::PreviewCardSerializer),
    }
  end

  private

  def remove_nulls(hash)
    hash.delete_if { |_, v| v.nil? }
  end

  def the_options
    DEFAULT_OPTIONS.merge(instance_options)
  end

  def all_statuses
    return [] if object.nil? || object.empty?

    object.flat_map do |status|
      items = [status, status.reblog, status.quote]
  
      # Check if status.reblog exists and has a quote.
      items << status.reblog.quote if status.reblog&.quote
  
      items.compact
    end
  end

  def serialized_statuses
    @all_statuses.map { |status| remove_nulls(REST::PresenterStatusSerializer.new(status, @options).serializable_hash) }
  end

  def presenter_related_accounts(klass, foreign_key, serializer)
    if @data && @data.accounts
      @data.accounts.values.map { |account| serializer.new(account, @options).serializable_hash }
    else
      unique_related_objects(klass, foreign_key, serializer)
    end
  end

  def unique_related_objects(klass, foreign_key, serializer)
    if klass == Account && instance_options[:data] && instance_options[:data].accounts
      return instance_options[:data].accounts.values.map { |account| remove_nulls(serializer.new(account, @options).serializable_hash) }
    end
    if klass == Group && instance_options[:data] && instance_options[:data].groups
      return instance_options[:data].groups.values.map { |group| remove_nulls(serializer.new(group, @options).serializable_hash) }
    end
    if klass == Poll && instance_options[:data] && instance_options[:data].polls
      return instance_options[:data].polls.values.map { |poll| serializer.new(poll, @options).serializable_hash }
    end
    if klass == GroupCategories && instance_options[:data] && instance_options[:data].group_categories
      return instance_options[:data].group_categories.values.map { |group_category| serializer.new(group_category, @options).serializable_hash }
    end
    if klass == StatusContext && instance_options[:data] && instance_options[:data].status_contexts
      return instance_options[:data].status_contexts.values.map { |status_context| serializer.new(status_context, @options).serializable_hash }
    end
    related_objects = klass.where(id: @all_statuses.pluck(foreign_key))
    related_objects.map { |object| serializer.new(object, @options).serializable_hash }
  rescue StandardError => e
    raise "Error serializing #{klass.name.downcase}: #{e.message}"
  end

  def unique_related_objects_with_medias
    associated_objects = @all_statuses

    serialized_response = associated_objects.map do |object|
      ma = []
      pma = []
      seen_fingerprints = []
      if instance_options && instance_options[:data] && instance_options[:data].media_attachments
        instance_options[:data].media_attachments.each { |m|
          next unless m.status_id == object.id 
          next if seen_fingerprints.include?(m.file_fingerprint)
          if !m.file_fingerprint.nil?
            seen_fingerprints.push(m.file_fingerprint)
          end
          ma.push(m)
        }
      else
        ma = object.media_attachments.to_a
      end
      if instance_options && instance_options[:data] && instance_options[:data].pending_media_attachments
        instance_options[:data].pending_media_attachments.each { |m|
          next unless m.status_id == object.id
          next if seen_fingerprints.include?(m.file_fingerprint)
          if !m.file_fingerprint.nil?
            seen_fingerprints.push(m.file_fingerprint)
          end
          pma.push(m)
        }
      else
        pma = object.pending_media_attachments.where(media_attachment_id: nil).to_a
      end
      (ma.map { |m| 
        REST::PresenterMediaAttachmentSerializer.new(m, data: instance_options[:data]) 
      } + pma.map { |m| 
        REST::PresenterPendingMediaAttachmentSerializer.new(m, data: instance_options[:data]) 
      }).sort_by { |m| m.id }
    end

    serialized_response.flatten.map(&:serializable_hash).sort_by { |hash| -hash[:id] }
  rescue StandardError => e
    raise "Error serializing media associations: #{e.message}"
  end

  def unique_related_objects_with_associations(klass, association_name, serializer)
    if klass == PreviewCard && instance_options[:data] && instance_options[:data].preview_cards
      return instance_options[:data].preview_cards.values.map { |preview_card| serializer.new(preview_card, @options).serializable_hash }
    end
    associated_ids = @all_statuses.flat_map(&association_name).map(&:id).uniq
    related_objects = klass.where(id: associated_ids)

    related_objects.map { |object| serializer.new(object, @options).serializable_hash }
  rescue StandardError => e
    raise "Error serializing #{klass.name.downcase} associations: #{e.message}"
  end

  def simplify_keys(serialized_data, simplifier_class)
    if serialized_data.is_a?(Array)
      serialized_data.map do |data|
        data.transform_keys { |key| simplifier_class.simplified_key(key.to_sym) }
      end
    else
      serialized_data.transform_keys { |key| simplifier_class.simplified_key(key.to_sym) }
    end
  end

  def simplify_media_attachment_keys(serialized_data, simplifier_class)
    simplify_data = lambda do |data|
      simplified = data.transform_keys { |key| simplifier_class.simplified_key(key.to_sym) }
      simplified[:m] = simplifier_class.simplify_meta(simplified[:m])
      simplified
    end

    if serialized_data.is_a?(Array)
      serialized_data.map(&simplify_data)
    else
      simplify_data.call(serialized_data)
    end
  end

end
