# frozen_string_literal: true

module Admin::FilterHelper
  ACCOUNT_FILTERS      = %i(local remote by_domain active pending silenced suspended username display_name email ip note staff spam is_pro is_investor is_donor is_verified).freeze
  REPORT_FILTERS       = %i(resolved account_id target_account_id category).freeze
  INVITE_FILTER        = %i(available expired).freeze
  CUSTOM_EMOJI_FILTERS = %i(local remote by_domain shortcode).freeze
  TAGS_FILTERS         = %i(hidden).freeze
  INSTANCES_FILTERS    = %i(limited by_domain).freeze
  FOLLOWERS_FILTERS    = %i(relationship status by_domain activity order).freeze

  FILTERS = ACCOUNT_FILTERS + REPORT_FILTERS + INVITE_FILTER + CUSTOM_EMOJI_FILTERS + TAGS_FILTERS + INSTANCES_FILTERS + FOLLOWERS_FILTERS

  def filter_link_to(text, link_to_params, link_class_params = link_to_params)
    new_url = filtered_url_for(link_to_params)
    new_class = filtered_url_for(link_class_params)
    link_to text, new_url, class: filter_link_class(new_class)
  end

  def table_link_to(icon, text, path, **options)
    link_to safe_join([fa_icon(icon), text]), path, options.merge(class: 'table-action-link')
  end

  def selected?(more_params)
    new_url = filtered_url_for(more_params)
    filter_link_class(new_url) == 'selected'
  end

  private

  def filter_params(more_params)
    x = controller_request_params.merge(more_params)
    x
  end

  def filter_link_class(new_url)
    filtered_url_for(controller_request_params) == new_url ? 'selected' : ''
  end

  def filtered_url_for(url_params)
    url_for filter_params(url_params)
  end

  def controller_request_params
    params.permit(FILTERS)
  end
end
