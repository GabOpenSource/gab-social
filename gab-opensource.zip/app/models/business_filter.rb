# frozen_string_literal: true

class BusinessFilter
  attr_reader :params

  def initialize(params)
    @params = params
  end

  def results
    scope = Business
    params.each do |key, value|
      scope = scope.merge scope_for(key, value) if !value.nil? && !value.empty? && key != 'sort'
    end

    sort_option = params[:sort]

    if !sort_option.nil?
      case sort_option
      when "newest_to_oldest"
        scope = scope.order(created_at: :desc)
      when "oldest_to_newest"
        scope = scope.order(created_at: :asc)
      end
    end

    scope
  end

  def scope_for(key, value)
    case key.to_sym
    when :id
      Business.where(id: value)
    when :name
    when :title
      Business.matching(:name, :contains, value)
    when :account_id
      Business.where(account_id: value)
    when :status
      Business.where(status: value)
    when :pro_tier
    when :tier
      Business.where(pro_tier: value)
    when :by_spam
      Business.joins(:account).where(accounts: { spam_flag: 1 })
        .or(Business.joins(:account).where.not(accounts: { suspended_at: nil }))
    when :by_pro
      Business.includes(:account).where(accounts: { is_pro: true })
    when :by_new
      Business.joins(:account).where('accounts.created_at >= ?', 14.days.ago)
    # when :tagline
    #   Business.matching(:tagline, :contains, value)
    # when :description
    #   Business.matching(:tagline, :contains, value)
    else
      raise "Unknown filter: #{key}"
    end
  end
end
