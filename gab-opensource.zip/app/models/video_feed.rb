class VideoFeed
  RECENTQUERY = <<-SQL
    with my_groups as (
      select ga.group_id as id
      from group_accounts ga
      where ga.account_id = :id
      and not exists(select from group_removed_accounts gra where ga.group_id = gra.group_id and ga.account_id = gra.account_id)
    ),   
    cte as
    (
      select
        s.id
      from statuses s
      where
        (s.account_id = :id 
          or s.visibility = 0)
        and s.id > :hard_limit_id
        and s.reblog_of_id is null
        and s.reply is false
        and s.in_reply_to_id IS NULL
        and s.tombstoned_at IS NULL
        and not exists(select mm.target_account_id from mutes mm where mm.account_id = :id and mm.target_account_id = s.account_id)
        and not exists(select bb.target_account_id from blocks bb where bb.account_id = :id and bb.target_account_id = s.account_id)
        and exists(select from media_attachments ma where ma.status_id = s.id and ma.type = 2)
        and exists(select 1 from (select count(*) as cnt from media_attachments ma where ma.status_id = s.id) as t where t.cnt = 1)
        and (
          :only_following is false or (
            :only_following is true and (
              s.account_id = :id
              or exists(
                  select ff.target_account_id from follows ff where ff.account_id = :id and ff.target_account_id = s.account_id
              )
            )
          )
        )
        and (
          (
            :only_clips is true and
            exists(select ma.id from media_attachments ma where ma.status_id = s.id and (ma.file_meta -> 'small' ->> 'aspect')::float <= 0.8)
          ) or (
            :only_clips is false and
            exists(select ma.id from media_attachments ma where ma.status_id = s.id and (ma.file_meta -> 'small' ->> 'aspect')::float > 0.8)
          )
        )
        and (
          s.group_id IS NULL
          or exists(
            select from groups g
            where g.id = s.group_id
            and (not g.is_private or g.id in (select id from my_groups))
          )
        )
        and (:max_id is null or s.id < :max_id)
        and (:min_id is null or s.id > :min_id)
      order by s.id desc
      limit :limit
    )
    select
      so.*
    from cte
    inner join statuses so on cte.id = so.id
    order by so.id desc
  SQL

  TOPQUERY = <<-SQL
    with cte as
    (
      select
        s.id, (ss.favourites_count + ss.reblogs_count) as score
      from statuses s
      join status_stats ss on s.id = ss.status_id
      where
        s.visibility = 0
        and ss.status_id > :hard_limit_id
        and s.reblog_of_id is null
        and s.reply is false
        and s.in_reply_to_id IS NULL
        and s.tombstoned_at IS NULL
        and s.group_id IS NULL
        and exists(select from media_attachments ma where ma.status_id = s.id and ma.type = 2)
        and exists(select 1 from (select count(*) as cnt from media_attachments ma where ma.status_id = s.id) as t where t.cnt = 1)
        and (
          (
            :only_clips is true and
            exists(select ma.id from media_attachments ma where ma.status_id = s.id and (ma.file_meta -> 'small' ->> 'aspect')::float <= 0.8)
          ) or (
            :only_clips is false and
            exists(select ma.id from media_attachments ma where ma.status_id = s.id and (ma.file_meta -> 'small' ->> 'aspect')::float > 0.8)
          )
        )
    )
    select
      score, so.*
    from cte
    inner join statuses so on cte.id = so.id
    order by cte.score desc
    limit :limit
    offset ((:page - 1) * :limit)
  SQL

  QUERY_OPTIONS = {
    'newest' => [RECENTQUERY, 6.months.ago.change(hour: 0)],
    'recent' => [RECENTQUERY, 2.days.ago.change(hour: 0)],
    'hot' => [TOPQUERY, 8.hours.ago.change(min: 0)],
    'top' => [TOPQUERY, 1.day.ago.change(min: 0)],
    'top_today' => [TOPQUERY, 1.day.ago.change(min: 0)],
    'top_weekly' => [TOPQUERY, 1.week.ago.change(hour: 0)],
    'top_monthly' => [TOPQUERY, 1.month.ago.change(hour: 0)],
    'top_yearly' => [TOPQUERY, 1.year.ago.change(hour: 0)],
    'top_all_time' => [TOPQUERY, 7.years.ago.change(hour: 0)],
  }

  def initialize(account)
    @type    = :home

    if !account.nil?
      @id      = account.id
      @account = account
    else
      @id      = nil
      @account = nil
    end
  end

  def get(limit = 21, max_id = nil, since_id = nil, min_id = nil, sort_by_value = nil, page = nil, only_following = false, only_clips = false)
    sort_by_value ||= 'newest'
    query, duration = QUERY_OPTIONS[sort_by_value]
    if !query || (page && page.to_i > 250)
      return(Status.none)
    end

    opts = { id: @id, limit: limit, min_id: min_id, max_id: max_id, only_following: only_following, only_clips: only_clips }
    opts[:hard_limit_id] = GabSocial::Snowflake.id_at(duration)
    opts[:page] = page if ['top', 'top_today', 'top_weekly', 'top_monthly', 'top_yearly', 'top_all_time', 'hot'].include?(sort_by_value)
    opts[:page] = 1 if opts[:page].nil?

    ActiveRecord::Base.connected_to(role: :reading) do
      Status.find_by_sql([query, opts])
    end
  end

end