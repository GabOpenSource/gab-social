# frozen_string_literal: true

class Form::DeleteStatusesConfirmation
  include ActiveModel::Model

  attr_accessor :password
end
