# frozen_string_literal: true
# == Schema Information
#
# Table name: ai_agents
#
#  id         :bigint(8)        not null, primary key
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  name       :text             not null
#  model_code :text
#  type       :text             not null
#  account_id :bigint(8)        not null
#  endpoint   :text
#  active     :boolean          default(FALSE)
#  system     :text             not null
#  data       :jsonb
#

class AiAgent < ApplicationRecord

  validates :name, presence: true, uniqueness: true
  validates :account_id, presence: true, uniqueness: true
  validates :endpoint, presence: true

  after_commit :clear_cache
  
  self.inheritance_column = :_type_disabled

  private
  
  def clear_cache
    Rails.cache.delete("ai_agents")
  end

end
