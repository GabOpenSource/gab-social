# frozen_string_literal: true
# == Schema Information
#
# Table name: pending_media_attachments
#
#  id                  :integer          not null, primary key
#  file_file_name      :string
#  file_content_type   :string
#  file_file_size      :bigint(8)
#  file_updated_at     :datetime
#  status_id           :bigint(8)
#  scheduled_status_id :bigint(8)
#  account_id          :integer
#  media_attachment_id :integer
#  description         :string(1000)
#  blurhash            :string(100)
#  type                :integer          default("image"), not null
#  shortcode           :string(36)
#  file_fingerprint    :string(64)
#  created_at          :datetime         not null
#  updated_at          :datetime         not null
#  file_meta           :jsonb
#

class PendingMediaAttachment < ApplicationRecord
  self.inheritance_column = nil

#  after_commit :process_file, on: :create
  after_commit :update_media, on: :update

  enum type: [:image, :gifv, :video, :unknown]

  IMAGE_FILE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.webp', '.jfif'].freeze
  GIF_FILE_EXTENSIONS = ['.gif'].freeze
  WEBM_FILE_EXTENSIONS = ['.webm'].freeze
  VIDEO_FILE_EXTENSIONS = ['.mp4', '.m4v', '.mov'].freeze

  IMAGE_MIME_TYPES             = ['image/jpeg', 'image/png', 'image/webp'].freeze
  GIF_MIME_TYPES = ['image/gif'].freeze
  WEBM_MIME_TYPES = ['video/webm', 'audio/webm'].freeze
  VIDEO_MIME_TYPES             = ['video/mp4', 'video/quicktime', 'video/ogg', 'video/3gpp', 'application/octet-stream'].freeze

  BLURHASH_OPTIONS = {
    x_comp: 4,
    y_comp: 4,
  }.freeze

  IMAGE_STYLES = {
    original: {
      convert_options: '-strip',
      file_geometry_parser: FastGeometryParser,
    },
    small: {
      pixels: 160_000, # 400x400px
      file_geometry_parser: FastGeometryParser,
      blurhash: BLURHASH_OPTIONS,
    },
  }.freeze
      
  GIF_STYLES = {
    original: {
      file_geometry_parser: FastGeometryParser,
    },
  }.freeze

  VIDEO_STYLES = {
    small: {
      convert_options: {
        output: {
          'vf' => "\"scale='min(720,in_w)':'min(720,in_h)':force_original_aspect_ratio=decrease,pad=ceil(iw/2)*2:ceil(ih/2)*2\"",
        },
      },
      format: 'png',
      time: 0,
      file_geometry_parser: FastGeometryParser,
      blurhash: BLURHASH_OPTIONS,
    },
  }.freeze

  WEBM_STYLES = {
    small: {
      convert_options: {
        output: {
          'vf' => 'scale="min(720, iw):min(720, ih)":force_original_aspect_ratio=decrease',
        },
      },
      format: 'png',
      time: 0,
      file_geometry_parser: FastGeometryParser,
      blurhash: BLURHASH_OPTIONS,
    },
  }.freeze

  SIZE_LIMIT = 250.megabytes

  belongs_to :account,          inverse_of: :pending_media_attachments, optional: true
  belongs_to :status, inverse_of: :pending_media_attachments, optional: true
  belongs_to :scheduled_status, inverse_of: :pending_media_attachments, optional: true

  has_attached_file :file#,
  #                  styles: ->(f) { file_styles f },
  #                  processors: ->(f) { file_processors f },
  #                  convert_options: { all: '-strip +set modify-date +set create-date' }

  validates_attachment_content_type :file, content_type: IMAGE_MIME_TYPES + GIF_MIME_TYPES + VIDEO_MIME_TYPES + WEBM_MIME_TYPES
  validates_attachment_size :file, less_than: SIZE_LIMIT
#  remotable_attachment :file, SIZE_LIMIT

  include Attachmentable
  include Paginable

  #validates :account, presence: true
  validates :description, length: { maximum: 1000 }

  scope :attached,   -> {
    where.not(status_id: nil).or(
      where.not(scheduled_status_id: nil)
    )
  }
  scope :unattached, -> { where(status_id: nil, scheduled_status_id: nil) }
  scope :recent,     -> { reorder(id: :desc) }

  default_scope { order(id: :asc) }

  def to_param
    shortcode
  end

  def focus=(point)
    return if point.blank?

    x, y = (point.is_a?(Enumerable) ? point : point.split(',')).map(&:to_f)

    meta = file.instance_read(:meta) || {}
    meta['focus'] = { 'x' => x, 'y' => y }

    file.instance_write(:meta, meta)
  end

  def focus
    x = file.meta['focus']['x']
    y = file.meta['focus']['y']

    "#{x},#{y}"
  end

  before_create :prepare_description
  before_create :set_shortcode
  before_post_process :set_type_and_extension
  before_save :set_meta

  class << self
    def supported_mime_types
      IMAGE_MIME_TYPES + GIF_MIME_TYPES + VIDEO_MIME_TYPES + WEBM_MIME_TYPES
    end

    def supported_file_extensions
      IMAGE_FILE_EXTENSIONS + GIF_FILE_EXTENSIONS + VIDEO_FILE_EXTENSIONS + WEBM_FILE_EXTENSIONS
    end

    private

    def file_styles(f)
      if IMAGE_MIME_TYPES.include? f.instance.file_content_type
        IMAGE_STYLES
      elsif GIF_MIME_TYPES.include? f.instance.file_content_type
        GIF_STYLES
      elsif WEBM_MIME_TYPES.include? f.instance.file_content_type
        WEBM_STYLES
      else
        VIDEO_STYLES
      end
    end

    def file_processors(f)
      puts "file_processors"
      puts f.inspect
      if VIDEO_MIME_TYPES.include?(f.file_content_type) || WEBM_MIME_TYPES.include?(f.file_content_type)
        [:type_corrector]
      else
        [:type_corrector] #, :lazy_thumbnail]
      end
    end

  end

  private



  def process_file
    if type == "image"
      ProcessPendingMediaAttachmentWorker.perform_async(id)
    end
  end

  def update_media
    return if media_attachment_id.nil?
    attachment = MediaAttachment.where(id: media_attachment_id, status_id: nil, scheduled_status_id: nil).first
    return if attachment.nil?
    attachment.update!(status_id: status_id, scheduled_status_id: scheduled_status_id)
  end
      

  def set_shortcode
    self.type = :unknown if file.blank? && !type_changed?

    loop do
      self.shortcode = SecureRandom.urlsafe_base64(14)
      break if PendingMediaAttachment.find_by(shortcode: shortcode).nil?
    end
  end

  def prepare_description
    self.description = description.strip[0...420] unless description.nil?
  end

  def set_type_and_extension
    self.type = (VIDEO_MIME_TYPES.include?(file_content_type) || WEBM_MIME_TYPES.include?(file_content_type)) ? :video : :image
  end

  def set_meta
    meta = populate_meta
    return if meta == {}
    file.instance_write :meta, meta
  end

  def populate_meta
    meta = file.instance_read(:meta) || {}

    file.queued_for_write.each do |style, file|
      meta[style] = style == :small || image? ? image_geometry(file) : video_metadata(file)
    end

    meta
  end

  def image_geometry(file)
    width, height = FastImage.size(file.path)

    return {} if width.nil?

    {
      width:  width,
      height: height,
      size: "#{width}x#{height}",
      aspect: width.to_f / height.to_f,
    }
  end

  def video_metadata(file)
    movie = FFMPEG::Movie.new(file.path)

    return {} unless movie.valid?

    {
      width: movie.width,
      height: movie.height,
      frame_rate: movie.frame_rate,
      duration: movie.duration,
      bitrate: movie.bitrate,
    }
  end

end
