# == Schema Information
#
# Table name: business_categories
#
#  id                                       :bigint(8)        not null, primary key
#  created_at                               :datetime         not null
#  updated_at                               :datetime         not null
#  name                                     :string           default(""), not null
#  slug                                     :string           default(""), not null
#  description                              :string
#  cover_image_file_name                    :string
#  cover_image_content_type                 :string
#  cover_image_file_size                    :bigint(8)
#  cover_image_updated_at                   :datetime
#  top_level_category_id                    :integer
#  related_marketplace_listing_category_ids :integer          default([]), not null, is an Array
#

class BusinessCategory < ApplicationRecord

  LIMIT = 2.megabytes
  
  has_attached_file :cover_image, styles: { static: { format: 'png', convert_options: '-coalesce -strip' } }
  validates_attachment :cover_image, content_type: { content_type: 'image/png' }, size: { less_than: LIMIT }

  include Attachmentable
  
  belongs_to :top_level_category, class_name: 'BusinessCategory', optional: true

  scope :ordered, -> { reorder(id: :asc) }

  def self.find_category_and_descendants(category_id)
    # Find the initial category
    category = BusinessCategory.find_by(id: category_id)

    return [] unless category

    # Determine the top-level category ID
    top_level_id = category.top_level_category_id.presence || category.id

    # Find all categories that are either the top-level category
    # or have the same top_level_category_id
    category_ids = BusinessCategory.where("id = ? OR top_level_category_id = ?", top_level_id, top_level_id)
                                   .pluck(:id)

    category_ids
  end
  
end
