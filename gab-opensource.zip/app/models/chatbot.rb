# frozen_string_literal: true
# == Schema Information
#
# Table name: chatbots
#
#  id         :bigint(8)        not null, primary key
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  account_id :bigint(8)        not null
#  name       :text             not null
#  endpoint   :text             not null
#  token      :text             not null
#

class Chatbot < ApplicationRecord

  validates :name, presence: true, uniqueness: true
  validates :token, presence: true
  validates :account_id, presence: true, uniqueness: true
  validates :endpoint, presence: true, uniqueness: true

  after_commit :clear_cache
  
  def send_message(account, conversation_id, message)
    payload = { 
      account_id: account.id.to_s,
      conversation_id: conversation_id.to_s,
      is_pro: account.is_pro?,
      username: account.username,
      message: message,
      token: self.token 
    }
    headers = { 'Content-Type' => 'application/json' }
    begin
      uri = URI.parse(self.endpoint)
      response = Net::HTTP.post(uri, payload.to_json, headers)
      if response.code != '200'
        Rails.logger.error "Error posting to Chatbot #{self.name}: #{response.body}"
        reply_message(conversation_id, "Sorry, this bot appears to be offline, please try again later.")
      end
    rescue => e
      Rails.logger.error "Error posting to Chatbot #{self.name}: #{e}"
      reply_message(conversation_id, "Sorry, this bot appears to be offline, please try again later.")
    end
  end

  def reply_message(conversation_id, message, media_ids = nil)
    chat_account = Account.find(self.account_id)
    chat_conversation_account = chat_account.chat_conversation_accounts.find_by!(
      chat_conversation: conversation_id
    )
    duration = 14.days.from_now
    if message == "GabBotReplaceWithAdStatus"
      duration = 10.minutes.from_now
    elsif chat_account.is_pro?
      duration = 45.days.from_now
    end

    PostChatMessageService.new.call(
      chat_account,
      text: message,
      media_ids: media_ids,
      chat_conversation_account: chat_conversation_account,
      skip_validation: true,
      expiration: duration
    )
  end

  private
  
  def clear_cache
    Rails.cache.delete("chatbots")
  end

end
