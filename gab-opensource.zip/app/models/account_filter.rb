# frozen_string_literal: true

class AccountFilter
  attr_reader :params

  def initialize(params)
    @params = params
    set_defaults!
  end

  def results
    scope = Account.unscoped.includes(:user)

    params.each do |key, value|
      scope.merge!(scope_for(key, value.to_s.strip)) if value.present? && key != 'sort'
    end

    sort_option = params[:sort]

    if !sort_option.nil?
      case sort_option
      when "newest_to_oldest"
        scope = scope.order(created_at: :desc)
      when "oldest_to_newest"
        scope = scope.order(created_at: :asc)

      when "status_count_desc"
        scope = scope.joins(:account_stat).order('account_stats.statuses_count DESC')

      when "latest_status_desc"
        scope = scope.joins(:account_stat)
          .order(Arel.sql('CASE WHEN account_stats.last_status_at IS NULL THEN 1 ELSE 0 END, account_stats.last_status_at DESC'))

      when "reports_desc"
        scope = scope.joins(:targeted_reports)
          .group("accounts.id")
          .order("COUNT(reports.id) DESC")

      when "made_reports_desc"
        scope = scope.joins(:reports)
          .group("accounts.id")
          .order("COUNT(reports.id) DESC")

      when "following_desc"
        scope = scope.joins(:account_stat).order('account_stats.following_count DESC')
      when "followers_desc"
        scope = scope.joins(:account_stat).order('account_stats.followers_count DESC')

      when "blocked_by_desc"
        scope = scope.joins(:blocked_by)
          .group('accounts.id')
          .order('COUNT(blocks.account_id) DESC')

      when "blocking_desc"
        scope = scope.joins(:blocking)
          .group('accounts.id')
          .order('COUNT(blocks.target_account_id) DESC')

      when "joined_groups_count_desc"
        scope = scope.joins(:group_accounts)
          .group("accounts.id")
          .order("COUNT(group_accounts.id) DESC")
      
      when "removed_by_groups_count_desc"
        scope = scope.joins(:group_removed_accounts)
          .group('accounts.id')
          .order('COUNT(group_removed_accounts.group_id) DESC')

      when "like_count_desc"
        scope = scope.joins("LEFT JOIN favourites ON favourites.account_id = accounts.id")
          .group("accounts.id")
          .order("COUNT(favourites.id) DESC")

      when "unlike_count_desc"
        scope = scope.joins("LEFT JOIN unfavourites ON unfavourites.account_id = accounts.id")
          .group("accounts.id")
          .order("COUNT(unfavourites.id) DESC")

      when "unfollow_count_desc"
        scope = scope.joins(:unfollows)
          .group("accounts.id")
          .order("COUNT(unfollows.id) DESC")

      when "unfollowed_by_count_desc"
        scope = scope.joins(:targeted_unfollows)
          .group("accounts.id")
          .order("COUNT(unfollows.id) DESC")

      when "chat_conversation_count_desc"
        scope = scope.joins(:chat_conversation_accounts)
          .group("accounts.id")
          .order("COUNT(chat_conversation_accounts.id) DESC")

      when "chat_message_count_desc"
        scope = scope.joins(:chat_messages)
          .group("accounts.id")
          .order("COUNT(chat_messages.id) DESC")

      when "marketplace_listing_count_desc"
        scope = scope.joins(:marketplace_listings)
          .group("accounts.id")
          .order("COUNT(marketplace_listings.id) DESC")

      when "session_count_desc"
        scope = scope.joins(user: :session_activations)
          .group('accounts.id')
          .order('COUNT(session_activations.id) DESC')

      when "account_warning_count_desc"
        scope = scope.joins(:targeted_account_warnings)
          .group("accounts.id")
          .order("COUNT(account_warnings.id) DESC")
      
      when "uploaded_media_size"
        scope = scope.joins(:media_attachments)
          .group("accounts.id")
          .order("SUM(media_attachments.file_file_size) DESC")
          .select("accounts.*, SUM(media_attachments.file_file_size) as total_file_size")

      end
    end

    scope
  end

  private

  def set_defaults!
    params['local']  = '1' if params['remote'].blank?
    params['active'] = '1' if params['suspended'].blank? && params['silenced'].blank? && params['pending'].blank?
  end

  def scope_for(key, value)
    case key.to_s
    when 'local'
      Account.local
    when 'remote'
      Account.remote
    when 'by_domain'
      Account.where(domain: value)
    when 'active'
      Account.without_suspended
    when 'pending'
      accounts_with_users.merge User.pending
    when 'silenced'
      Account.silenced
    when 'suspended'
      Account.suspended
    when 'username'
      Account.matches_username(value)
    when 'display_name'
      Account.matches_display_name(value)
    when 'email'
      accounts_with_users.merge User.matches_email(value)
    when 'ip'
      valid_ip?(value) ? accounts_with_users.where('users.current_sign_in_ip <<= ?', value) : Account.none
    when 'staff'
      accounts_with_users.merge User.staff
    when "note"
      Account.matching(:note, :contains, value)
    when "status_count_gte"
      # : todo :
      Account.joins(:account_stat)
    when "sign_up_date_gte"
      Account.where("created_at >= ?", value)
    when "spam"
      Account.where(spam_flag: Account::SPAM_FLAG_CLASS_MAP[:spam])
    when "is_pro"
      Account.where(is_pro: true)
    when "is_investor"
      Account.where(is_investor: true)
    when "is_donor"
      Account.where(is_donor: true)
    when "is_verified"
      Account.where(is_verified: true)
    else
      raise "Unknown filter: #{key}"
    end
  end

  def accounts_with_users
    Account.joins(:user)
  end

  def valid_ip?(value)
    IPAddr.new(value) && true
  rescue IPAddr::InvalidAddressError
    false
  end
end
