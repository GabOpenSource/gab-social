# == Schema Information
#
# Table name: businesses
#
#  id                  :bigint(8)        not null, primary key
#  created_at          :datetime         not null
#  updated_at          :datetime         not null
#  name                :string(512)      default(""), not null
#  tagline             :string
#  description         :string
#  status              :integer          default("pending"), not null
#  websites            :string           default([]), not null, is an Array
#  categories          :string           default([]), not null, is an Array
#  keywords            :string           default([]), not null, is an Array
#  account_id          :bigint(8)        not null
#  cta                 :jsonb
#  avatar_file_name    :string
#  avatar_content_type :string
#  avatar_file_size    :integer
#  avatar_updated_at   :datetime
#  promotions          :integer          is an Array
#  pro_tier            :integer
#  pro_expires_at      :datetime
#  cover_file_name     :string
#  cover_content_type  :string
#  cover_file_size     :integer
#  cover_updated_at    :datetime
#  phone_number        :string
#  hours               :jsonb
#  locations           :jsonb
#  coupons             :jsonb
#

class Business < ApplicationRecord

  belongs_to :account
  has_many :business_accounts, dependent: :destroy
  has_many :accounts, through: :business_accounts

  include BusinessAvatar
  include BusinessCover
  include Attachmentable

  validates_with BusinessValidator

  after_initialize :set_default_promotions, if: :new_record?

  enum status: {
    pending: 0,
    rejected: 1,
    approved: 2,
  }, _suffix: 'business_status'

  enum pro_tier: {
    none: 0,
    bronze: 1,
    silver: 2,
    gold: 3,
  }, _suffix: 'business_pro_tier'

  enum promotion: {
    none: 0,
    explore_page_business: 1,
    explore_page_business_marketplace_listings: 2,

    marketplace_listings_front_page: 100,
    marketplace_listings_category_page: 101,
    marketplace_listings_injection: 102,
    marketplace_listings_panel: 103,

    businesses_front_page: 200,
    businesses_category_page: 201,
    businesses_injection: 202,
    businesses_panel: 203,

    ads: 300,
  }, _suffix: 'business_promotion'

  scope :recent, -> { reorder(id: :desc) }
  scope :is_approved, -> { where(status: :approved) }

  validates :name, presence: true

  class << self
    SEARCH_FIELDS = %i[name tagline description].freeze

    def search_for(term, offset = 0, limit = 25)
      SEARCH_FIELDS.inject(none) { |r, f| r.or(matching(f, :contains, term)) }
        .is_approved
        .recent
        .limit(limit)
        .offset(offset)
    end

    def with_any_of_categories(category_ids)
      # Convert category_ids to strings as business.categories is an array of strings
      category_ids_as_strings = category_ids.map(&:to_s)
  
      # Query for businesses with any of the given category IDs
      where("categories && ARRAY[?]::varchar[]", category_ids_as_strings)
    end
  end

  private

  def set_default_promotions
    self.promotions ||= []
  end



end
