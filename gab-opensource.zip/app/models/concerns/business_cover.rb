# frozen_string_literal: true

module BusinessCover
  extend ActiveSupport::Concern

  IMAGE_MIME_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'].freeze
  LIMIT = 5.megabytes

  class_methods do
    def cover_styles(file)
      styles = { original: { geometry: '1600x400#', file_geometry_parser: FastGeometryParser } }
      styles[:static] = { geometry: '1600x400#', format: 'png', convert_options: '-coalesce', file_geometry_parser: FastGeometryParser } if file.content_type == 'image/gif'
      styles
    end

    private :cover_styles
  end

  included do
    # cover upload
    has_attached_file :cover, styles: ->(f) { cover_styles(f) }, convert_options: { all: '-strip' }, processors: [:lazy_thumbnail]
    validates_attachment_content_type :cover, content_type: IMAGE_MIME_TYPES
    validates_attachment_size :cover, less_than: LIMIT
    remotable_attachment :cover, LIMIT
  end

  def cover_original_url
    cover.url(:original)
  end

  def cover_static_url
    cover_content_type == 'image/gif' ? cover.url(:static) : cover_original_url
  end
end
