# == Schema Information
#
# Table name: business_accounts
#
#  id          :bigint(8)        not null, primary key
#  business_id :bigint(8)        not null
#  account_id  :bigint(8)        not null
#  title       :string
#  role        :integer
#  visibility  :integer
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#

class BusinessAccount < ApplicationRecord

  belongs_to :business
  belongs_to :account

  enum role: {
    owner: 0,
  }, _suffix: 'business_account_role'

  # for people who want/dont want their account assosiated with their businesses
  enum visibility: {
    private: 0,
    public: 1,
  }, _suffix: 'business_account_visibility'

end
