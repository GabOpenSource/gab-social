# frozen_string_literal: true

class BusinessPolicy < ApplicationPolicy
  def index?
    true
  end

  def show?
    # if staff, show all, if own, show all
    return true if owned?

    # dont allow if blocked by owner
    
    # else show only running
    return true if record.status == "approved"
    return false
  end

  def create?
    true
  end
  
  def update?
    # only allow staff and owner to update
    return true if staff? || owned?
    false
  end

  def destroy?
    # only allow staff and owner to destroy
    return true if staff? || owned?
    false
  end

  def remove_business_avatar?
    return true if staff? || owned?
    false
  end

  private

  def owned?
    record.account_id == current_account&.id
  end

end
