import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import ImmutablePureComponent from 'react-immutable-pure-component'
import ImmutablePropTypes from 'react-immutable-proptypes'
import { authorizeFollowRequest, rejectFollowRequest } from '../actions/accounts'
import { makeGetAccount } from '../selectors'
import Account from './account'

class AccountAuthorize extends ImmutablePureComponent {

  render () {
    const { account, onAuthorize, onReject } = this.props

    return (
      <Account
        id={account.get('id')}
        dismissAction={onReject}
        onActionClick={onAuthorize}
        actionIcon='add'
        showDismiss
        withBio
      />
    )
  }

}

const makeMapStateToProps = (state, props) => ({
  account: makeGetAccount()(state, props.id),
})

const mapDispatchToProps = (dispatch, { id }) => ({
  onAuthorize() {
    dispatch(authorizeFollowRequest(id))
  },
  onReject() {
    dispatch(rejectFollowRequest(id))
  },
})

AccountAuthorize.propTypes = {
  account: ImmutablePropTypes.map.isRequired,
  onAuthorize: PropTypes.func.isRequired,
  onReject: PropTypes.func.isRequired,
}

export default connect(makeMapStateToProps, mapDispatchToProps)(AccountAuthorize)