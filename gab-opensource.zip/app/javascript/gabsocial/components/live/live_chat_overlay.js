'use strict'

import React from 'react'
import PropTypes from 'prop-types'
import ImmutablePropTypes from 'react-immutable-proptypes'

const OVERLAY_STYLE = { position: 'absolute', bottom: '16px', left: '16px', width: '280px', zIndex: 20, display: 'flex', flexDirection: 'column', gap: '4px' }
const LIST_STYLE = { maxHeight: '200px', overflow: 'hidden', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }
const NAME_STYLE = { color: '#4ade80', fontSize: '12px', fontWeight: '600', marginRight: '6px' }
const TEXT_STYLE = { color: '#fff', fontSize: '13px', wordBreak: 'break-word' }
const FORM_STYLE = { display: 'flex', gap: '4px' }
const INPUT_STYLE = {
  flex: 1, padding: '8px 12px', borderRadius: '20px', border: 'none',
  background: 'rgba(255,255,255,0.15)', color: '#fff', fontSize: '13px',
  outline: 'none', backdropFilter: 'blur(4px)',
}
const BUTTON_STYLE = {
  background: 'rgba(255,255,255,0.2)', border: 'none', borderRadius: '50%',
  width: '36px', height: '36px', display: 'flex', alignItems: 'center',
  justifyContent: 'center', cursor: 'pointer', color: '#fff', fontSize: '14px', flexShrink: 0,
}
const messageStyle = (opacity) => ({
  padding: '3px 8px', borderRadius: '12px', background: 'rgba(0,0,0,0.5)',
  marginBottom: '2px', maxWidth: '100%', opacity, transition: 'opacity 0.5s',
  position: 'relative',
})
const MUTE_BTN_STYLE = {
  position: 'absolute', top: '2px', right: '2px', background: 'rgba(239,68,68,0.7)',
  border: 'none', borderRadius: '4px', padding: '1px 5px', cursor: 'pointer',
  color: '#fff', fontSize: '10px', fontWeight: '600', display: 'none', lineHeight: '1.2',
}

class LiveChatOverlay extends React.PureComponent {

  state = {
    text: '',
  }

  handleChange = (e) => {
    this.setState({ text: e.target.value })
  }

  handleSubmit = (e) => {
    e.preventDefault()
    const { text } = this.state
    if (!text.trim()) return
    this.props.onSend(text.trim())
    this.setState({ text: '' })
  }

  handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      this.handleSubmit(e)
    }
  }

  handleMute = (username) => {
    if (this.props.onMuteUser) {
      this.props.onMuteUser(username)
    }
  }

  isMuted = (username) => {
    const { mutedUsernames } = this.props
    if (!mutedUsernames || !username) return false
    const list = mutedUsernames.toJS ? mutedUsernames.toJS() : mutedUsernames
    return list.includes(username)
  }

  render() {
    const { messages, isHost } = this.props
    const { text } = this.state
    const msgList = messages && messages.toJS ? messages.toJS() : (messages || [])
    const recentMessages = msgList.slice(-20)

    return (
      <div style={OVERLAY_STYLE}>
        <div style={LIST_STYLE}>
          {
            recentMessages.map((msg, i) => {
              const age = Date.now() - (msg.timestamp || 0)
              const opacity = age > 10000 ? 0.4 : age > 5000 ? 0.7 : 1
              const name = msg.name || 'Viewer'
              const isSelf = name === 'You'
              const alreadyMuted = this.isMuted(name)
              const showMute = isHost && !isSelf && !alreadyMuted

              return (
                <div
                  key={msg.id || i}
                  style={messageStyle(opacity)}
                  onMouseEnter={(e) => { if (showMute) e.currentTarget.querySelector('.mute-btn').style.display = 'inline-block' }}
                  onMouseLeave={(e) => { if (showMute) e.currentTarget.querySelector('.mute-btn').style.display = 'none' }}
                >
                  <span style={NAME_STYLE}>
                    {name}
                  </span>
                  <span style={TEXT_STYLE}>
                    {msg.text}
                  </span>
                  {alreadyMuted && (
                    <span style={{ color: 'rgba(239,68,68,0.8)', fontSize: '10px', marginLeft: '6px' }}>muted</span>
                  )}
                  {showMute && (
                    <button
                      className='mute-btn'
                      style={MUTE_BTN_STYLE}
                      onClick={() => this.handleMute(name)}
                      title={'Mute ' + name + ' forever'}
                    >
                      mute
                    </button>
                  )}
                </div>
              )
            })
          }
        </div>

        <form onSubmit={this.handleSubmit} style={FORM_STYLE}>
          <input
            type="text"
            value={text}
            onChange={this.handleChange}
            onKeyDown={this.handleKeyDown}
            placeholder="Say something..."
            maxLength={200}
            style={INPUT_STYLE}
          />
          <button type="submit" style={BUTTON_STYLE}>
            ➤
          </button>
        </form>
      </div>
    )
  }
}

LiveChatOverlay.propTypes = {
  messages: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  onSend: PropTypes.func.isRequired,
  isHost: PropTypes.bool,
  onMuteUser: PropTypes.func,
  mutedUsernames: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
}

export default LiveChatOverlay
