'use strict'

import React from 'react'
import PropTypes from 'prop-types'

class ViewerCountBadge extends React.PureComponent {
  render() {
    const { count } = this.props

    return (
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: '4px',
        background: 'rgba(0,0,0,0.5)',
        padding: '4px 10px',
        borderRadius: '12px',
        backdropFilter: 'blur(4px)',
      }}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2">
          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
          <circle cx="12" cy="12" r="3" />
        </svg>
        <span style={{ color: '#fff', fontSize: '13px', fontWeight: '600' }}>
          {count}
        </span>
      </div>
    )
  }
}

ViewerCountBadge.propTypes = {
  count: PropTypes.number.isRequired,
}

export default ViewerCountBadge
