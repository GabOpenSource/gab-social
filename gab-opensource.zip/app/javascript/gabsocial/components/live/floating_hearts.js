'use strict'

import React from 'react'
import PropTypes from 'prop-types'

const HEART_COLORS = ['#ff4d6d', '#ff6b81', '#ff8fab', '#fb5607', '#ff006e', '#e63946']

const CONTAINER_STYLE = { position: 'absolute', right: '16px', bottom: '120px', width: '60px', height: '300px', zIndex: 15, pointerEvents: 'none', overflow: 'hidden' }

const heartStyle = (color, xOffset, size, delay) => ({
  position: 'absolute',
  bottom: '0',
  left: `calc(50% + ${xOffset}px)`,
  fontSize: `${size}px`,
  color: color,
  opacity: 0,
  animation: `floatHeart 3s ${delay}s ease-out forwards`,
  pointerEvents: 'none',
})

class FloatingHearts extends React.PureComponent {

  render() {
    const { hearts } = this.props
    const heartList = hearts && hearts.toJS ? hearts.toJS() : (hearts || [])

    return (
      <div style={CONTAINER_STYLE}>
        {
          heartList.map((heart, i) => {
            const color = HEART_COLORS[i % HEART_COLORS.length]
            const xOffset = Math.random() * 40 - 20
            const delay = Math.random() * 0.3
            const size = 18 + Math.random() * 14

            return (
              <span key={heart.id} style={heartStyle(color, xOffset, size, delay)}>
                ❤
              </span>
            )
          })
        }
        <style>{`
          @keyframes floatHeart {
            0% {
              opacity: 1;
              transform: translateY(0) scale(0.5);
            }
            50% {
              opacity: 1;
              transform: translateY(-150px) scale(1);
            }
            100% {
              opacity: 0;
              transform: translateY(-300px) scale(1.2);
            }
          }
        `}</style>
      </div>
    )
  }
}

FloatingHearts.propTypes = {
  hearts: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
}

export default FloatingHearts
