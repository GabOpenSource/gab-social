import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { List as ImmutableList } from 'immutable'
import ImmutablePropTypes from 'react-immutable-proptypes'
import ImmutablePureComponent from 'react-immutable-pure-component'
import { openPopoverDeferred, cancelPopover } from '../actions/popover'
import Image from './image'
import { resizeImageUrl } from '../utils/urls'

/**
 * Renders an avatar component
 * @param {map} [props.account] - the account for image
 * @param {number} [props.size=40] - the size of the avatar
 */
class Avatar extends ImmutablePureComponent {

  state = { hovering: false }

  openUserInfo(evt) {
    // targetRef can be missing until the components set it
    const targetRef = this.imageRef || evt.target

    if (this.props.noHover) {
      // The avatar can be inside a popover and we don't want to open
      // another popover or jump the existing popover to different coordinates.
      return
    }

    if (!targetRef) {
      // it doesn't reliably get a ref
      return
    }

    this.setState({ hovering: true })

    this.props.openUserInfoPopover({
      targetRef,
      position: 'top',
      accountId: this.props.account.get('id'),
      timeout: 1500,
    })
  }

  handleMouseEnter = evt => this.openUserInfo(evt)
  handleMouseMove = evt => this.openUserInfo(evt)
  handleMouseLeave = () => this.props.onCancelPopover()
  setImageRef = el => this.imageRef = el

  handleClick = (e) => {
    const { account, liveStream, isStatic, history } = this.props
    if (!liveStream || !account || isStatic) return

    e.preventDefault()
    e.stopPropagation()
    const username = account.get('acct') || account.get('username')
    if (history) {
      history.push(`/live/${username}`)
    }
  }

  render() {
    const {
      account,
      expandOnClick,
      size,
      isStatic,
      liveStream,
    } = this.props
    const { hovering } = this.state

    const isPro = !!account ? account.get('is_pro') : false
    const displayName = !!account ? account.get('display_name') || account.get('username') : ''
    const alt = (!isStatic || !account) ? '' : `${displayName} ${isPro ? '(PRO)' : ''}`.trim()
    const classes = [_s.d, _s.circle, _s.overflowHidden]
    const isLive = !!liveStream
    if (isPro) {
      classes.push(_s.boxShadowAvatarPro)
    }

    const wrapStyle = isLive && !isStatic
      ? { ...styles.wrap, width: size, height: size, cursor: 'pointer' }
      : { ...styles.wrap, width: size, height: size }

    return (
      <div style={wrapStyle} onClick={isLive && !isStatic ? this.handleClick : undefined}>
        {
          isLive &&
          <span style={styles.liveRing}>
            <span style={styles.livePulse} />
          </span>
        }
        <Image
          src={!!account ? account.get('avatar') : undefined}
          alt={alt}
          cfWidthPX={size}
          imageRef={this.setImageRef}
          className={classes.join(' ')}
          expandOnClick={isStatic ? null : expandOnClick}
          onMouseEnter={isStatic ? null : this.handleMouseEnter}
          onMouseMove={isStatic ? null : this.handleMouseMove}
          onMouseLeave={isStatic ? null : this.handleMouseLeave}
          width={size}
          height={size}
          isLazy={true}
        />
        {
          isLive &&
          <span style={styles.liveDot} />
        }
      </div>
    )
  }

}

const styles = {
  wrap: {
    position: 'relative',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  liveRing: {
    position: 'absolute',
    inset: '-2px',
    borderRadius: '50%',
    border: '2px solid rgba(255,79,94,0.95)',
    boxShadow: '0 0 0 2px rgba(255,79,94,0.18)',
    pointerEvents: 'none',
  },
  livePulse: {
    position: 'absolute',
    inset: '-4px',
    borderRadius: '50%',
    border: '1px solid rgba(255,79,94,0.45)',
    opacity: 0.7,
    pointerEvents: 'none',
  },
  liveDot: {
    position: 'absolute',
    right: '-1px',
    bottom: '-1px',
    width: '10px',
    height: '10px',
    borderRadius: '50%',
    background: '#ff4f5e',
    boxShadow: '0 0 12px rgba(255,79,94,0.9)',
    border: '2px solid var(--background-primary, #111)',
    pointerEvents: 'none',
  },
}

const mapStateToProps = (state, { account }) => {
  const accountId = account ? account.get('id') : null
  const streams = state.getIn(['live_streams', 'items'], ImmutableList())
  const liveStream = accountId ? streams.find(stream => stream.getIn(['account', 'id']) === accountId) : null

  return {
    liveStream,
  }
}

const mapDispatchToProps = (dispatch) => ({
  openUserInfoPopover(props) {
    dispatch(openPopoverDeferred('USER_INFO', props))
  },
  onCancelPopover() {
    dispatch(cancelPopover())
  }
})

Avatar.propTypes = {
  account: ImmutablePropTypes.map,
  liveStream: ImmutablePropTypes.map,
  noHover: PropTypes.bool,
  openUserInfoPopover: PropTypes.func.isRequired,
  onCancelPopover: PropTypes.func.isRequired,
  expandOnClick: PropTypes.bool,
  size: PropTypes.number,
  history: PropTypes.object,
}

Avatar.defaultProps = {
  size: 40,
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Avatar))
