import React from 'react'
import { connect } from 'react-redux'
import { openModal } from '../actions/modal'
import { CX, MODAL_AD, MODAL_DONATE } from '../constants'
import { isPro, createdAt, loggedIn } from '../initial_state'
import {
  openProUpgrade,
  canShowProNag,
  markProNagShown,
  trackEvent,
  PRO_SUBTITLE,
} from '../utils/pro_upgrade'
import Button from './button'
import Text from './text'

// How long after signup we treat the account as "new" — these users get
// a different (warmer, identity-led) Pro pitch instead of being skipped.
const NEW_USER_WINDOW_MS = 7 * 24 * 60 * 60 * 1000

// Probability of showing an interstitial when the user is eligible. We
// keep this in line with the previous value but the eligibility filter
// has changed (see canShowProNag()).
const INTERSTITIAL_PROBABILITY = 0.25

// When we DO show an interstitial, this is the share that goes to Pro
// vs the legacy ad slot. Pro LTV >> ad RPM for this audience.
const PRO_INTERSTITIAL_SHARE = 0.85

class HomeCallToAction extends React.PureComponent {

  state = {
    dismissed: false,
    cta: null,
  }

  componentDidMount() {
    this.selectRandomCta()
    this.maybeShowInterstitial()
  }

  componentDidUpdate(prevProps) {
    if (prevProps.ctas && this.props.ctas && prevProps.ctas.size === 0 && this.props.ctas.size > 0 && !this.state.cta) {
      this.selectRandomCta()
    } else if (!this.state.cta) {
      this.selectRandomCta()
    }
  }

  /**
   * Eligibility for an interstitial nag. Pro users are always excluded.
   * New users (< 7 days) are now INCLUDED — they're the highest-intent
   * window for Pro conversion — but they get a tailored subtitle so
   * pro.gab.com can render an identity-led variant.
   */
  maybeShowInterstitial = () => {
    if (!loggedIn) return
    if (isPro) return
    if (!canShowProNag()) return
    if (Math.random() > INTERSTITIAL_PROBABILITY) return

    const isNewAccount = createdAt && (Date.now() - createdAt) < NEW_USER_WINDOW_MS
    const showPro = Math.random() < PRO_INTERSTITIAL_SHARE

    if (showPro) {
      const subtitle = isNewAccount
        ? PRO_SUBTITLE.HOME_INTERSTITIAL_NEW_USER
        : PRO_SUBTITLE.HOME_INTERSTITIAL_RETURNING

      markProNagShown()
      this.props.dispatch(openProUpgrade({
        subtitle,
        consumeNagBudget: false,
      }))
      return
    }

    // Ad fallback — still consumes the global nag budget so users don't
    // get stacked interruptions across surfaces.
    markProNagShown()
    trackEvent('interstitial_ad_shown', { isNewAccount: !!isNewAccount })
    this.props.dispatch(openModal(MODAL_AD))
  }

  selectRandomCta = () => {
    const { ctas } = this.props
    const validCtas = ctas.filter((cta) => cta && localStorage.getItem(cta.get('id')) !== '2')

    if (validCtas.size > 0) {
      const randomIndex = Math.floor(Math.random() * validCtas.size)
      const selectedCta = validCtas.get(randomIndex)
      this.setState({ cta: selectedCta.toJS() })
    }
  }

  handleOnDismissNow = () => {
    const { cta } = this.state
    if (cta) {
      localStorage.setItem(cta.id, '2')
      trackEvent('home_cta_dismiss', { ctaId: cta.id })
      this.setState({ dismissed: true, cta: null })
    }
  }

  handleOnGoPro = () => {
    const { cta } = this.state
    if (isPro) return

    this.props.dispatch(openProUpgrade({
      ctaId: cta?.id,
      subtitle: cta?.id ? `home-cta-${cta.id}` : PRO_SUBTITLE.HOME_INTERSTITIAL_RETURNING,
    }))
  }

  handleOnDonate = () => {
    const { cta } = this.state
    trackEvent('donate_open', { ctaId: cta?.id, surface: 'home-cta' })
    this.props.dispatch(openModal(MODAL_DONATE, { ctaId: cta?.id }))
  }

  handleOnDismiss = () => {
    this.handleOnDismissNow()
  }

  render() {
    const { isXS } = this.props
    const { dismissed, cta } = this.state

    if (dismissed || !cta) return null
    const localStorageDismissed = localStorage.getItem(cta.id) === '2'
    if (localStorageDismissed) return null

    const containerClasses = CX({
      d: 1,
      px15: 1,
      pt10: 1,
      pb10: 1,
      w100PC: 1,
      bgPrimary: 1,
      borderBottom1PX: 1,
      borderColorSecondary: 1,
    })

    return (
      <div className={containerClasses}>
        <div className={[_s.d, _s.flexRow, _s.aiCenter, _s.mb5].join(' ')}>
          <Text size='large' weight='bold' className={_s.maxW80PC}>{cta.title}</Text>
          <Button
            circle
            icon='close'
            iconSize='10px'
            backgroundColor='secondary'
            color='secondary'
            onClick={this.handleOnDismiss}
            className={[_s.h30PX, _s.w30PX, _s.aiCenter, _s.jcCenter, _s.mlAuto].join(' ')}
          />
        </div>
        <Text>{cta.content}</Text>
        <div className={[_s.d, _s.flexRow, _s.flexWrap, !isXS ? _s.jcCenter : ''].join(' ')}>
          {
            (!!cta.secondaryBtnTitle && !!cta.secondaryBtnAction) &&
            <Button
              radiusSmall
              backgroundColor='tertiary'
              color='primary'
              onClick={
                cta.secondaryBtnAction === 'go-pro' ? this.handleOnGoPro :
                cta.secondaryBtnAction === 'donate' ? this.handleOnDonate :
                undefined
              }
              href={
                ['donate', 'go-pro'].indexOf(cta.secondaryBtnAction) === -1 ? cta.secondaryBtnAction : undefined
              }
              className={[_s.mt10, _s.mr10].join(' ')}
            >
              <Text color='inherit' weight='medium' size={isXS ? '' : 'medium'}>{cta.secondaryBtnTitle}</Text>
            </Button>
          }
          {
            (!!cta.primaryBtnTitle && !!cta.primaryBtnAction) &&
            <Button
              radiusSmall
              isBlock={isXS}
              backgroundColor='none'
              color='none'
              target='_blank'
              onClick={
                cta.primaryBtnAction === 'go-pro' ? this.handleOnGoPro :
                cta.primaryBtnAction === 'donate' ? this.handleOnDonate :
                undefined
              }
              href={
                ['donate', 'go-pro'].indexOf(cta.primaryBtnAction) === -1 ? cta.primaryBtnAction : undefined
              }
              className={[_s.mt10, _s.bgTextPrimary, _s.colorBGPrimary].join(' ')}
            >
              <Text color='inherit' align='center' weight='bold' size={isXS ? '' : 'medium'}>{cta.primaryBtnTitle}</Text>
            </Button>
          }
        </div>
      </div>
    )
  }
}


const mapStateToProps = (state) => ({
  ctas: state.getIn(['call_to_actions', 'items']),
})

export default connect(mapStateToProps)(HomeCallToAction)
