import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import ImmutablePropTypes from 'react-immutable-proptypes'
import ImmutablePureComponent from 'react-immutable-pure-component'
import {
  followAccount,
  unfollowAccount,
  unblockAccount,
  fetchRelationships,
} from '../actions/accounts'
import { openModal } from '../actions/modal'
import { closePopover } from '../actions/popover'
import { me, unfollowModal } from '../initial_state'
import { MODAL_EDIT_PROFILE } from '../constants'
import Button from './button'
import Text from './text'
import { makeGetAccount } from '../selectors'

class AccountActionButton extends ImmutablePureComponent {

  componentDidMount() {
    const { account, shouldLoad } = this.props
    if (!!account && shouldLoad) {
      this.checkRelationships(account)
    }
  }

  componentDidUpdate(prevProps) {
    const { account, shouldLoad } = this.props
    if (shouldLoad && !!account && !account.get('relationship')) {
      this.checkRelationships(account)
    }
  }

  checkRelationships = (account) => {
    if (!account) return
    if (!account.get('relationship')) {
      this.props.onFetchRelationships(account.get('id'))
    }
  }

  handleFollow = () => {
    this.props.onFollow(this.props.account)
  }

  handleBlock = () => {
    this.props.onBlock(this.props.account)
  }

  handleOnEditProfile = () => {
    this.props.onOpenEditProfile()
  }
  
  render() {
    const { account, accountId, isSmall } = this.props

    if (!account) return null

    const isMe = account.get('id') === me
      
    // Wait until the relationship is loaded unless me
    if (!account.get('relationship') && !isMe) return null

    let buttonText = ''
    let buttonOptions = {}

    if (isMe) {
      buttonText = 'Edit profile'
      buttonOptions = {
        onClick: this.handleOnEditProfile,
        color: 'brand',
        backgroundColor: 'none',
        isOutline: true,
      }
    } else {
      const isBlockedBy = account.getIn(['relationship', 'blocked_by'])

      // Don't show
      if (isBlockedBy) return null

      const isRequested = account.getIn(['relationship', 'requested'])
      const isBlocking = account.getIn(['relationship', 'blocking'])
      const isFollowing = account.getIn(['relationship', 'following'])

      if (isRequested) {
        buttonText = 'Requested'
        buttonOptions = {
          onClick: this.handleFollow,
          color: 'primary',
          backgroundColor: 'tertiary',
        }
      } else if (isBlocking) {
        buttonText = 'Blocked'
        buttonOptions = {
          onClick: this.handleBlock,
          color: 'white',
          backgroundColor: 'danger',
        }
      } else if (isFollowing) {
        buttonText = 'Following'
        buttonOptions = {
          onClick: this.handleFollow,
          color: 'white',
          backgroundColor: 'brand',
        }
      } else {
        buttonText = 'Follow'
        buttonOptions = {
          onClick: this.handleFollow,
          color: 'brand',
          backgroundColor: 'none',
          isOutline: true,
        }
      }
    }

    const textClassName = isSmall ? null : _s.px10
    const textSize = isSmall ? 'normal' : 'medium'
    const textWeight = isSmall ? 'normal' : 'bold'

    return (
      <Button
        {...buttonOptions}
        radiusSmall
        isNarrow
        className={[_s.jcCenter, _s.aiCenter].join(' ')}
      >
        <Text
          color='inherit'
          weight={textWeight}
          size={textSize}
          className={textClassName}
        >
          {buttonText}
        </Text>
      </Button>
    )
  }

}

const mapDispatchToProps = (dispatch) => ({
  onFetchRelationships(accountId) {
    dispatch(fetchRelationships([accountId]))
  },
  onFollow(account) {
    if (account.getIn(['relationship', 'following']) || account.getIn(['relationship', 'requested'])) {
      if (unfollowModal) {
        dispatch(openModal('UNFOLLOW', {
          account,
        }))
      } else {
        dispatch(unfollowAccount(account.get('id')))
      }
    } else {
      dispatch(followAccount(account.get('id')))
    }
  },
  onBlock(account) {
    if (account.getIn(['relationship', 'blocking'])) {
      dispatch(unblockAccount(account.get('id')))
    } else {
      dispatch(openModal('BLOCK_ACCOUNT', {
        accountId: account.get('id'),
      }))
    }
  },
  onOpenEditProfile() {
    dispatch(closePopover())
    dispatch(openModal(MODAL_EDIT_PROFILE))
  },
})

const mapStateToProps = (state, props) => {
  const theAccount = !props.account && props.accountId ? makeGetAccount()(state, props.accountId) : props.account
  return {
    account: theAccount,
  }
}

AccountActionButton.propTypes = {
  account: ImmutablePropTypes.map,
  isSmall: PropTypes.bool,
  onBlock: PropTypes.func.isRequired,
  onFollow: PropTypes.func.isRequired,
  onOpenEditProfile: PropTypes.func.isRequired,
  shouldLoad: PropTypes.bool,
}

export default connect(mapStateToProps, mapDispatchToProps)(AccountActionButton)
