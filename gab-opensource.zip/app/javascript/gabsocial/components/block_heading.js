import React from 'react'
import PropTypes from 'prop-types'
import Heading from './heading'

class BlockHeading extends React.PureComponent {

  render() {
    const { title, children } = this.props

    return (
      <div className={[_s.d, _s.px15, _s.py10].join(' ')}>
        <div className={[_s.d, _s.flexRow, _s.aiCenter].join(' ')}>
          <Heading size='h2'>{title}</Heading>
          {children}
        </div>
      </div>
    )
  }

}

BlockHeading.propTypes = {
  title: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.node,
  ]).isRequired,
}

export default BlockHeading
