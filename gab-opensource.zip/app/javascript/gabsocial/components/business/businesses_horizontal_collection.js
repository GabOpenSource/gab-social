import React from 'react'
import PropTypes from 'prop-types'
import ImmutablePureComponent from 'react-immutable-pure-component'
import ImmutablePropTypes from 'react-immutable-proptypes'
import { connect } from 'react-redux'
import debounce from 'lodash/debounce'
import {
  CX,
  BREAKPOINT_EXTRA_SMALL,
} from '../../constants'
import BusinessCard from '../business/business_card'
import BusinessCardPlaceholder from '../placeholder/business_card_placeholder'
import Text from '../text'
import ScrollableList from '../scrollable_list'
import Button from '../button'

class BusinessesHorizontalCollection extends ImmutablePureComponent {

  handleLoadMore = debounce(() => {
    this.props.onLoadMore()
  }, 300, { leading: true })

  render() {
    const {
      isLoading,
      hasMore,
      data,
      title,
      isXS,
      unwrapped,
    } = this.props

    // const hasListings = Array.isArray(data) && data.length > 0

    const wrapperClasses = CX({
      d: 1,
      w100PC: 1,
      pt15: isXS,
    })

    const mainClasses = CX({
      d: 1,
      pb10: 1,
      pt15: 1,
      px15: !isXS && !unwrapped,
      px10: isXS && !unwrapped,
    })

    const titlePLClass = isXS ? _s.pl5 : _s.pl10

    return (
      <div className={wrapperClasses}>
        <ScrollableList
          scrollKey="businesses_horizontal_collection"
          role='feed'
          onLoadMore={this.handleLoadMore}
          placeholderComponent={BusinessCardPlaceholder}
          placeholderCount={6}
          emptyMessage='No businesses found'
          hasMore={hasMore}
          isLoading={isLoading}
        >
          <div className={mainClasses}>
            {
              Array.isArray(data) && data.map((block, i) => {
                let mbClass = isXS ? _s.d : _s.mb10
                let mClass = i === 0 ? _s.d : _s.mt15
                let pbClass = isXS ? i === 0 ? _s.pb10 : _s.pb5 : _s.pb15
                let isFeatured = block.title.toLowerCase().indexOf('featured') > -1
                let gridClass = isFeatured ? _s.businessGrid : _s.businessGrid

                return (
                  <div key={`mlhc-${block.title}`} className={[_s.d, _s.w100PC, mClass, mbClass, pbClass, _s.borderBottom1PX, _s.borderColorInput].join(' ')}>
                    <div className={[_s.d, _s.flexRow, _s.aiCenter, titlePLClass, _s.pr5, pbClass, _s.mb10].join(' ')}>
                      {
                        !!block.title && <Text size={isXS ? 'large' : 'extraExtraLarge'} weight='bold'>{block.title}</Text>
                      }
                      {
                        !!block.to &&
                        <div className={[_s.d, _s.mlAuto].join(' ')}>
                          <Button
                            radiusSmall
                            backgroundColor='none'
                            color='brand'
                            to={block.to}
                            className={_s.bgSubtle_onHover}
                          >
                            <Text color='inherit' size={isXS ? 'normal' : 'medium'} weight='medium'>See all</Text>
                          </Button>
                        </div>
                      }
                    </div>
                    <div className={[_s.d, gridClass, titlePLClass, _s.w100PC, _s.flexWrap, _s.flexRow, _s.pb15].join(' ')}>
                      {Array.isArray(block.ids) && block.ids.map((listingId) => {
                        return (
                          <BusinessCard
                            isFeatured={isFeatured}
                            isInline={!isFeatured}
                            key={`business-card-${listingId}`}
                            id={listingId}
                          />
                        )
                      })}
                    </div>
                  </div>
                )
              })
            }
          </div>
        </ScrollableList>
      </div>
    )
  }

}

const mapStateToProps = (state) => ({
  isXS: state.getIn(['settings', 'window_dimensions', 'width']) <= BREAKPOINT_EXTRA_SMALL,
})

BusinessesHorizontalCollection.propTypes = {
  listingIds: ImmutablePropTypes.list,
  isLoading: PropTypes.bool,
  isError: PropTypes.bool,
  hasMore: PropTypes.bool,
  unwrapped: PropTypes.bool,
  onLoadMore: PropTypes.func,
  title: PropTypes.string,
}

export default connect(mapStateToProps)(BusinessesHorizontalCollection)
