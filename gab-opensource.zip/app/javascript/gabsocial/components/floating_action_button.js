import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { loggedOut } from '../initial_state'
import { CX, MODAL_COMPOSE, BREAKPOINT_EXTRA_SMALL } from '../constants'
import { openModal } from '../actions/modal'
import Button from './button'
import { getGroupIdFromRoute } from '../utils/groups'

const btnClass = [
  _s.py15,
  _s.h60PX,
  _s.saveAreaInsetMR,
  _s.saveAreaInsetMB,
  _s.w60PX,
  _s.jcCenter,
  _s.aiCenter,
  _s.boxShadowBlock
].join(' ')

class FloatingActionButton extends React.PureComponent {
  get groupId() {
    return getGroupIdFromRoute(this)
  }

  get hasGroup() {
    return this.groupId !== undefined && this.groupId !== null
  }

  onClick = () => {
    const { groupId, hasGroup } = this
    const { text } = this.props
    const opts = hasGroup ? { groupId } : {}
    if (!!text) opts.initialText = text
    this.props.onOpenCompose(opts)
  }

  render() {
    const { fabDisabled, width } = this.props

    const isDesktop = width > BREAKPOINT_EXTRA_SMALL

    if (fabDisabled || loggedOut || isDesktop) return null

    const message = 'Gab'

    const containerClasses = CX({
      posFixed: 1,
      z3: 1,
      mb15: 1,
      mr15: 1,
      right0: 1,
      transitionTransform025: 1,
      bottom55PX: 1,
    })

    return (
      <div id='fab' className={containerClasses}>
        <Button
          onClick={this.onClick}
          className={btnClass}
          title={message}
          aria-label={message}
          icon="pencil"
          iconSize="20px"
        />
      </div>
    )
  }
}

const mapStateToProps = state => ({
  fabDisabled: state.getIn(['settings', 'displayOptions', 'fabDisabled'], false),
  width: state.getIn(['settings', 'window_dimensions', 'width']),
})

const mapDispatchToProps = dispatch => ({
  onOpenCompose: (opts) => {
    dispatch(openModal(MODAL_COMPOSE, opts))
  }
})

FloatingActionButton.propTypes = {
  onOpenCompose: PropTypes.func.isRequired,
  text: PropTypes.string,
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(FloatingActionButton))