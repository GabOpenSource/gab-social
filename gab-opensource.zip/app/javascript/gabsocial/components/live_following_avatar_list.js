import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { List as ImmutableList } from 'immutable'
import ImmutablePureComponent from 'react-immutable-pure-component'
import ImmutablePropTypes from 'react-immutable-proptypes'
import { fetchRelationships } from '../actions/accounts'
import { BREAKPOINT_EXTRA_SMALL } from '../constants'
import { me } from '../initial_state'
import Avatar from './avatar'
import Button from './button'

const SCROLL_AMOUNT = 200

class LiveFollowingAvatarList extends ImmutablePureComponent {

  state = {
    canScrollLeft: false,
    canScrollRight: false,
  }

  componentDidMount() {
    this.ensureRelationships()
  }

  componentDidUpdate(prevProps) {
    if (prevProps.liveAccountIds !== this.props.liveAccountIds) {
      this.ensureRelationships()
      this.updateScrollArrows()
    }
  }

  ensureRelationships() {
    const { liveAccountIds, dispatch } = this.props
    if (liveAccountIds.length > 0) {
      dispatch(fetchRelationships(liveAccountIds))
    }
  }

  setScrollRef = (n) => {
    this.scrollRef = n
    this.updateScrollArrows()
  }

  updateScrollArrows = () => {
    if (!this.scrollRef) return
    const { scrollLeft, scrollWidth, clientWidth } = this.scrollRef
    this.setState({
      canScrollLeft: scrollLeft > 0,
      canScrollRight: scrollLeft + clientWidth < scrollWidth - 1,
    })
  }

  handleScrollLeft = () => {
    if (!this.scrollRef) return
    this.scrollRef.scrollBy({ left: -SCROLL_AMOUNT, behavior: 'smooth' })
  }

  handleScrollRight = () => {
    if (!this.scrollRef) return
    this.scrollRef.scrollBy({ left: SCROLL_AMOUNT, behavior: 'smooth' })
  }

  handleScroll = () => {
    this.updateScrollArrows()
  }

  handleAvatarClick = (username, e) => {
    e.preventDefault()
    if (this.props.history) {
      this.props.history.push(`/live/${username}`)
    }
  }

  render() {
    const { liveFollowingStreams, width } = this.props
    const { canScrollLeft, canScrollRight } = this.state

    if (!liveFollowingStreams || liveFollowingStreams.size === 0) return null

    const isXS = width <= BREAKPOINT_EXTRA_SMALL
    const showArrows = !isXS

    return (
      <div className={[_s.d, _s.posRel, _s.w100PC, _s.py10, _s.borderBottom1PX, _s.borderColorSecondary].join(' ')}>
        <div
          ref={this.setScrollRef}
          onScroll={this.handleScroll}
          className={[
            _s.d,
            _s.px10,
            _s.flexRow,
            _s.aiCenter,
            _s.w100PC,
            _s.overflowXScroll,
            _s.noScrollbar,
          ].join(' ')}
        >
          <span style={styles.liveLabel}>LIVE</span>

          {liveFollowingStreams.map((stream) => {
            const account = stream.get('account')
            if (!account) return null
            const username = account.get('acct') || account.get('username')
            return (
              <div
                key={`live-following-${account.get('id')}`}
                className={[_s.d, _s.mr10, _s.cursorPointer].join(' ')}
                onClick={(e) => this.handleAvatarClick(username, e)}
                role='link'
                tabIndex='0'
              >
                <Avatar account={account} size={40} />
              </div>
            )
          })}
        </div>

        {
          showArrows && canScrollLeft &&
          <div
            className={[_s.d, _s.posAbs, _s.left0, _s.top0, _s.bottom0, _s.aiCenter, _s.jcCenter].join(' ')}
            style={{ background: 'linear-gradient(to right, var(--color_bg_primary) 60%, transparent)', paddingLeft: 4, paddingRight: 12 }}
          >
            <Button
              tabIndex='0'
              backgroundColor='secondary'
              color='primary'
              circle
              onClick={this.handleScrollLeft}
              aria-label='Scroll left'
              icon='arrow-left'
              iconSize='14px'
              className={[_s.aiCenter, _s.jcCenter].join(' ')}
              style={{ width: 30, height: 30 }}
            />
          </div>
        }

        {
          showArrows && canScrollRight &&
          <div
            className={[_s.d, _s.posAbs, _s.right0, _s.top0, _s.bottom0, _s.aiCenter, _s.jcCenter].join(' ')}
            style={{ background: 'linear-gradient(to left, var(--color_bg_primary) 60%, transparent)', paddingRight: 4, paddingLeft: 12 }}
          >
            <Button
              tabIndex='0'
              backgroundColor='secondary'
              color='primary'
              circle
              onClick={this.handleScrollRight}
              aria-label='Scroll right'
              icon='arrow-right'
              iconSize='14px'
              className={[_s.aiCenter, _s.jcCenter].join(' ')}
              style={{ width: 30, height: 30 }}
            />
          </div>
        }
      </div>
    )
  }
}

const styles = {
  liveLabel: {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
    marginRight: '10px',
    padding: '4px 8px',
    borderRadius: '6px',
    background: '#ff4f5e',
    color: '#fff',
    fontSize: '11px',
    fontWeight: '800',
    letterSpacing: '0.06em',
    lineHeight: '1',
  },
}

const mapStateToProps = (state) => {
  if (!me) return { liveFollowingStreams: ImmutableList(), liveAccountIds: [] }

  const streams = state.getIn(['live_streams', 'items'], ImmutableList())

  const liveAccountIds = streams.reduce((acc, s) => {
    const id = s.getIn(['account', 'id'])
    if (id) acc.push(id)
    return acc
  }, [])

  const liveFollowingStreams = streams.filter(stream => {
    const accountId = stream.getIn(['account', 'id'])
    if (!accountId || accountId === me) return false
    return state.getIn(['relationships', accountId, 'following'], false)
  })

  return {
    liveFollowingStreams,
    liveAccountIds,
    width: state.getIn(['settings', 'window_dimensions', 'width']),
  }
}

LiveFollowingAvatarList.propTypes = {
  dispatch: PropTypes.func.isRequired,
  liveFollowingStreams: ImmutablePropTypes.list,
  liveAccountIds: PropTypes.array,
  width: PropTypes.number,
  history: PropTypes.object,
}

export default withRouter(connect(mapStateToProps)(LiveFollowingAvatarList))
