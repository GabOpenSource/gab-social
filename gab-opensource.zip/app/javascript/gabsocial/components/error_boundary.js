import React from 'react'
import PropTypes from 'prop-types'
import { version } from '../initial_state'
import {
  APP_NAME,
  DEFAULT_REL,
} from '../constants'
import Button from './button'
import DotTextSeperator from './dot_text_seperator'
import Divider from './divider'
import Icon from './icon'
import Text from './text'

class ErrorBoundary extends React.PureComponent {

  state = {
    hasError: false,
    stackTrace: undefined,
    componentStack: undefined,
    copied: false,
  }

  componentDidCatch(error, info) {
    if (process.env.NODE_ENV === 'development') {
      const { message, stack } = error
      console.error("ErrorBoundary", message, stack)
    }
    this.setState({
      hasError: true,
      stackTrace: error.stack,
      componentStack: info && info.componentStack,
      copied: false,
    })
  }

  handleCopyStackTrace = () => {
    const { stackTrace } = this.state;
    const textarea = document.createElement('textarea');

    textarea.textContent = stackTrace;
    textarea.style.position = 'fixed';

    document.body.appendChild(textarea);

    try {
      textarea.select();
      document.execCommand('copy');
    } catch (e) {
      //
    }

    document.body.removeChild(textarea);

    this.setState({ copied: true });
    setTimeout(() => this.setState({ copied: false }), 700);
  }

  render() {
    const { hasError, copied } = this.state

    if (!hasError) return this.props.children

    return (
      <div className={[_s.d, _s.minH100VH, _s.w100PC, _s.aiCenter, _s.jcCenter].join(' ')}>
        <div className={[_s.d, _s.minH53PX, _s.bgBrand, _s.aiCenter, _s.z3, _s.top0, _s.right0, _s.left0, _s.posFixed].join(' ')} >
          <div className={[_s.d, _s.flexRow, _s.saveAreaInsetPT, _s.saveAreaInsetPL, _s.saveAreaInsetPR, _s.w1255PX].join(' ')}>

            <div className={[_s.d, _s.flexRow].join(' ')}>

              <h1 className={[_s.d, _s.mr15].join(' ')}>
                <Button href='/' isText aria-label='Gab' className={[_s.d, _s.jcCenter, _s.noSelect, _s.noUnderline, _s.h53PX, _s.cursorPointer, _s.px10, _s.mr15].join(' ')}>
                  <Icon id='logo' className={_s.fillWhite} />
                </Button>
              </h1>

            </div>
          </div>
        </div>

        <div className={[_s.d, _s.maxW640PX, _s.px15, _s.py10].join(' ')}>

          <Icon id='warning' size='28px' className={[_s.d, _s.cSecondary, _s.mb15].join(' ')} />

          <Text size='medium' className={_s.pt15}>
            Due to a bug in our code or a browser compatibility issue, this page or feature could not be displayed correctly.
          </Text>

          <Text size='medium' className={_s.mt10}>
            Try refreshing the page or trying the action again. If that does not help, you may still be able to use Gab.com through a different browser or native app.
          </Text>

          <div className={[_s.d, _s.py10, _s.my10].join(' ')}>
            <Text>
              Gab.com (version: {version})
            </Text>

            <div className={[_s.d, _s.flexRow, _s.mt10, _s.aiCenter].join(' ')}>
              <Button
                isText
                href={'/'} 
                rel={DEFAULT_REL}
                target='_blank'
                backgroundColor='tertiary'
                color='primary'
                radiusSmall
                className={[_s.py2, _s.px10].join(' ')}
              >
                <Text color='inherit'>Report issue</Text>
              </Button>

              <DotTextSeperator />

              <Button
                isText
                backgroundColor='tertiary'
                color='primary'
                onClick={this.handleCopyStackTrace}
                radiusSmall
                className={[_s.ml5, _s.py2, _s.px10].join(' ')}
              >
                <Text color='inherit'>Copy error to clipboard</Text>
              </Button>
            </div>
          </div>

          <Divider />

          <div className={[_s.d, _s.flexRow].join(' ')}>
            <Button
              href='/home'
              radiusSmall
              className={[_s.w100PC].join(' ')}
            >
              <Text align='center' color='inherit' weight='medium' size='medium'>Return Home</Text>
            </Button>
          </div>

        </div>
      </div>
    )
  }

}

ErrorBoundary.propTypes = {
  children: PropTypes.node,
}

export default ErrorBoundary
