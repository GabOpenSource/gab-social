'use strict'

import api from '../api'

export const LIVE_STREAMS_FETCH_REQUEST = 'LIVE_STREAMS_FETCH_REQUEST'
export const LIVE_STREAMS_FETCH_SUCCESS = 'LIVE_STREAMS_FETCH_SUCCESS'
export const LIVE_STREAMS_FETCH_FAIL = 'LIVE_STREAMS_FETCH_FAIL'

export const LIVE_STREAM_CREATE_REQUEST = 'LIVE_STREAM_CREATE_REQUEST'
export const LIVE_STREAM_CREATE_SUCCESS = 'LIVE_STREAM_CREATE_SUCCESS'
export const LIVE_STREAM_CREATE_FAIL = 'LIVE_STREAM_CREATE_FAIL'

export const LIVE_STREAM_END_REQUEST = 'LIVE_STREAM_END_REQUEST'
export const LIVE_STREAM_END_SUCCESS = 'LIVE_STREAM_END_SUCCESS'
export const LIVE_STREAM_END_FAIL = 'LIVE_STREAM_END_FAIL'

export const LIVE_STREAM_SHOW_REQUEST = 'LIVE_STREAM_SHOW_REQUEST'
export const LIVE_STREAM_SHOW_SUCCESS = 'LIVE_STREAM_SHOW_SUCCESS'
export const LIVE_STREAM_SHOW_FAIL = 'LIVE_STREAM_SHOW_FAIL'

export const LIVE_STREAM_BY_USERNAME_REQUEST = 'LIVE_STREAM_BY_USERNAME_REQUEST'
export const LIVE_STREAM_BY_USERNAME_SUCCESS = 'LIVE_STREAM_BY_USERNAME_SUCCESS'
export const LIVE_STREAM_BY_USERNAME_FAIL = 'LIVE_STREAM_BY_USERNAME_FAIL'

export const LIVE_STREAM_SET_CURRENT = 'LIVE_STREAM_SET_CURRENT'
export const LIVE_STREAM_UPDATE_VIEWER_COUNT = 'LIVE_STREAM_UPDATE_VIEWER_COUNT'
export const LIVE_STREAM_CHAT_MESSAGE = 'LIVE_STREAM_CHAT_MESSAGE'
export const LIVE_STREAM_HEART = 'LIVE_STREAM_HEART'

export function fetchLiveStreams() {
  return (dispatch, getState) => {
    dispatch({ type: LIVE_STREAMS_FETCH_REQUEST })
    api(getState).get('/api/v1/live_streams').then(response => {
      dispatch({
        type: LIVE_STREAMS_FETCH_SUCCESS,
        streams: response.data,
      })
    }).catch(error => {
      dispatch({ type: LIVE_STREAMS_FETCH_FAIL, error })
    })
  }
}

export function createLiveStream(title, options = {}) {
  return (dispatch, getState) => {
    dispatch({ type: LIVE_STREAM_CREATE_REQUEST })
    return api(getState).post('/api/v1/live_streams', {
      title,
      ...options,
    }).then(response => {
      dispatch({
        type: LIVE_STREAM_CREATE_SUCCESS,
        stream: response.data,
      })
      return response.data
    }).catch(error => {
      dispatch({ type: LIVE_STREAM_CREATE_FAIL, error })
      throw error
    })
  }
}

export function endLiveStream(id) {
  return (dispatch, getState) => {
    dispatch({ type: LIVE_STREAM_END_REQUEST, id })
    api(getState).delete(`/api/v1/live_streams/${id}`).then(response => {
      dispatch({
        type: LIVE_STREAM_END_SUCCESS,
        stream: response.data,
      })
    }).catch(error => {
      dispatch({ type: LIVE_STREAM_END_FAIL, id, error })
    })
  }
}

export function fetchLiveStream(id) {
  return (dispatch, getState) => {
    dispatch({ type: LIVE_STREAM_SHOW_REQUEST, id })
    return api(getState).get(`/api/v1/live_streams/${id}`).then(response => {
      dispatch({
        type: LIVE_STREAM_SHOW_SUCCESS,
        stream: response.data,
      })
      return response.data
    }).catch(error => {
      dispatch({ type: LIVE_STREAM_SHOW_FAIL, id, error })
      throw error
    })
  }
}

export function fetchLiveStreamByUsername(username) {
  return (dispatch, getState) => {
    dispatch({ type: LIVE_STREAM_BY_USERNAME_REQUEST, username })
    return api(getState).get(`/api/v1/live_streams/by_username/${username}`).then(response => {
      dispatch({
        type: LIVE_STREAM_BY_USERNAME_SUCCESS,
        stream: response.data,
        username,
      })
      return response.data
    }).catch(error => {
      dispatch({ type: LIVE_STREAM_BY_USERNAME_FAIL, username, error })
      throw error
    })
  }
}

export function setCurrentStream(streamId) {
  return { type: LIVE_STREAM_SET_CURRENT, streamId }
}

export function updateViewerCount(streamId, count) {
  return { type: LIVE_STREAM_UPDATE_VIEWER_COUNT, streamId, count }
}

export function addChatMessage(streamId, message) {
  return { type: LIVE_STREAM_CHAT_MESSAGE, streamId, message }
}

export function addHeart(streamId, heart) {
  return { type: LIVE_STREAM_HEART, streamId, heart }
}

export const LIVE_STREAM_MUTE_CHAT_REQUEST = 'LIVE_STREAM_MUTE_CHAT_REQUEST'
export const LIVE_STREAM_MUTE_CHAT_SUCCESS = 'LIVE_STREAM_MUTE_CHAT_SUCCESS'
export const LIVE_STREAM_MUTE_CHAT_FAIL = 'LIVE_STREAM_MUTE_CHAT_FAIL'

export function muteChatUser(streamId, username) {
  return (dispatch, getState) => {
    dispatch({ type: LIVE_STREAM_MUTE_CHAT_REQUEST, streamId, username })
    return api(getState).post(`/api/v1/live_streams/${streamId}/mute_chat`, {
      username,
    }).then(response => {
      dispatch({
        type: LIVE_STREAM_MUTE_CHAT_SUCCESS,
        streamId,
        username,
      })
      return response.data
    }).catch(error => {
      dispatch({ type: LIVE_STREAM_MUTE_CHAT_FAIL, streamId, username, error })
      throw error
    })
  }
}
