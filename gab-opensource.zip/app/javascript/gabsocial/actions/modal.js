import { emailConfirmed, me } from '../initial_state'
import { MODAL_EMAIL_CONFIRMATION_REMINDER } from '../constants'

export const MODAL_OPEN = 'MODAL_OPEN'
export const MODAL_CLOSE = 'MODAL_CLOSE'

export const openModal = (type, props) => ({
  type: MODAL_OPEN,
  modalType: type,
  modalProps: props
})

export const closeModal = () => ({ type: MODAL_CLOSE })

/**
 * Returns true if the user's email is unconfirmed (action should be blocked).
 * Opens the confirmation reminder modal as a side effect.
 */
export const requireEmailConfirmation = () => (dispatch) => {
  if (!me || emailConfirmed) return false
  dispatch(openModal(MODAL_EMAIL_CONFIRMATION_REMINDER))
  return true
}
