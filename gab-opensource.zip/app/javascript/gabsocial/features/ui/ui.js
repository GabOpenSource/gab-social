'use strict'

import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
// import { HotKeys } from 'react-hotkeys'
import { Switch, Redirect, Route, withRouter } from 'react-router-dom'
import debounce from 'lodash/debounce'
import queryString from 'query-string'
import moment from 'moment-mini'
import { BREAKPOINT_EXTRA_SMALL, MIN_ACCOUNT_CREATED_AT_ONBOARDING } from '../../constants'
import { fetchUnreadWarningsCount } from '../../actions/warnings'
import LoadingBar from '../../components/loading_bar'
import { clearHeight } from '../../actions/height_cache'
import { openModal } from '../../actions/modal'
import { fetchGroupsByTab } from '../../actions/groups'
import { fetchGroupCategories } from '../../actions/group_categories'
import { fetchFeaturedProducts } from '../../actions/shop'
import {
  fetchRelatedSuggestions,
  fetchPopularSuggestions,
} from '../../actions/suggestions'
import { fetchPublicRooms } from '../../store/voice_public_rooms'
import WrappedRoute from './util/wrapped_route'
import ModalRoot from '../../components/modal/modal_root'
import ToastsContainer from '../../containers/toasts_container'
import PopoverRoot from '../../components/popover/popover_root'
import ProfilePage from '../../pages/profile_page'
import HashtagPage from '../../pages/hashtag_page'
import ShortcutsPage from '../../pages/shortcuts_page'
import GroupPage from '../../pages/group_page'
import GroupsPage from '../../pages/groups_page'
import SearchPage from '../../pages/search_page'
import ErrorPage from '../../pages/error_page'
import HomePage from '../../pages/home_page'
import NotificationsPage from '../../pages/notifications_page'
import ListPage from '../../pages/list_page'
import ListsPage from '../../pages/lists_page'
import BasicPage from '../../pages/basic_page'
import ModalPage from '../../pages/modal_page'
import StatusPage from '../../pages/status_page'
import SettingsPage from '../../pages/settings_page'
import ProPage from '../../pages/pro_page'
import NewsPage from '../../pages/news_page'
import ExplorePage from '../../pages/explore_page'
import ProTimelinePage from '../../pages/pro_timeline_page'
import SuggestionsPage from '../../pages/suggestions_page'
import AboutPage from '../../pages/about_page'
import LinkPage from '../../pages/link_page'
import MessagesPage from '../../pages/messages_page'
import ComposePage from '../../pages/compose_page'
import DeckPage from '../../pages/deck_page'
import IntroductionPage from '../../pages/introduction_page'
import MarketplaceListingCategoriesPage from '../../pages/marketplace_listing_categories_page'
import MarketplaceListingsPage from '../../pages/marketplace_listings_page'
import EmptyPage from '../../pages/empty_page'
import MediaPage from '../../pages/media_page'
import ListCreatePage from '../../pages/list_create_page'
import GroupCreatePage from '../../pages/group_create_page'
import MarketplaceListingCreatePage from '../../pages/marketplace_listing_create_page'
import MarketplaceListingPage from '../../pages/marketplace_listing_page'
import BusinessCreatePage from '../../pages/business_create_page'
import BusinessesPage from '../../pages/businesses_page'
import BusinessCategoriesPage from '../../pages/business_categories_page'
import BusinessPage from '../../pages/business_page'
import BusinessEditPage from '../../pages/business_edit_page'

import {
  About,
  AccountMarketplaceListings,
  AccountPhotoGallery,
  AccountVideoGallery,
  AccountTimeline,
  AccountCommentsTimeline,
  Assets,
  BlockedAccounts,
  BookmarkCollections,
  BookmarkCollectionCreate,
  BookmarkedStatuses,
  Business,
  BusinessCategories,
  BusinessDashboard,
  BusinessCreate,
  BusinessesFrontPage,
  BusinessSearch,
  CaliforniaConsumerProtection,
  CaliforniaConsumerProtectionContact,
  ChatConversationCreate,
  ChatConversationRequests,
  ChatConversationBlockedAccounts,
  ChatConversationMutes,
  Compose,
  Deck,
  DisplayOptionsModal,
  DMCA,
  ExploreTimeline,
  // Filters,
  Followers,
  Following,
  FollowRequests,
  GenericNotFound,
  GroupsCollection,
  GroupCollectionTimeline,
  GroupCreate,
  GroupAbout,
  GroupMedia,
  GroupLinks,
  GroupJoinRequests,
  GroupModerationTimeline,
  GroupMembers,
  GroupRemovedAccounts,
  GroupTimeline,
  GroupsCategories,
  GroupCategory,
  HashtagTimeline,
  HomeTimeline,
  Investors,
  LikedStatuses,
  LinkTimeline,
  ListMembers,
  ListSubscribers,
  ProLinksTimeline,
  ListCreate,
  ListsDirectory,
  ListEdit,
  ListTimeline,
  MarketplaceListingCategories,
  MarketplaceListingCreate,
  MarketplaceListingDetail,
  MarketplaceListingSaves,
  MarketplaceListingsDashboard,
  MarketplaceListingsFrontPage,
  MarketplaceListings,
  Media,
  Messages,
  MutedAccounts,
  News,
  NewsView,
  Notifications,
  PollsTimeline,
  Press,
  PrivacyPolicy,
  ProTimeline,
  ProPhotosTimeline,
  ProVideoClipsTimeline,
  Search,
  Shortcuts,
  StatusContextTimeline,
  StatusFeature,
  StatusLikes,
  StatusReposts,
  StatusQuotes,
  Suggestions,
  TermsOfSale,
  TermsOfService,
  Warnings,
  Introduction,
} from './util/async_components'
import { me, meUsername, isFirstSession, showVideos, showSuggestedUsers, showGroups, meBusinesses, isStaff } from '../../initial_state'
import { parseQuerystring } from '../../utils/querystring'

// Dummy import, to make sure that <Status /> ends up in the application bundle.
// Without this it ends up in ~8 very commonly used bundles.
import '../../components/status'
import { getWindowDimension, isIOS } from '../../utils/is_mobile'
import { fetchShortcuts } from '../../actions/shortcuts'
import LandingPage from '../../pages/landing_page'
import { expandGabTrendsFeeds } from '../../actions/news'
import { fetchManagedBusinesses } from '../../actions/businesses'


const mapStateToProps = (state) => ({
  accountCreatedAt: !!me ? state.getIn(['accounts', me, 'created_at']) : undefined,
  shownOnboarding: state.getIn(['settings', 'shownOnboarding']),
})

/* const keyMap = {
  help: '?',
  new: 'n',
  search: 's',
  forceNew: 'option+n',
  reply: 'r',
  Favorite: 'f',
  boost: 'b',
  mention: 'm',
  open: ['enter', 'o'],
  openProfile: 'p',
  moveDown: ['down', 'j'],
  moveUp: ['up', 'k'],
  back: 'backspace',
  goToHome: 'g h',
  goToNotifications: 'g n',
  goToStart: 'g s',
  goToFavorites: 'g f',
  goToProfile: 'g u',
  goToBlocked: 'g b',
  goToMuted: 'g m',
  goToRequests: 'g r',
} */

class SwitchingArea extends React.PureComponent {

  componentDidMount() {
    window.addEventListener('resize', this.handleResize, {
      passive: true,
    })
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.handleResize)
  }

  handleResize = debounce(() => {
    // The cached heights are no longer accurate, invalidate
    this.props.onLayoutChange()
  }, 500, {
    trailing: true,
  })

  setRef = c => {
    this.node = c.getWrappedInstance()
  }

  render() {
    const { children } = this.props

    return (
      <Switch>
        {
          !!me &&
          <Redirect from='/' to='/home' exact />
        }
        {
          !me &&
          <WrappedRoute path='/' exact publicRoute page={LandingPage} component={ExploreTimeline} content={children} />
        }

        <WrappedRoute path='/home' exact page={HomePage} component={HomeTimeline} content={children} />

        <WrappedRoute path='/deck' exact page={DeckPage} component={Deck} content={children} />

        <WrappedRoute path='/about' publicRoute exact page={AboutPage} component={About} content={children} componentParams={{ title: 'About' }} />
        <WrappedRoute path='/about/assets' publicRoute exact page={AboutPage} component={Assets} content={children} componentParams={{ title: 'Assets' }} />
        <WrappedRoute path='/about/dmca' publicRoute exact page={AboutPage} component={DMCA} content={children} componentParams={{ title: 'DMCA' }} />
        <WrappedRoute path='/about/investors' publicRoute exact page={AboutPage} component={Investors} content={children} componentParams={{ title: 'Investors' }} />
        <WrappedRoute path='/about/press' publicRoute exact page={AboutPage} component={Press} content={children} componentParams={{ title: 'Press' }} />
        <WrappedRoute path='/about/privacy' publicRoute exact page={AboutPage} component={PrivacyPolicy} content={children} componentParams={{ title: 'Privacy Policy' }} />
        <WrappedRoute path='/about/sales' publicRoute exact page={AboutPage} component={TermsOfSale} content={children} componentParams={{ title: 'Terms of Sale' }} />
        <WrappedRoute path='/about/tos' publicRoute exact page={AboutPage} component={TermsOfService} content={children} componentParams={{ title: 'Terms of Service' }} />
        <WrappedRoute path='/about/ccpa' publicRoute exact page={AboutPage} component={CaliforniaConsumerProtection} content={children} componentParams={{ title: 'Terms of Service' }} />
        <WrappedRoute path='/about/ccpa/contact' publicRoute exact page={AboutPage} component={CaliforniaConsumerProtectionContact} content={children} componentParams={{ title: 'Terms of Service' }} />
        <WrappedRoute path='/about/introduction' page={IntroductionPage} component={Introduction} content={children} />

        <WrappedRoute path='/explore' publicRoute page={ExplorePage} component={ExploreTimeline} content={children} componentParams={{ title: 'Explore' }} />
        <WrappedRoute path='/suggestions' exact page={SuggestionsPage} component={Suggestions} content={children} componentParams={{ title: 'Suggestions' }} />
        <WrappedRoute path='/compose' exact page={ComposePage} component={Compose} content={children} componentParams={{ title: 'Compose', page: 'compose' }} />

        <WrappedRoute path='/news' exact publicRoute page={NewsPage} component={News} content={children} componentParams={{ title: 'News' }} />
        <WrappedRoute path='/news/view/:trendsRSSId' page={NewsPage} component={NewsView} content={children} componentParams={{ title: 'News RSS Feed' }} />

        <WrappedRoute path='/messages' exact page={MessagesPage} component={Messages} content={children} componentParams={{ source: 'approved' }} />
        <WrappedRoute path='/messages/new' exact page={BasicPage} component={ChatConversationCreate} content={children} componentParams={{ title: 'New Message' }} />
        {/*<WrappedRoute path='/messages/settings' exact page={MessagesPage} component={MessagesSettings} content={children} componentParams={{ isSettings: true }} />*/}
        <WrappedRoute path='/messages/requests' exact page={MessagesPage} component={ChatConversationRequests} content={children} componentParams={{ isSettings: true, source: 'requested' }} />
        <WrappedRoute path='/messages/blocks' exact page={MessagesPage} component={ChatConversationBlockedAccounts} content={children} componentParams={{ isSettings: true }} />
        <WrappedRoute path='/messages/muted_conversations' exact page={MessagesPage} component={ChatConversationMutes} content={children} componentParams={{ isSettings: true }} />
        <WrappedRoute path='/messages/:chatConversationId' exact page={MessagesPage} component={Messages} content={children} componentParams={{ source: 'approved' }} />

        <WrappedRoute path='/timeline/pro' publicRoute exact page={ProTimelinePage} component={ProTimeline} content={children} componentParams={{ title: 'Pro Feed' }} />
        <WrappedRoute path='/timeline/polls' publicRoute exact page={ProTimelinePage} component={PollsTimeline} content={children} componentParams={{ title: 'Pro Polls Feed', noRightSidebar: 1 }} />
        <WrappedRoute path='/timeline/photos' publicRoute exact page={ProTimelinePage} component={ProPhotosTimeline} content={children} componentParams={{ title: 'Pro Photos Feed', noRightSidebar: 1 }} />
        <WrappedRoute path='/timeline/clips' publicRoute exact page={ProTimelinePage} component={ProVideoClipsTimeline} content={children} componentParams={{ title: 'Clips', noRightSidebar: 1 }} />

        <WrappedRoute path='/timeline/context/:statusContextId' exact page={BasicPage} component={StatusContextTimeline} content={children} componentParams={{ title: 'Status Context Feed' }} />

        <WrappedRoute path='/groups' publicRoute exact page={GroupsPage} component={GroupCollectionTimeline} content={children} componentParams={{ activeTab: 'timeline', collectionType: 'member' }} />
        { /* <WrappedRoute path='/groups/browse/new' exact page={GroupsPage} component={GroupsCollection} content={children} componentParams={{ activeTab: 'new' }} /> */ }
        <WrappedRoute path='/groups/browse/featured' publicRoute exact page={GroupsPage} component={GroupsCollection} content={children} componentParams={{ activeTab: 'featured' }} />
        <WrappedRoute path='/groups/browse/member' exact page={GroupsPage} component={GroupsCollection} content={children} componentParams={{ activeTab: 'member' }} />
        <WrappedRoute path='/groups/browse/admin' exact page={GroupsPage} component={GroupsCollection} content={children} componentParams={{ activeTab: 'admin' }} />
        <WrappedRoute path='/groups/browse/categories' publicRoute exact page={GroupsPage} component={GroupsCategories} content={children} componentParams={{ activeTab: 'categories' }} />
        <WrappedRoute path='/groups/browse/categories/:sluggedCategory' publicRoute exact page={GroupsPage} component={GroupCategory} content={children} componentParams={{ activeTab: 'categories' }} />

        <WrappedRoute path='/groups/create' page={GroupCreatePage} component={GroupCreate} content={children} componentParams={{ title: 'Create Group', page: 'create-group' }} />
        <WrappedRoute path='/groups/:id/members' page={GroupPage} component={GroupMembers} content={children} />
        <WrappedRoute path='/groups/:id/requests' page={GroupPage} component={GroupJoinRequests} content={children} />
        <WrappedRoute path='/groups/:id/moderation' page={GroupPage} component={GroupModerationTimeline} content={children} />
        <WrappedRoute path='/groups/:id/removed-accounts' page={GroupPage} component={GroupRemovedAccounts} content={children} />
        <WrappedRoute path='/groups/:id/edit' page={GroupPage} component={GroupCreate} content={children} componentParams={{ forwardGroupId: true }}  />
        <WrappedRoute path='/groups/:id/about' publicRoute page={GroupPage} component={GroupAbout} content={children} />
        <WrappedRoute path='/groups/:id/media' publicRoute page={GroupPage} component={GroupMedia} content={children} />
        <WrappedRoute path='/groups/:id/links' publicRoute page={GroupPage} component={GroupLinks} content={children} />
        <WrappedRoute path='/groups/:id/compose' page={ComposePage} component={Compose} content={children} componentParams={{ title: 'Compose', page: 'compose' }} />
        { /* <WrappedRoute path='/groups/:id/media' publicRoute page={GroupPage} component={GroupTimeline} content={children} componentParams={{ isTimeline: true, onlyMedia: true }} /> */ }
        <WrappedRoute path='/groups/:id' exact publicRoute page={GroupPage} component={GroupTimeline} content={children} componentParams={{ isTimeline: true }} />

        <WrappedRoute path='/tags/:id' publicRoute page={HashtagPage} component={HashtagTimeline} content={children} componentParams={{ title: 'Hashtag' }} />

        <WrappedRoute path='/links/:id' publicRoute page={LinkPage} component={LinkTimeline} content={children} componentParams={{ title: 'Link Feed' }} />

        <WrappedRoute path='/shortcuts' page={ShortcutsPage} component={Shortcuts} content={children} />

        <WrappedRoute path='/warnings' page={BasicPage} component={Warnings} content={children} componentParams={{ title: 'Warnings' }} />

        <WrappedRoute path='/feeds' publicRoute exact page={ListsPage} component={ListsDirectory} content={children} />
        <WrappedRoute path='/feeds/create' exact page={ListCreatePage} component={ListCreate} content={children} />
        <WrappedRoute path='/feeds/:id/edit' exact page={ModalPage} component={ListEdit} content={children} componentParams={{ title: 'Edit Feed', page: 'edit-feed' }} />
        <WrappedRoute path='/feeds/:id/members' exact publicRoute page={ListPage} component={ListMembers} content={children} />
        <WrappedRoute path='/feeds/:id/subscribers' exact publicRoute page={ListPage} component={ListSubscribers} content={children} />
        <WrappedRoute path='/feeds/:id' publicRoute page={ListPage} component={ListTimeline} content={children} />

        <WrappedRoute path='/notifications' exact page={NotificationsPage} component={Notifications} content={children} />
        <Redirect from='/follow_requests' to='/notifications/follow_requests' exact />
        <WrappedRoute path='/notifications/follow_requests' exact page={NotificationsPage} component={FollowRequests} content={children} />

        <Redirect from='/search' to='/search/people' exact />
        <WrappedRoute path='/search/:tab' publicRoute page={SearchPage} component={Search} content={children} />

        <WrappedRoute path='/marketplace' exact publicRoute page={MarketplaceListingsPage} component={MarketplaceListingsFrontPage} content={children} componentParams={{ title: 'Marketplace', page: 'marketplace' }} />
        <WrappedRoute path='/marketplace/categories' exact publicRoute page={MarketplaceListingCategoriesPage} component={MarketplaceListingCategories} content={children} componentParams={{ title: 'Marketplace', page: 'marketplace-categories' }} />
        <WrappedRoute path='/marketplace/listings' exact publicRoute page={MarketplaceListingsPage} component={MarketplaceListings} content={children}  componentParams={{ page: 'marketplace-listings' }} />
        <WrappedRoute path='/marketplace/listings/:categorySlug' exact publicRoute page={MarketplaceListingsPage} component={MarketplaceListings} content={children} />
        <WrappedRoute path='/marketplace/create' exact page={MarketplaceListingCreatePage} component={MarketplaceListingCreate} content={children} componentParams={{ title: 'New Listing', page: 'marketplace-listing-create' }} />
        <WrappedRoute path='/marketplace/dashboard' exact page={MarketplaceListingPage} component={MarketplaceListingsDashboard} content={children} componentParams={{ title: 'Your Listings', page: 'marketplace-listing-dashboard' }} />
        <WrappedRoute path='/marketplace/saved' exact page={MarketplaceListingPage} component={MarketplaceListingSaves} content={children} componentParams={{ title: 'Marketplace Saves', page: 'marketplace-listing-saves' }} />
        <WrappedRoute path='/marketplace/item/:id/edit' page={MarketplaceListingCreatePage} component={MarketplaceListingCreate} content={children} componentParams={{ title: 'Edit Marketplace Listing', page: 'marketplace-listing-edit' }} />
        <WrappedRoute path='/marketplace/item/:id' publicRoute page={MarketplaceListingPage} component={MarketplaceListingDetail} content={children} componentParams={{ title: 'Listing', page: 'marketplace-listing-detail' }} />

        <WrappedRoute path='/marketplace/business/join' publicRoute exact page={BusinessCreatePage} component={BusinessCreate} content={children} />
        <WrappedRoute path='/marketplace/business/join/thanks' exact page={BusinessCreatePage} component={BusinessCreate} content={children} componentParams={{ page: 'business-join-thanks' }} />
        
        <WrappedRoute path='/businesses' publicRoute exact page={BusinessesPage} component={BusinessesFrontPage} content={children} />
        <WrappedRoute path='/businesses/categories' exact publicRoute page={BusinessCategoriesPage} component={BusinessCategories} content={children} componentParams={{ title: 'Businesss', page: 'business-categories' }} />
        <WrappedRoute path='/businesses/dashboard' exact publicRoute page={BusinessesPage} component={BusinessDashboard} content={children} componentParams={{ title: 'Businesss Dashboard', page: 'business-dashboard' }} />
        <WrappedRoute path='/businesses/search' exact publicRoute page={BusinessesPage} component={BusinessSearch} content={children} componentParams={{ title: 'Businesss Search', page: 'business-search' }} />
        <WrappedRoute path='/businesses/search/:categorySlug' exact publicRoute page={BusinessesPage} component={BusinessSearch} content={children} componentParams={{ title: 'Businesss Search', page: 'business-search' }} />
        <WrappedRoute path='/business/:businessId' exact publicRoute page={BusinessPage} component={Business} content={children} />
        <WrappedRoute path='/business/:businessId/edit' exact page={BusinessEditPage} component={BusinessCreate} content={children} />

        <WrappedRoute path='/settings/blocks' exact page={SettingsPage} component={BlockedAccounts} content={children} componentParams={{ title: 'Blocked Users' }} />
        <WrappedRoute path='/settings/mutes' exact page={SettingsPage} component={MutedAccounts} content={children} componentParams={{ title: 'Muted Users' }} />
        <WrappedRoute path='/settings/display-options' exact page={SettingsPage} component={DisplayOptionsModal} content={children} />

        <WrappedRoute path='/:username' publicRoute exact page={ProfilePage} component={AccountTimeline} content={children} />

        <WrappedRoute path='/:username/comments' page={ProfilePage} component={AccountCommentsTimeline} content={children} />

        <WrappedRoute path='/:username/followers' page={ProfilePage} component={Followers} content={children} />
        <WrappedRoute path='/:username/following' page={ProfilePage} component={Following} content={children} />
        {/* <WrappedRoute path='/:username/marketplace_listings' page={ProfilePage} component={AccountMarketplaceListings} content={children} /> */}

        <WrappedRoute path='/:username/listings' publicRoute exact page={ProfilePage} component={AccountMarketplaceListings} content={children} componentParams={{ noSidebar: true }} />
        <WrappedRoute path='/:username/photos' publicRoute exact page={ProfilePage} component={AccountPhotoGallery} content={children} componentParams={{ noSidebar: true }} />
        { /* <WrappedRoute path='/:username/albums/:albumId' page={ProfilePage} component={AccountAlbumGallery} content={children} componentParams={{ noSidebar: true }} />  */ }
        <WrappedRoute path='/:username/videos' publicRoute exact page={ProfilePage} component={AccountVideoGallery} content={children} componentParams={{ noSidebar: true }} />

        <WrappedRoute path='/:username/likes' page={ProfilePage} component={LikedStatuses} content={children} />
        <WrappedRoute path='/:username/bookmarks' exact page={ProfilePage} component={BookmarkCollections} content={children} />
        <WrappedRoute path='/:username/bookmarks/create' page={ModalPage} component={BookmarkCollectionCreate} content={children} componentParams={{ title: 'Create Bookmark Collection', page: 'create-bookmark-collection' }} />
        {/* <WrappedRoute path='/:username/bookmarks/:bookmarkCollectionId/edit' exact page={ModalPage} component={BookmarkCollectionEdit} content={children} componentParams={{ title: 'Edit Bookmark Collection', page: 'edit-bookmark-collection' }} /> */}
        <WrappedRoute path='/:username/bookmarks/:bookmarkCollectionId' page={ProfilePage} component={BookmarkedStatuses} content={children} />

        <WrappedRoute path='/:username/posts/:statusId' publicRoute exact page={StatusPage} component={StatusFeature} content={children} />

        <WrappedRoute path='/:username/posts/:statusId/reposts' publicRoute page={ModalPage} component={StatusReposts} content={children} componentParams={{ title: 'Reposts' }} />
        <WrappedRoute path='/:username/posts/:statusId/quotes' publicRoute page={ModalPage} component={StatusQuotes} content={children} componentParams={{ title: 'Quotes' }} />
        <WrappedRoute path='/:username/posts/:statusId/likes' page={ModalPage} component={StatusLikes} content={children} componentParams={{ title: 'Likes' }} />

        <WrappedRoute path='/:username/posts/:statusId/media/:mediaIndex' publicRoute page={MediaPage} component={Media} content={children} />

        <WrappedRoute page={ErrorPage} component={GenericNotFound} content={children} />
      </Switch>
    )
  }

}

SwitchingArea.propTypes = {
  children: PropTypes.node,
  location: PropTypes.object,
  onLayoutChange: PropTypes.func.isRequired,
}

class UI extends React.PureComponent {

  state = {
    fetchedHome: false,
    translateY: Math.min(-window.scrollY, 0), // Initialize with the negative of current scroll position
    lastScrollY: window.scrollY,
    userHasScrolled: false,
  }

  timeout = null

  handleLayoutChange = () => {
    // The cached heights are no longer accurate, invalidate
    this.props.dispatch(clearHeight())
  }

  handleServiceWorkerPostMessage = ({ data }) => {
    if (data.type === 'navigate') {
      this.props.history.push(data.path)
    } else {
      console.warn('Unknown message type:', data.type)
    }
  }

  handleScroll = () => {
    const { lastScrollY, translateY, userHasScrolled } = this.state
    const currentScrollY = window.scrollY
    const limit = 130
    const diffScroll = lastScrollY - currentScrollY
    const multiplier = 2.65
    let newTranslateY = translateY + (diffScroll * multiplier)

    // Check if user has initiated a scroll
    if (!userHasScrolled && currentScrollY !== 0) {
      this.setState({ userHasScrolled: true })
    }
    if (!userHasScrolled) return

    if (newTranslateY > 0 || currentScrollY < limit) {
      newTranslateY = 0
    } else if (newTranslateY < -limit) {
      // console.log("limit:", limit)
      newTranslateY = Math.min(-limit, 0)
    }

    this.setState({
      translateY: newTranslateY,
      lastScrollY: currentScrollY,
    })

    const navbarEl = document.getElementById('nav-container')
    if (navbarEl) navbarEl.style.transform = `translateY(${newTranslateY}px)`

    const navbarEmailEl = document.getElementById('nav-email')
    if (navbarEmailEl) navbarEmailEl.style.transform = `translateY(${newTranslateY}px)`

    const fabEl = document.getElementById('fab')
    if (fabEl) fabEl.style.transform = `translateY(${Math.min(-newTranslateY, 60)}px)`

    const footer = document.getElementById('footer')
    if (footer) footer.style.transform = `translateY(${-newTranslateY}px)`
  }

  componentDidMount() {
    const { dispatch } = this.props

    const initialState = getWindowDimension()
    const width = initialState.width
    const isXS = width <= BREAKPOINT_EXTRA_SMALL
    if (isXS && isIOS()) window.addEventListener('scroll', this.handleScroll)

    if (!!me) {
      dispatch(expandGabTrendsFeeds())
    }

    if (Array.isArray(meBusinesses) && meBusinesses.length > 0) {
      dispatch(fetchManagedBusinesses())
    }
    
    dispatch(fetchFeaturedProducts())

    if (!me) return

    dispatch(fetchShortcuts())
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', this.handleServiceWorkerPostMessage)
    }

    if (typeof window.Notification !== 'undefined' && Notification.permission === 'default') {
      window.setTimeout(() => Notification.requestPermission(), 120 * 1000)
    }

    const pathname = this.props.location.pathname

    if (pathname === '/home') {
      this.props.dispatch(fetchUnreadWarningsCount())
    }

    const introductionPath = '/about/introduction'
    if (
      !!me &&
      this.props.accountCreatedAt &&
      pathname.startsWith(introductionPath) === false
    ) {
      //If first time opening app, and is new user, show onboarding
      const accountCreatedAtValue = moment(this.props.accountCreatedAt).valueOf()
      const onboard = isFirstSession &&
        !this.props.shownOnboarding &&
        accountCreatedAtValue > MIN_ACCOUNT_CREATED_AT_ONBOARDING
      if (onboard) {
        this.props.history.push(introductionPath)
      }
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.location !== prevProps.location) {
      const pathname = this.props.location.pathname

      if (pathname === '/home' && !this.state.fetchedHome) {
        this.setState({ fetchedHome: true })
        this.props.dispatch(fetchUnreadWarningsCount())
      }
    }
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScroll)
  }

  setRef = (c) => {
    this.node = c
  }

  handleHotkeyNew = (e) => {
    e.preventDefault()

    const element = this.node.querySelector('.compose-form__autosuggest-wrapper textarea')

    if (element) {
      element.focus()
    }
  }

  handleHotkeySearch = (e) => {
    e.preventDefault()

    const element = this.node.querySelector('.search__input')

    if (element) {
      element.focus()
    }
  }

  handleHotkeyForceNew = (e) => {
    this.handleHotkeyNew(e)
  }

  handleHotkeyBack = () => {
    if (window.history && window.history.length === 1) {
      this.props.history.push('/home') // homehack
    } else {
      this.props.history.goBack()
    }
  }

  setHotkeysRef = (c) => {
    this.hotkeys = c
  }

  handleHotkeyToggleHelp = () => {
    this.props.dispatch(openModal('HOTKEYS'))
  }

  handleHotkeyGoToHome = () => {
    this.props.history.push('/home')
  }

  handleHotkeyGoToNotifications = () => {
    this.props.history.push('/notifications')
  }

  handleHotkeyGoToStart = () => {
    this.props.history.push('/getting-started')
  }

  handleHotkeyGoToFavorites = () => {
    this.props.history.push(`/${meUsername}/favorites`)
  }

  handleHotkeyGoToProfile = () => {
    this.props.history.push(`/${meUsername}`)
  }

  handleHotkeyGoToBlocked = () => {
    this.props.history.push('/blocks')
  }

  handleHotkeyGoToMuted = () => {
    this.props.history.push('/mutes')
  }

  handleHotkeyGoToRequests = () => {
    this.props.history.push('/follow_requests')
  }

  handleOpenComposeModal = () => {
    this.props.dispatch(openModal('COMPOSE'))
  }

  render() {
    const { children, location } = this.props

    // : todo :
    // const handlers = me ? {
    //   help: this.handleHotkeyToggleHelp,
    //   new: this.handleHotkeyNew,
    //   search: this.handleHotkeySearch,
    //   forceNew: this.handleHotkeyForceNew,
    //   back: this.handleHotkeyBack,
    //   goToHome: this.handleHotkeyGoToHome,
    //   goToNotifications: this.handleHotkeyGoToNotifications,
    //   goToStart: this.handleHotkeyGoToStart,
    //   goToFavorites: this.handleHotkeyGoToFavorites,
    //   goToProfile: this.handleHotkeyGoToProfile,
    //   goToBlocked: this.handleHotkeyGoToBlocked,
    //   goToMuted: this.handleHotkeyGoToMuted,
    //   goToRequests: this.handleHotkeyGoToRequests,
    // } : {}

    return (
      <div ref={this.setRef} className={_s.gabsocial}>
        <LoadingBar
          maxProgress={100}
          progressIncrease={100}
          showFastActions
          className={[_s.h2PX, _s.posFixed, _s.z6, _s.top53PX, _s.bgBrandLight, _s.saveAreaInsetMT].join(' ')}
        />

        <SwitchingArea location={location} onLayoutChange={this.handleLayoutChange}>
          {children}
        </SwitchingArea>

        <ModalRoot />
        <PopoverRoot />

        <ToastsContainer />
      </div>
    )
  }

}

UI.propTypes = {
  dispatch: PropTypes.func.isRequired,
  children: PropTypes.node,
  isComposing: PropTypes.bool,
  location: PropTypes.object,
  history: PropTypes.object.isRequired,
  accountCreatedAt: PropTypes.string,
  shownOnboarding: PropTypes.bool,
}

export default withRouter(connect(mapStateToProps)(UI))
