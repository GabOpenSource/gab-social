import React from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import {
  changeBusinessEditorAttr,
  resetBusinessEditor,
  setBusiness,
  submitBusinessEditor,
} from '../actions/business_editor'
import { BREAKPOINT_EXTRA_SMALL, CX, MODAL_BUSINESS_CATEGORIES, MODAL_LOCATION, MODAL_UNAUTHORIZED } from '../constants'
import { businessCreate, businessEdit, fetchBusinessById, fetchBusinessCategories } from '../actions/businesses'
import Button from '../components/button'
import Input from '../components/input'
import Text from '../components/text'
import Divider from '../components/divider'
import DisplayName from '../components/display_name'
import Avatar from '../components/avatar'
import { me, meBusinesses } from '../initial_state'
import Textarea from '../components/textarea'
import { openModal } from '../actions/modal'
import Pills from '../components/pills'
import FileInput from '../components/file_input'
import BusinessHoursInput from '../components/business/business_hours_input'
import BusinessGalleryInput from '../components/business/business_gallery_input'
import Switch from '../components/switch'
import BusinessStatusTag from '../components/business/business_status_tag'
import moment from 'moment-mini'
import BusinessCouponsInput from '../components/business/business_coupons_input'
import isObject from 'lodash/isObject'

class BusinessCreate extends React.PureComponent {

  state = {
    tab: 'basic',
    websites: [''],
  }

  componentDidMount() {
    const { attrs, business, businessId, isEditing } = this.props
    this.props.onFetchBusinessCategories()

    if (!business) {
			if (businessId) {
				this.props.onFetchBusiness(businessId)
			} else if (!isEditing) {
				this.props.onResetEditor()
			}
		} else {
			this.setup(business)
		}
  }

  componentDidUpdate(prevProps) {
    const { business, businessId, attrs, isEditing } = this.props
    if (businessId && !prevProps.business && !!business) {
      // console.log("-----here attrs:", attrs)
      this.setup(business)
    }
    // if (!business) {
    //   if (businessId) {
    //     this.props.onFetchBusiness(businessId)
    //   } else if (!isEditing) {
    //     this.props.onResetEditor()
    //   }
    // } else {
    //   this.props.onSetBusiness(business)
    // }
  }

  setup = (business) => {
    if (!business) return null
    this.props.onSetBusiness(business)
    const existingSites = business.get('websites')
    const setSites = !!existingSites ? existingSites.toJS() : []
    this.setState({ websites: setSites })
  }

  handleOnSubmit = () => {
    if (!me) {
      this.props.onOpenUnauthorizedModal()
    } else {
      this.handleOnChange('websites', this.state.websites)
      this.props.onSubmit(this.props.history, this.props.isEditing)
    }
  }

  handleLogoImageChange = (e) => {
		try {
      this.props.onChangeAttr('logo', e.target.files[0])
    } catch (error) {
     // 
    }
	}

  handleCoverImageChange = (e) => {
		try {
      this.props.onChangeAttr('cover', e.target.files[0])
    } catch (error) {
    //  console.log("error:", error)
    }
	}

  handleOnChange = (key, value) => {
    this.props.onChangeAttr(key, value)
  }

  handleOnOpenCategoriesModal = () => {
    this.props.onOpenCategoriesModal()
  }

  handleOnOpenLocationModal = () => {
    this.props.onOpenLocationModal(this.handleOnChangeLocation)
  }

  handleOnChangeTab = (tab) => {
    this.setState({ tab })
  }

  handleOnChangeLocation = (location) => {
    this.props.onChangeAttr('location', location)
  }

  handleOnChangeWebsite = (index, value) => {
    const newWebsites = [...this.state.websites]
    newWebsites[index] = value
    this.setState({ websites: newWebsites })
  }

  handleAddWebsite = () => {
    if (this.state.websites.length < 6) {
      this.setState(prevState => ({ websites: [...prevState.websites, ''] }))
    }
  }

  handleRemoveWebsite = (index) => {
    const newWebsites = [...this.state.websites]
    newWebsites.splice(index, 1)
    this.setState({ websites: newWebsites })
  }

  handleToggleUserVisibility = (e) => {
    this.props.onChangeAttr('account_hidden', e.currentTarget.checked)
  }

  render() {
    const {
      isXS,
      attrs,
      isChanged,
      account,
      isEditing,
      business,
      businessId,
      isSubmitting,
      businessAccount,
    } = this.props
    const { tab, websites } = this.state

    // console.log("attrs", attrs)
    if (!attrs) return null

    const name = attrs.get('name', '')
    const tagline = attrs.get('tagline', '')
    const description = attrs.get('description', '')
    const attrWebsites = attrs.get('websites', [])
    const categories = attrs.get('categories', [])
    const logo = attrs.get('logo', '')
    const phone = attrs.get('phone', '')
    const ctaTitle = attrs.get('cta_title', '')
    const ctaLink = attrs.get('cta_link', '')
    const location = attrs.get('location')
    const account_hidden = attrs.get('account_hidden') === -1 ? !!businessAccount ? businessAccount.get('visibility') === 'hidden' : true : attrs.get('account_hidden')

    const pillItems = !!categories ? categories.map((s) => ({
      title: s.name,
    })) : undefined
    const hasCategories = Array.isArray(pillItems) && pillItems.length > 0

    const submittable = !!name && !!tagline && !!description && !!attrWebsites && hasCategories
    const isDisabled = isSubmitting

    // console.log("business:", business)

    const wrapperClasses = CX({
      d: 1,
      w100PC: 1,
      h100PC: 1,
      mt15: isXS,
      pt15: isXS,
      borderTop1PX: isXS && !isEditing,
      borderColorSecondary: isXS && !isEditing,
    })

    const upperContainerClasses = CX({
      d: 1,
      flexRow: 1,
      pt10: (isXS && !isEditing) || (!isXS && isEditing),
      // maxW100PC130PX: !isXS
    })

    const categoryContainerClasses = CX({
      d: 1,
      px5: hasCategories,
      pt5: hasCategories,
      pl15: !hasCategories,
      jcCenter: 1,
      w100PC: 1,
      h40PX: !hasCategories,
      bgPrimary: 1,
      radiusTiny: 1,
      border1PX: 1,
      borderColorInput: 1,
      cursorPointer: 1,
      outlineNone: 1,
      outlineBrand_onFocus: 1,
    })

    const expirationDate = !!business && (!!business.get('pro_expires_at') ? moment(business.get('pro_expires_at')).format('MM-DD-YYYY') : '-')
    
    const tabs = [
      {
        title: 'Basic',
        isActive: tab === 'basic',
        onClick: () => { this.handleOnChangeTab('basic') },
      },
      {
        title: 'Details',
        isActive: tab === 'details',
        onClick: () => { this.handleOnChangeTab('details') },
      },
      {
        title: 'Customization',
        isActive: tab === 'custom',
        onClick: () => { this.handleOnChangeTab('custom') },
      },
      !!business && {
        title: 'Offers',
        isActive: tab === 'offers',
        onClick: () => { this.handleOnChangeTab('offers') },
      },
      !!business && {
        title: 'Settings',
        isActive: tab === 'settings',
        onClick: () => { this.handleOnChangeTab('settings') },
      },
    ].filter(Boolean)

    return (
      <div className={wrapperClasses}>
        <div className={[_s.d, _s.w100PC, _s.flexRow, _s.mb5].join(' ')}>
          <div className={upperContainerClasses}>
            {!!me && <Avatar size={38} account={account} />}
            <div className={!!me ? [_s.d, _s.pl15].join(' ') : _s.d}>
              { !!me && <DisplayName account={account} noUsername /> }
              { !me && <Text>Log in or Sign up</Text>}
              <Text className={_s.pt2} size='small' color='tertiary'>{isEditing ? 'Edit' : 'List'} your Business</Text>
            </div>
          </div>
          {
            /*submittable && 
            <div className={[_s.d, _s.mlAuto, _s.pl10].join(' ')}>
              <Button
                radiusSmall
              >
                <Text color='inherit' weight='medium'>Join now!</Text>
              </Button>
            </div>*/
          }
        </div>
        
        <div className={[_s.d, _s.w100PC, _s.borderBottom1PX, _s.flexRow, _s.borderColorSecondary].join(' ')}>
          {
            tabs.map((tabItem) => {
              const activeClass = tabItem.isActive ? _s.navigationUnderlineActive : undefined
              return (
                <Button
                  noClasses
                  onClick={tabItem.onClick}
                  className={[_s.d, _s.py15, _s.px10, _s.bgTransparent, _s.cursorPointer, _s.outlineNone, activeClass].join(' ')}
                >
                  <Text color='brand' weight={tabItem.isActive ? 'bold' : ''} size='medium'>
                    {tabItem.title}
                  </Text>
                </Button>
              )
            })
          }
        </div>
        
        {/* BASIC - START */}
        <div className={tab === 'basic' ? [_s.d, _s.w100PC].join(' ') : _s.displayNone}>
          <div className={[_s.d, _s.w100PC, _s.pt15].join(' ')}>
            <div className={[_s.d, _s.flexRow].join(' ')}>
              <div className={[_s.d].join(' ')}>
                <Text className={[_s.mb15].join(' ')} weight='medium' color='primary' tagName='label'>
                  Logo
                </Text>
                <FileInput
                  disabled={isSubmitting}
                  id='business-logo-photo'
                  onChange={this.handleLogoImageChange}
                  file={business ? business.get('logo_thumbnail_url') : undefined}
                  width='136px'
                  height='136px'
                  isBordered
                />
              </div>
              <div className={[_s.d, _s.pl15, _s.flex1].join(' ')}>
                <Text className={[_s.mb15].join(' ')} weight='medium' color='primary' tagName='label'>
                  Banner
                  <Text color='tertiary' size='small'>&nbsp;·&nbsp;1200px x 200px</Text>
                </Text>
                <FileInput
                  disabled={isSubmitting}
                  id='busienss-cover-photo'
                  onChange={this.handleCoverImageChange}
                  file={business ? business.get('cover_image_url') : undefined}
                  width='100%'
                  height='136px'
                  isBordered
                />
              </div>

            </div>
            <Text className={[_s.mt5, _s.mb15, _s.pb5].join(' ')} size='small' color='tertiary'>
              Max: 5MB. Accepted image types: .jpg, .png
            </Text>
          </div>

          <Input
            isRequired
            title='Business Name *'
            placeholder='My Business Name'
            value={name}
            onChange={(value) => this.handleOnChange('name', value)}
            isDisabled={isDisabled}
            maxLength={180}
          />

          <Divider isInvisible isSmall />

          <Textarea
            title='Tagline *'
            value={tagline}
            onChange={(value) => this.handleOnChange('tagline', value)}
            placeholder='My Business sells...'
            isDisabled={isDisabled}
            className={_s.minH40PX}
            maxLength={3000}
            isRequired
          />

          <Divider isInvisible isSmall />

          <Textarea
            title='Long description *'
            value={description}
            rows={2}
            onChange={(value) => this.handleOnChange('description', value)}
            placeholder='My Business does...'
            isDisabled={isDisabled}
            className={_s.minH150PX}
            maxLength={3000}
            isRequired
          />

          <Divider isInvisible isSmall />
          
          <div className={[_s.d, _s.flexRow, _s.aiStart].join(' ')}>
            <Text className={[_s.mb15].join(' ')} weight='medium' color='primary' tagName='label'>
              Websites *
            </Text>
            <div className={[_s.d, _s.mlAuto, _s.aiStart].join(' ')}>
              <Button
                radiusSmall
                backgroundColor='none'
                color='brand'
                onClick={this.handleAddWebsite}
                isDisabled={websites.length >= 6}
                className={[_s.py2, _s.bgSubtle_onHover].join(' ')}
              >
                <Text color='inherit' weight='bold'>
                  Add
                </Text>
              </Button>
            </div>
          </div>
          {
            websites.map((stateWebsite, i) => (
              <div key={`business-website-${i}`} className={[_s.d, _s.flexRow, _s.mb10, _s.aiCenter].join(' ')}>
                <Input
                  isRequired
                  placeholder='https://mybusiness.com'
                  value={stateWebsite}
                  isDisabled={isDisabled}
                  maxLength={180}
                  onChange={e => this.handleOnChangeWebsite(i, e)} 
                />
                {
                  i > 0 &&
                  <Button
                    radiusSmall
                    backgroundColor='none'
                    color='secondary'
                    icon='close'
                    iconSize='12px'
                    onClick={() => this.handleRemoveWebsite(i)}
                    className={[_s.py5, _s.border1PX, _s.aiCenter, _s.jcCenter, _s.borderColorInput, _s.ml10, _s.h40PX, _s.w40PX, _s.bgSubtle_onHover].join(' ')}
                  />
                }
              </div>
            ))
          }

          <div className={[_s.d, _s.mb10, _s.mt5, _s.py5].join(' ')}>
            <Text weight='medium' color='primary' tagName='label'>
              Categories *
            </Text>
          </div>
          <Button
            noClasses
            isDisabled={isDisabled}
            onClick={this.handleOnOpenCategoriesModal}
            className={categoryContainerClasses}
          >
            { hasCategories && <Pills pills={pillItems} /> }
            { !hasCategories && <Text size='large' color='tertiary'>Select categories</Text> }
          </Button>
        </div>
        {/* BASIC - END */}

        {/* DETAILS - START */}        
        <div className={tab === 'details' ? [_s.d, _s.w100PC, _s.pt15].join(' ') : _s.displayNone}>
          <Input
            isRequired
            title='Business Phone Number'
            placeholder='555-555-5555'
            type='tel'
            value={phone}
            onChange={(value) => this.handleOnChange('phone', value)}
            isDisabled={isDisabled}
            maxLength={32}
          />

          <Divider isInvisible isSmall />

          <div className={[_s.d, _s.mb10, _s.py5].join(' ')}>
            <Text weight='medium' color='primary' tagName='label'>
              Location
            </Text>
          </div>
          <Button
            noClasses
            isDisabled={isDisabled}
            onClick={this.handleOnOpenLocationModal}
            className={[_s.d, _s.px10, _s.py10, _s.jcCenter, _s.w100PC, _s.minH40PX, _s.bgPrimary, _s.radiusTiny, _s.border1PX, _s.borderColorInput, _s.cursorPointer, _s.outlineNone, _s.outlineBrand_onFocus].join(' ')}
          >
            {
              !!location && isObject(location) &&
              <Text size='large' weight='medium' color='brand'>{location.display_name}</Text>
            }
            {
              !location && <Text size='large' color='tertiary'>Select location</Text>
            }
          </Button>
          {/* <Divider isInvisible isSmall />
          <BusinessGalleryInput /> */}
          {!!business && <Divider isInvisible isSmall /> }
          {!!business && <BusinessHoursInput businessId={businessId} />}
        </div>
        {/* DETAILS - END */}        

        {/* CUSTOM - START */}        
        <div className={tab === 'custom' ? [_s.d, _s.w100PC, _s.pt15].join(' ') : _s.displayNone}>
          <Input
            title='Call to Action - Title'
            placeholder='Shop Now, Buy Now, Learn More, etc.'
            value={ctaTitle}
            onChange={(value) => this.handleOnChange('cta_title', value)}
            isDisabled={isDisabled}
            maxLength={180}
          />

          <Divider isInvisible isSmall />

          <Input
            title='Call to Action - Link'
            placeholder='https://mybusiness.com'
            value={ctaLink}
            onChange={(value) => this.handleOnChange('cta_link', value)}
            isDisabled={isDisabled}
            maxLength={180}
          />
        </div>
        {/* CUSTOM - END */}

        {/* DETAILS - OFFERS */}        
        <div className={tab === 'offers' ? [_s.d, _s.w100PC, _s.pt15].join(' ') : _s.displayNone}>
          <BusinessCouponsInput businessId={businessId} onChange={this.handleOnChangeCoupons} />
        </div>
        {/* DETAILS - OFFERS */}

        {/* DETAILS - SETTINGS */}        
        <div className={tab === 'settings' ? [_s.d, _s.w100PC, _s.pt15].join(' ') : _s.displayNone}>
          <div className={[_s.d, _s.w100PC, _s.mb10].join(' ')}>
            <div className={[_s.d, _s.mb10, _s.py5].join(' ')}>
              <Text weight='medium' color='primary' tagName='label'>
                Business Status
              </Text>
            </div>
            <div className={[_s.d, _s.w100PC, _s.py5].join(' ')}>
              <BusinessStatusTag id={businessId} />
            </div>
          </div>
          
          {
            businessAccount &&
            <>
              <div className={[_s.d, _s.mb10, _s.pt5].join(' ')}>
                <Text weight='medium' color='primary' tagName='label'>
                  Business Account Settings
                </Text>
              </div>

              <div className={[_s.d, _s.w100PC, _s.pt10].join(' ')}>
                <div className={[_s.d, _s.aiCenter, _s.radiusSmall, _s.bgTertiary, _s.w100PC, _s.mb10].join(' ')}>
                  <div className={[_s.d, _s.flexRow, _s.w100PC, _s.px15, _s.py15].join(' ')}>
                    <Avatar account={account} size={22} />&nbsp;&nbsp;
                    <DisplayName account={account} />
                  </div>
                  <div className={[_s.d, _s.w100PC, _s.pt10, _s.borderTop1PX, _s.borderColorInput].join(' ')}>
                    <div className={[_s.d, _s.aiCenter, _s.h40PX, _s.px15, _s.borderBottom1PX, _s.borderColorInput, _s.flexRow, _s.pb5].join(' ')}>
                      <Button
                        noClasses
                        tooltip='Your title for your position in this business.'
                        className={[_s.d, _s.bgSecondary, _s.circle, _s.cursorPointer, _s.font, _s.cPrimary, _s.jcCenter, _s.aiCenter, _s.fs13PX, _s.outlineNone, _s.w20PX, _s.h20PX].join(' ')}
                      >
                        i
                      </Button>
                      <Text className={[_s.w76PX, _s.pl5].join(' ')} weight='bold'>Title:</Text>
                      <Text weight='bold' className={[_s.mlAuto, _s.capitalize].join(' ')}>{businessAccount.get('title')}</Text>
                    </div>
                    <div className={[_s.d, _s.aiCenter, _s.h40PX, _s.px15, _s.borderBottom1PX, _s.borderColorInput, _s.flexRow, _s.pb5].join(' ')}>
                      <Button
                        noClasses
                        tooltip='Your administrative role for this business on Gab.'
                        className={[_s.d, _s.bgSecondary, _s.circle, _s.cursorPointer, _s.font, _s.cPrimary, _s.jcCenter, _s.aiCenter, _s.fs13PX, _s.outlineNone, _s.w20PX, _s.h20PX].join(' ')}
                      >
                        i
                      </Button>
                      <Text className={[_s.w76PX, _s.pl5].join(' ')} weight='bold'>Role:</Text>
                      <Text weight='bold' className={[_s.mlAuto, _s.capitalize].join(' ')}>{businessAccount.get('role')}</Text>
                    </div>
                    <div className={[_s.d, _s.aiCenter, _s.h40PX, _s.px15, _s.flexRow, _s.pb5].join(' ')}>
                      <Button
                        noClasses
                        tooltip="Your account's visibility within this business. If private, your account will be hidden from this business page."
                        className={[_s.d, _s.bgSecondary, _s.circle, _s.cursorPointer, _s.font, _s.cPrimary, _s.jcCenter, _s.aiCenter, _s.fs13PX, _s.outlineNone, _s.w20PX, _s.h20PX].join(' ')}
                      >
                        i
                      </Button>
                      <Text className={[_s.pl5].join(' ')} weight='bold'>Visibility Hidden</Text>
                      <div className={[_s.d, _s.mlAuto].join(' ')}>
                        <input
                          type='checkbox'
                          checked={account_hidden}
                          onChange={(e) => this.handleToggleUserVisibility(e)} 
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          }
          
          {
            !!business &&
            <>
              <div className={[_s.d, _s.mb10, _s.mt5, _s.pt5].join(' ')}>
                <Text weight='medium' color='primary' tagName='label'>
                  GabPro for Business
                </Text>
              </div>

              <div className={[_s.d, _s.w100PC, _s.pt10].join(' ')}>
                <div className={[_s.d, _s.aiCenter, _s.radiusSmall, _s.bgTertiary, _s.w100PC, _s.mb10].join(' ')}>                
                  <div className={[_s.d, _s.w100PC, _s.px15, _s.aiCenter, _s.h40PX, _s.borderBottom1PX, _s.borderColorInput, _s.flexRow].join(' ')}>
                    <Text className={[_s.w192PX].join(' ')} weight='bold'>
                      Status:
                    </Text>
                    <Text weight='bold' className={_s.mlAuto}>
                      {business.get('pro_tier_name', 'None') === 'None' ? 'Inactive' : 'Active'}
                    </Text>
                  </div>

                  <div className={[_s.d, _s.w100PC, _s.px15, _s.aiCenter, _s.h40PX, _s.borderBottom1PX, _s.borderColorInput, _s.flexRow].join(' ')}>
                    <Text className={[_s.w192PX].join(' ')} weight='bold'>
                      PRO Tier:
                    </Text>
                    <Text weight='bold' className={_s.mlAuto}>
                      {business.get('pro_tier_name', 'None') || 'None'}
                    </Text>
                  </div>

                  <div className={[_s.d, _s.w100PC, _s.px15, _s.aiCenter, _s.h40PX, _s.flexRow].join(' ')}>
                    <Text weight='bold'>
                      Expiration / Recurring Date:
                    </Text>
                    <Text weight='bold' className={_s.mlAuto}>
                      {expirationDate}
                    </Text>
                  </div>
                </div>
              </div>
            </>
          }

          <div className={[_s.d, _s.w100PC, _s.pt15].join(' ')}>
            <Button
              isBlock
              backgroundColor='secondary'
              color='primary'
              radiusSmall
            >
              <Text align='center' weight='medium' color='inherit'>GabPro for Business</Text>
            </Button>
          </div>
          {/* delete business
          show/hide reviews
          show/hide mentions */}
        </div>
        {/* DETAILS - SETTINGS */}      


        <Divider isInvisible isSmall />

        <div className={[_s.d, _s.w100PC, _s.mtAuto, _s.mb10].join(' ')}>
          <Button
            isBlock
            radiusSmall
            isDisabled={!submittable}
            onClick={this.handleOnSubmit}
          >
            {/* go to biz page on create */}
            {/* when landing on page, show modal "thank you, will take a few days, go pro now" */}
            <Text color='inherit' align='center' size='medium' weight='medium'>
              { isEditing ? 'Save Changes' : 'Join the Movement!' }
            </Text>
          </Button>
        </div>
      </div>
    )
  }

}

const mapStateToProps = (state, { businessId: propBusinessId, id }) => {
  const businessId = propBusinessId || id
  const businessAccount = state.getIn(['businesses', 'business_accounts', businessId])
  const isOwner = !!businessAccount ?
    businessAccount.get('account_id') === me && businessAccount.get('role') === 'owner' : 
    Array.isArray(meBusinesses) && meBusinesses.indexOf(businessId) > -1
    
  return {
    isOwner,
    businessId,
    businessAccount,
    isSubmitting: state.getIn(['business_editor', 'isSubmitting']),
    isChanged: state.getIn(['business_editor', 'isChanged']),
    attrs: state.getIn(['business_editor', 'attrs']),
    account: !!me ? state.getIn(['accounts', me]) : undefined,
    business: !!businessId ? state.getIn(['businesses', 'items', businessId]) : undefined,
    isXS: state.getIn(['settings', 'window_dimensions', 'width']) <= BREAKPOINT_EXTRA_SMALL,
  }
}

const mapDispatchToProps = (dispatch) => ({
  onChangeAttr: (attr, value) => dispatch(changeBusinessEditorAttr(attr, value)),
  onSubmit: (routerHistory, isEditing) => {
    if (isEditing) dispatch(businessEdit(routerHistory))
    else dispatch(businessCreate(routerHistory))
  },
  onFetchBusinessCategories() {
    dispatch(fetchBusinessCategories())
  },
  onOpenCategoriesModal() {
    dispatch(openModal(MODAL_BUSINESS_CATEGORIES))
  },
  onOpenLocationModal(onChange) {
    dispatch(openModal(MODAL_LOCATION, {
      withLocation: true,
      onChange,
    }))
  },
  onOpenUnauthorizedModal() {
    dispatch(openModal(MODAL_UNAUTHORIZED))
  },
  onFetchBusiness(businessId) {
    dispatch(fetchBusinessById(businessId))
  },
	onResetEditor() {
    dispatch(resetBusinessEditor())
  },
  onSetBusiness(business) {
    dispatch(setBusiness(business))
  },
})

BusinessCreate.propTypes = {
  // 
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(BusinessCreate))