import React from 'react'
import PropTypes from 'prop-types'
import StatusList from '../components/status_list'

const HashtagTimeline = ({ params }) =>
  (<StatusList
    timelineId={`hashtag:${params.id}`}
    endpoint={`/api/v2/timelines/tag/${params.id}`}
    emptyMessage='There is nothing in this hashtag yet.'
    queue
  />)

HashtagTimeline.propTypes = { params: PropTypes.object }

export default HashtagTimeline;
