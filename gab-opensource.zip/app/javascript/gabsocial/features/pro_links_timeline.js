import React from 'react'
import Masonry, { ResponsiveMasonry } from 'react-responsive-masonry'
import StatusList from '../components/status_list'
import ExploreTimelinePills from '../components/explore_timelines_pills'
import ResponsiveClassesComponent from './ui/util/responsive_classes_component'
import ResponsiveComponent from './ui/util/responsive_component'
import GroupSortBlock from '../components/group_sort_block'
import {
  PRO_TIMELINE_SORTS,
  GROUP_SORT_TOPS,
  EXPLORE_SORT_CREATE_PARAMS,
  BREAKPOINT_EXTRA_SMALL
} from '../constants'

function Wrapper({ children }) {
  return (
    <ResponsiveMasonry columnsCountBreakPoints={{0: 1, 992: 2}}>
      <Masonry gutter='10px'>
        {children}
      </Masonry>
    </ResponsiveMasonry>
  )
}

function ProLinksTimeline({ noPills }) {
  return (
    <div className={[_s.d, _s.w100PC].join(' ')}>
      {
        !noPills &&
        <ResponsiveComponent max={BREAKPOINT_EXTRA_SMALL}>
          <ExploreTimelinePills />
        </ResponsiveComponent>
      }
      <ResponsiveClassesComponent classNamesXS={[_s.d, _s.pl10, _s.pt10].join(' ')}>
        <GroupSortBlock timelineId='pro:links' />
      </ResponsiveClassesComponent>
      <StatusList
        timelineId='pro:links'
        endpoint='/api/v2/timelines/links'
        queue
        showAds
        isDeckConnected
        sorts={PRO_TIMELINE_SORTS}
        topSorts={GROUP_SORT_TOPS}
        createParams={EXPLORE_SORT_CREATE_PARAMS}
        wrapper={Wrapper}
      />
    </div>
  )
}

export default ProLinksTimeline
